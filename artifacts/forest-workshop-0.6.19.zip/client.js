var va=Object.defineProperty;var xa=(e,r,a)=>r in e?va(e,r,{enumerable:!0,configurable:!0,writable:!0,value:a}):e[r]=a;var T=(e,r,a)=>xa(e,typeof r!="symbol"?r+"":r,a);var ce=globalThis.__MARINARA_HOST__;if(!ce||ce.version!==1||!ce.queryClient)throw new Error("Marinara Engine does not provide its query client; this package needs capability API 1.341 or newer.");var vn=ce.queryClient;function yt(){let e=ce.api;if(!e?.api)throw new Error("\uC774 Marinara Engine\uC740 \uD328\uD0A4\uC9C0 API \uD074\uB77C\uC774\uC5B8\uD2B8\uB97C \uC81C\uACF5\uD558\uC9C0 \uC54A\uC2B5\uB2C8\uB2E4.");return e}function z(){return yt().api}function F(e,r){try{let a=e.payload;return typeof a?.message=="string"&&a.message?a.message:yt().getApiErrorMessage(e,r)}catch{return e instanceof Error&&e.message?e.message:r}}function me(e){let r=e.payload;return typeof r?.error=="string"?r.error:null}function Ae(){return typeof crypto<"u"&&typeof crypto.randomUUID=="function"?crypto.randomUUID():`${Date.now().toString(36)}-${Math.random().toString(36).slice(2,12)}`}function Q(){if(typeof crypto<"u"&&typeof crypto.randomUUID=="function")return crypto.randomUUID();let e=crypto.getRandomValues(new Uint8Array(16));e[6]=e[6]&15|64,e[8]=e[8]&63|128;let r=[...e].map(a=>a.toString(16).padStart(2,"0")).join("");return`${r.slice(0,8)}-${r.slice(8,12)}-${r.slice(12,16)}-${r.slice(16,20)}-${r.slice(20)}`}var K="/forest-workshop",W={listWorlds:()=>z().get(`${K}/worlds`),createWorld:e=>z().post(`${K}/worlds`,e),getState:e=>z().get(`${K}/state?worldId=${encodeURIComponent(e)}`),getStoryOverview:e=>z().get(`${K}/stories?worldId=${encodeURIComponent(e)}`),getStory:(e,r)=>z().get(`${K}/stories/${encodeURIComponent(r)}?worldId=${encodeURIComponent(e)}`),generateStory:(e,r,a)=>z().post(`${K}/stories/generate`,{worldId:e,pairId:r,episode:a}),getDeliveries:e=>z().get(`${K}/deliveries?worldId=${encodeURIComponent(e)}`),heartbeat:e=>z().post(`${K}/heartbeat`,{worldId:e}),sendCommand:e=>z().post(`${K}/commands`,e),getStorage:e=>z().get(`${K}/storage?worldId=${encodeURIComponent(e)}`),getBackup:e=>z().get(`${K}/backup?worldId=${encodeURIComponent(e)}`),listSources:e=>z().get(`${K}/sources?worldId=${encodeURIComponent(e)}`),previewSource:(e,r,a)=>z().get(`${K}/sources/preview?worldId=${encodeURIComponent(e)}&kind=${r}&id=${encodeURIComponent(a)}`),rebuildSuggestion:(e,r)=>z().post(`${K}/rebuild-suggestion`,{worldId:e,source:r}),uploadResidentImage:e=>{let r=new FormData;return r.append("worldId",e.worldId),r.append("residentId",e.residentId),r.append("uploadKey",e.uploadKey),r.append("file",e.file,e.file.name),z().upload(`${K}/residents/image`,r)},restore:(e,r)=>z().post(`${K}/restore`,{newWorldId:e,backup:r})};var vt="\uC232\uACB0 \uACF5\uBC29 \uBC31\uC5C5 \uD30C\uC77C\uC774 \uC544\uB2D9\uB2C8\uB2E4. \uC124\uC815 \u2192 \uC800\uC7A5\xB7\uBC31\uC5C5\uC5D0\uC11C \uB0B4\uBCF4\uB0B8 JSON \uD30C\uC77C\uC744 \uACE8\uB77C \uC8FC\uC138\uC694.";function xt(e,r){return!e||typeof e!="object"||Array.isArray(e)?0:Object.values(e).filter(r).length}function kt(e){let r=e;if(!r||r.format!=="forest-workshop-backup"||!r.world)return{ok:!1,message:vt};let{settings:a,wallet:i,inventory:n}=r.world;if(typeof a?.worldName!="string"||typeof a.playerNickname!="string")return{ok:!1,message:vt};let o=n&&typeof n=="object"?Object.values(n).filter(s=>typeof s=="number"&&s>0):[];return{ok:!0,summary:{worldName:a.worldName,playerNickname:a.playerNickname,gold:typeof i?.gold=="number"?i.gold:0,itemKinds:o.length,itemTotal:o.reduce((s,l)=>s+l,0),exportedAt:typeof r.exportedAt=="string"?r.exportedAt:"",residents:xt(r.world.residents,()=>!0),pairs:xt(r.world.pairs,s=>!s.archived),pictures:Array.isArray(r.assets)?r.assets.length:0}}}var Nt={weather:{label:"\uD604\uC2E4 \uB0A0\uC528",phase:"P5"}};function Me(e){return e in Nt}function St(e){let r=Nt[e];return r?`${r.label} \uAE30\uB2A5\uC740 \uC544\uC9C1 \uC900\uBE44 \uC911\uC774\uC5D0\uC694.`:""}var $t="forest-workshop:font-size",ae={min:12,max:22,default:16,step:1};function Pe(e){return Number.isFinite(e)?Math.min(ae.max,Math.max(ae.min,Math.round(e))):ae.default}function It(){try{let e=localStorage.getItem($t);return e===null?ae.default:Pe(Number(e))}catch{return ae.default}}function Ct(e){try{localStorage.setItem($t,String(Pe(e)))}catch{}}var Rt="forest-workshop:season",ka=["auto","spring","summer","autumn","winter"];function At(){try{let e=localStorage.getItem(Rt);return ka.includes(e)?e:"auto"}catch{return"auto"}}function Mt(e){try{localStorage.setItem(Rt,e)}catch{}}var Pt="forest-workshop:auto-reading";function ye(e){return{enabled:e?.enabled===!0,seconds:typeof e?.seconds=="number"&&Number.isFinite(e.seconds)?Math.max(2,Math.min(10,Math.round(e.seconds))):4}}function Et(){try{return ye(JSON.parse(localStorage.getItem(Pt)??"null"))}catch{return ye(null)}}function Tt(e){try{localStorage.setItem(Pt,JSON.stringify(ye(e)))}catch{}}var He=["clear","cloudy","rain","snow"],ve={clear:"\uB9D1\uC74C",cloudy:"\uD750\uB9BC",rain:"\uBE44",snow:"\uB208"},Wt="forest-workshop:weather-effects";function Z(e){return{enabled:e?.enabled!==!1,kind:He.includes(e?.kind)?e.kind:"clear"}}function zt(){try{return Z(JSON.parse(localStorage.getItem(Wt)??"null"))}catch{return Z(null)}}function Lt(e){try{localStorage.setItem(Wt,JSON.stringify(Z(e)))}catch{}}function Ke(e){let r=e.getMonth();return r>=2&&r<=4?"spring":r>=5&&r<=7?"summer":r>=8&&r<=10?"autumn":"winter"}function jt(e,r=new Date){return e==="auto"?Ke(r):e}var xe={spring:"\uBD04",summer:"\uC5EC\uB984",autumn:"\uAC00\uC744",winter:"\uACA8\uC6B8"};var Na="forest-workshop",Sa=`/api/capability-packages/${Na}/assets/assets/`,Vt=["spring","summer","autumn","winter"],$a=new Set(["wild-berry","herb","wood","pinecone","acorn","wheat","flower","pumpkin","cotton","tea-leaf","honey","mushroom","beeswax","feather","clover","berry-jam","dried-herb","flour","plank","thread","herb-tea","pumpkin-puree","acorn-flour","herb-sachet","berry-pie","wooden-tray","beeswax-candle","knit-scarf","flower-wreath","pumpkin-soup","honey-cake","birdhouse","acorn-cookie","tea-gift","apple","reed","carrot","flax","clay","salt","dried-apple","apple-jam","linen","reed-cord","prepared-clay","herb-salt","apple-bread","carrot-potage","mushroom-skewer","linen-handkerchief","herb-pillow","reed-basket","wooden-spoon","desk-organizer","clay-planter","wind-chime","apple-gift","picnic-wrap"]),Bt={"gather-yard":"facilities/gather-yard.webp","grow-plot":"facilities/grow-plot.webp","survey-desk":"facilities/survey-desk.webp","process-bench":"facilities/process-bench.webp","craft-bench":"facilities/craft-bench.webp"},ke={spring:{base:"backgrounds/workshop-base-spring.webp",scene:"backgrounds/workshop-scene-spring.webp"},summer:{base:"backgrounds/workshop-base-summer.webp",scene:"backgrounds/workshop-scene-summer.webp"},autumn:{base:"backgrounds/workshop-base-autumn.webp",scene:"backgrounds/workshop-scene-autumn.webp"},winter:{base:"backgrounds/workshop-base-winter.webp",scene:"backgrounds/workshop-scene-winter.webp"}},Ue={joy:"emotions/joy.webp",affection:"emotions/affection.webp",curiosity:"emotions/curiosity.webp",fluster:"emotions/fluster.webp",inspiration:"emotions/inspiration.webp",annoyance:"emotions/annoyance.webp"},pe={home:"ui/nav-home.webp",work:"ui/nav-work.webp",explore:"ui/nav-explore.webp",residents:"ui/nav-residents.webp",invite:"ui/nav-invite.webp"},le={portrait:"ui/manage-portrait.webp",guidelines:"ui/manage-guidelines.webp",memory:"ui/manage-memory.webp",backup:"ui/manage-backup.webp"},Te={sun:"ui/weather-sun.webp",cloud:"ui/weather-cloud.webp",rain:"ui/weather-rain.webp",snow:"ui/weather-snow.webp"},G={gift:"ui/gift.webp",letterPaper:"ui/letter-paper.webp",storyVignette:"ui/story-vignette.webp",inviteScene:"ui/invite-scene.webp",trail:"backgrounds/forest-trail.webp",interior:"backgrounds/workshop-interior.webp",titleSign:"ui/title-sign.webp",primaryButton:"ui/primary-button.webp",paperPanel:"ui/paper-panel.webp",woodPanel:"ui/wood-panel.webp"};function Qe(e){return`${Sa}${e}`}function Dt(e){return $a.has(e)?`items/${e}.webp`:null}var Ee=new Set;function E(e,r){if(!e||Ee.has(e))return r.fallback();let a=document.createElement("img");return a.className=r.className,a.alt=r.alt??"",a.decoding="async",a.draggable=!1,r.lazy&&(a.loading="lazy"),a.addEventListener("error",()=>{Ee.add(e),a.replaceWith(r.fallback())},{once:!0}),a.src=Qe(e),a}function ue(e){return`url("${Qe(e)}")`}var Ot=new Map;function Ft(e){let r=Ot.get(e);return r||(r=new Promise(a=>{if(Ee.has(e))return a(!1);let i=new Image;i.decoding="async",i.onload=()=>a(!0),i.onerror=()=>{Ee.add(e),a(!1)},i.src=Qe(e)}),Ot.set(e,r)),r}function Ye(e){return[{path:ke[e].base,flag:"art-base"},{path:G.titleSign,flag:"art-sign"},{path:G.primaryButton,flag:"art-button"},{path:G.paperPanel,flag:"art-paper"}]}function Gt(e){let r=e,a=new Set;return{get:()=>r,set(i){let n=typeof i=="function"?i(r):i;r={...r,...n};for(let o of a)o(r)},remember(i){let n=typeof i=="function"?i(r):i;r={...r,...n}},subscribe(i){return a.add(i),()=>a.delete(i)}}}var We=class{constructor(){T(this,"epoch",0)}beginNavigation(){return this.epoch+=1,this.epoch}isCurrentNavigation(r){return r===this.epoch}acceptsUpdate(r,a){return!r||r.worldId!==a.worldId?!1:a.revision>=r.revision}};function _t(e){let{store:r}=e;function a(o){r.set(s=>s.register?{register:{...s.register,...o}}:{})}function i(){let o=r.get().register?.pendingImage;o&&URL.revokeObjectURL(o.previewUrl)}async function n(){let o=e.currentWorld();if(o){a({sources:{state:"loading"}});try{let{sources:s}=await W.listSources(o.worldId);a({sources:{state:"ready",value:s}})}catch(s){a({sources:{state:"error",message:F(s,"\uCE90\uB9AD\uD130\xB7\uD398\uB974\uC18C\uB098 \uBAA9\uB85D\uC744 \uBD88\uB7EC\uC624\uC9C0 \uBABB\uD588\uC5B4\uC694.")}})}}}return{openRegister(o=1){i(),r.set({register:{step:o,kindTab:"character",query:"",sources:{state:"loading"},selected:null,preview:null,draft:"",pendingImage:null,starterChoice:null}}),e.navigate("register"),o===1&&n()},closeRegister(){i(),r.set({register:null}),e.navigate("residents")},loadSources:n,setRegisterKind:o=>a({kindTab:o,sourcePage:0}),setRegisterQuery:o=>a({query:o,sourcePage:0}),setRegisterSourcePage:o=>a({sourcePage:Math.max(0,o)}),setRegisterStarterPage:o=>a({starterPage:Math.max(0,o)}),backToSources:()=>a({step:1}),setRegisterPanel:o=>a({panel:o}),setDraft:o=>r.remember(s=>s.register?{register:{...s.register,draft:o}}:{}),setStarterChoice:o=>a({starterChoice:o}),async chooseSource(o){let s=e.currentWorld();if(s){a({step:2,panel:"source",selected:o,preview:{state:"loading"},draft:""});try{let l=await W.previewSource(s.worldId,o.kind,o.id);a({preview:{state:"ready",value:l}})}catch(l){a({preview:{state:"error",message:F(l,"\uC790\uB8CC\uB97C \uC77D\uC9C0 \uBABB\uD588\uC5B4\uC694.")}})}}},async suggestSetting(){let o=e.currentWorld(),s=r.get().register?.selected;if(!o||!s)return;let l=await e.track("rebuild-suggestion",()=>W.rebuildSuggestion(o.worldId,{kind:s.kind,id:s.id}),"\uC81C\uC548\uC744 \uBC1B\uC9C0 \uBABB\uD588\uC5B4\uC694. \uC9C1\uC811 \uC368\uB3C4 \uB3FC\uC694.");l&&a({draft:l.suggestion})},pickPendingImage(o){i(),a({pendingImage:{file:o,previewUrl:URL.createObjectURL(o)}})},clearPendingImage(){i(),a({pendingImage:null})},async confirmRegister(o,s){let l=r.get().register,d=l?.selected;if(!l||!d||!l.draft.trim())return;let c=`register:${d.kind}:${d.id}`,m=e.requestIdFor(`${c}:id`,c,Q);if(!await e.runCommand(c,"residents.register",{residentId:m,source:{kind:d.kind,id:d.id},worldSetting:l.draft}))return;e.forgetRequest(`${c}:id`);let f=o?l.pendingImage:null;f&&await s(m,f.file),i();let b=e.currentWorld();if(b&&b.state.progress.starterResidentId===null){a({step:3,starterChoice:m,pendingImage:null,selected:null,preview:null,draft:""});return}r.set(y=>({register:null,residentsView:{...y.residentsView,selectedId:m}})),e.navigate("residents"),e.notify(`${d.name}\uC744(\uB97C) \uC8FC\uBBFC\uC73C\uB85C \uB4F1\uB85D\uD588\uC5B4\uC694.`)},async confirmStarter(){let o=r.get().register?.starterChoice;!o||!await e.runCommand("choose-starter","residents.chooseStarter",{residentId:o})||(r.set({register:null}),e.navigate("home"),e.notify("\uC2DC\uC791 \uC8FC\uBBFC\uC774 \uACF5\uBC29\uC5D0 \uC654\uC5B4\uC694."))},registerAnother(){a({step:1,query:""}),n()}}}var Ia=6e4;function qt(e){return e.map((r,a)=>({rule:r,index:a})).sort((r,a)=>r.rule.priority-a.rule.priority||r.index-a.index).map(({rule:r})=>r)}function Je(e){return e.map((r,a)=>({...r,priority:Math.min(5,a+1)}))}function Xe(e,r,a){return e.work.drafts[a]??qt(r.facilities[a]?.rules??[])}function Ht(e,r,a){let i=e.work.drafts[a];return!!i&&JSON.stringify(i)!==JSON.stringify(qt(r.facilities[a]?.rules??[]))}function ze(e){let{activity:r,simMs:a,...i}=e.production;return JSON.stringify([e.inventory,e.wallet,i,r.lastAbsence])}function Kt(e){let{store:r}=e,a,i=!1;function n(){return r.get().content}function o(c){r.set(m=>({work:{...m.work,...c}}))}function s(c,m){let g=e.currentWorld();if(!g)return;let f=Xe(r.get(),g.state.production,c);o({drafts:{...r.get().work.drafts,[c]:m(f.map(b=>({...b})))}})}async function l(){let c=e.currentWorld();if(!(!c||i)&&!(typeof document<"u"&&(document.visibilityState!=="visible"||!document.hasFocus()))){i=!0;try{let m=await W.heartbeat(c.worldId),g=e.currentWorld();if(!g||g.worldId!==m.worldId)return;ze(g.state)===ze(m.state)?e.rememberWorld(m):e.showWorld(m)}catch{}finally{i=!1}}}async function d(){let c=e.currentWorld();if(c)try{let m=await W.getState(c.worldId),g=e.currentWorld();if(!g||g.worldId!==m.worldId)return;ze(g.state)===ze(m.state)?e.rememberWorld(m):e.showWorld(m)}catch{}}return{heartbeat:l,refreshProduction:d,startHeartbeat(){clearInterval(a),a=setInterval(()=>{l()},Ia),l()},stopHeartbeat(){clearInterval(a),a=void 0},selectFacility(c){o({facilityId:c,section:"status",queueView:void 0,queuePage:0,priorityPage:0})},setWorkSection(c){o({section:c})},setInventoryPage(c){o({inventoryPage:Math.max(0,c)})},setQueueView(c){o({queueView:c})},setQueuePage(c){o({queuePage:Math.max(0,c)})},setPriorityPage(c){o({priorityPage:Math.max(0,c)})},rememberQueueCount(c,m){r.remember(g=>({work:{...g.work,queueCounts:{...g.work.queueCounts,[c]:m}}}))},rememberProtection(c){r.remember(m=>{if(m.sheet?.kind!=="protect-edit")return{};let g={...m.sheet.drafts};return c.itemId!==void 0&&c.amount!==void 0&&(g[c.itemId]=c.amount),{sheet:{...m.sheet,page:c.page??m.sheet.page,drafts:g}}})},selectRule(c,m){o({selected:{...r.get().work.selected,[c]:m}})},changeTarget(c,m,g){let f=n()?.production.targetStock??{min:1,max:999};s(c,b=>b.map(y=>y.policyId===m?{...y,targetStock:Math.min(f.max,Math.max(f.min,y.targetStock+g))}:y))},toggleRule(c,m){s(c,g=>g.map(f=>f.policyId===m?{...f,enabled:!f.enabled}:f))},moveRule(c,m,g){s(c,f=>{let b=f.findIndex(x=>x.policyId===m),y=b+g;if(b<0||y<0||y>=f.length)return f;let u=[...f];return[u[b],u[y]]=[u[y],u[b]],Je(u)})},addRule(c,m){let g=n()?.production.recommendedRules[c]?.find(b=>b.recipeId===m),f=Q();s(c,b=>Je([...b,{policyId:f,enabled:!0,recipeId:m,targetStock:g?.targetStock??10,priority:5}])),o({selected:{...r.get().work.selected,[c]:f}})},removeRule(c,m){s(c,g=>Je(g.filter(f=>f.policyId!==m)))},recommendRules(c){let m=e.currentWorld(),g=n()?.production.recommendedRules[c]??[];if(!m)return;let f=m.state.production.facilities[c]?.rules??[],b=g.map(y=>({policyId:f.find(u=>u.recipeId===y.recipeId)?.policyId??Q(),enabled:!0,recipeId:y.recipeId,targetStock:y.targetStock,priority:y.priority}));o({drafts:{...r.get().work.drafts,[c]:b}}),e.notify("\uCD94\uCC9C \uC124\uC815\uC744 \uBD88\uB7EC\uC654\uC5B4\uC694. \uD655\uC778\uD55C \uB4A4 '\uC6B4\uC601 \uADDC\uCE59 \uC801\uC6A9'\uC744 \uB204\uB974\uBA74 \uBC14\uB00C\uC5B4\uC694.")},discardDraft(c){let m={...r.get().work.drafts};delete m[c],o({drafts:m})},async applyRules(c){let m=r.get().work.drafts[c];if(!m||!await e.runCommand(`rules:${c}`,"production.setRules",{facilityId:c,rules:m}))return;let f={...r.get().work.drafts};delete f[c],o({drafts:f}),e.notify("\uC6B4\uC601 \uADDC\uCE59\uC744 \uC801\uC6A9\uD588\uC5B4\uC694. \uC9C0\uAE08 \uC791\uC5C5\uC740 \uADF8\uB300\uB85C \uC774\uC5B4\uC9C0\uACE0 \uB2E4\uC74C \uD68C\uCC28\uBD80\uD130 \uBC14\uB00C\uC5B4\uC694.")},async upgradeFacility(c,m){let g=await e.runCommand(`upgrade:${c}:${m}`,"production.upgradeFacility",{facilityId:c,fromLevel:m});g&&e.notify(`Lv. ${String(g.result.level)}\uB85C \uAC15\uD654\uD588\uC5B4\uC694. \uB2E4\uC74C \uD68C\uCC28\uBD80\uD130 \uBE68\uB77C\uC838\uC694.`)},async setProtected(c,m){await e.runCommand(`protect:${c}`,"production.setProtected",{itemId:c,amount:m})&&r.remember(f=>{if(f.sheet?.kind!=="protect-edit"||f.sheet.drafts?.[c]!==m)return{};let b={...f.sheet.drafts};return delete b[c],{sheet:{...f.sheet,drafts:b}}})},async sell(c,m){let g=await e.runCommand(`sell:${c}`,"economy.sell",{itemId:c,amount:m});g&&(r.set({sheet:null}),e.notify(`${m}\uAC1C\uB97C \uD314\uC544 ${String(g.result.gold)} G\uB97C \uBC1B\uC558\uC5B4\uC694.`))},async unlockFacility(c){let m=await e.runCommand(`unlock:${c}`,"production.unlockFacility",{facilityId:c});m&&!m.result.alreadyOpen&&e.notify("\uC2DC\uC124\uC774 \uC5F4\uB838\uC5B4\uC694. \uCD94\uCC9C \uADDC\uCE59\uC73C\uB85C \uBC14\uB85C \uC77C\uC744 \uC2DC\uC791\uD574\uC694.")},async setMode(c,m){(await e.runCommand(`mode:${c}`,"production.setMode",{facilityId:c,mode:m}))?.result.running&&e.notify("\uC9C0\uAE08 \uC791\uC5C5\uC774 \uB05D\uB098\uBA74 \uBC14\uB010 \uBC29\uC2DD\uC73C\uB85C \uC774\uC5B4\uC838\uC694.")},selectQueueRecipe(c,m){o({queueRecipe:{...r.get().work.queueRecipe,[c]:m}})},async addQueue(c,m,g){let f=`queue-entry:${c}`,b=e.requestIdFor(f,JSON.stringify([m,g]),Q);await e.runCommand(`queue:${c}`,"production.queueAdd",{facilityId:c,entryId:b,recipeId:m,count:g})&&e.forgetRequest(f)},async removeQueue(c,m){await e.runCommand(`queue-remove:${m}`,"production.queueRemove",{facilityId:c,entryId:m})},async assignResident(c,m){await e.runCommand(`assign:${c}`,"production.assignResident",{facilityId:c,residentId:m})&&(r.set({sheet:null}),e.notify(m?"\uC8FC\uBBFC\uC744 \uBC30\uCE58\uD588\uC5B4\uC694. \uBD84\uC57C\uAC00 \uB9DE\uC73C\uBA74 \uB2E4\uC74C \uC791\uC5C5\uBD80\uD130 \uD6A8\uACFC\uAC00 \uC801\uC6A9\uB3FC\uC694.":"\uC8FC\uBBFC \uBC30\uCE58\uB97C \uD574\uC81C\uD588\uC5B4\uC694."))},async setAutoSell(c,m){await e.runCommand(`auto-sell:${c}`,"economy.setAutoSell",{itemId:c,setting:m})&&e.notify(m.enabled?"\uC790\uB3D9 \uD310\uB9E4 \uC124\uC815\uC744 \uC800\uC7A5\uD588\uC5B4\uC694.":"\uC790\uB3D9 \uD310\uB9E4\uB97C \uAED0\uC5B4\uC694.")},async readReports(c){await e.runCommand("reports-read","production.markReportsRead",{throughReportId:c})&&r.set({sheet:null})}}}function Ze(e,r){let a=r.query.trim().toLowerCase();return Object.values(e.residents).filter(i=>r.tab==="all"||i.kind===r.tab).filter(i=>r.filter==="all"?!0:r.filter==="recruited"?i.recruited:!i.recruited).filter(i=>!a||i.displayName.toLowerCase().includes(a)||i.source.name.toLowerCase().includes(a)).sort((i,n)=>Number(n.recruited)-Number(i.recruited)||i.registeredAt.localeCompare(n.registeredAt))}function et(e,r){return`pair-add:${[e,r].sort().join(":")}`}function tt(e,r){return e.residentIds[0]===r?e.residentIds[1]:e.residentIds[0]}function Ut(e){let{store:r}=e;function a(n){let o=e.currentWorld();return o&&n?o.state.residents[n]??null:null}function i(n){r.set(o=>({residentsView:{...o.residentsView,...n}}))}return{openGuidelines(n){r.set({sheet:{kind:"guidelines",pairId:n}})},rememberGuidelines(n){r.remember(o=>o.sheet?.kind==="guidelines"?{sheet:{...o.sheet,draft:{...n}}}:{})},async saveGuidelines(n,o){await e.runCommand(`guidelines:${n??"world"}`,"guidelines.update",{...n?{pairId:n}:{},...o})&&(r.set(l=>l.sheet?.kind==="guidelines"&&l.sheet.pairId===n&&JSON.stringify(l.sheet.draft)===JSON.stringify(o)?{sheet:{...l.sheet,draft:void 0}}:{}),e.notify("AI \uC9C0\uCE68\uC744 \uC800\uC7A5\uD588\uC5B4\uC694. \uB2E4\uC74C\uC5D0 \uC0C8\uB85C \uC4F0\uB294 \uC774\uC57C\uAE30\uBD80\uD130 \uC801\uC6A9\uB3FC\uC694."))},openMailbox(){r.set({sheet:{kind:"mailbox"}})},async openActivityLetter(n){let o=e.currentWorld()?.state.mailbox.letters.find(l=>l.id===n);if(!o){r.set({sheet:{kind:"mailbox"}}),e.notify("\uACB0\uACFC \uD3B8\uC9C0\uB97C \uCC3E\uC744 \uC218 \uC5C6\uC5B4\uC694. \uC6B0\uD3B8\uD568\uC744 \uD655\uC778\uD574 \uC8FC\uC138\uC694.");return}r.set({sheet:{kind:"mailbox",archived:o.archived}}),(o.readAt||await e.runCommand(`mail:${n}`,"mail.read",{id:n}))&&r.set(l=>l.sheet?.kind==="mailbox"?{sheet:{...l.sheet,id:n}}:{})},setMailboxView(n){r.set(o=>o.sheet?.kind==="mailbox"?{sheet:{...o.sheet,...n}}:{})},async openLetter(n){await e.runCommand(`mail:${n}`,"mail.read",{id:n})&&r.set(s=>s.sheet?.kind==="mailbox"?{sheet:{...s.sheet,id:n}}:{})},async archiveLetter(n,o){await e.runCommand(`mail:${n}`,"mail.archive",{id:n,archived:o})&&r.set(l=>l.sheet?.kind==="mailbox"?{sheet:{...l.sheet,id:void 0}}:{})},openMemory(n){r.set({sheet:{kind:"memory",pairId:n,page:0}})},updateMemoryView(n){r.set(o=>o.sheet?.kind==="memory"?{sheet:{...o.sheet,...n}}:{})},rememberMemoryDraft(n){r.remember(o=>o.sheet?.kind==="memory"?{sheet:{...o.sheet,draft:n}}:{})},async correctMemory(n,o){let s=await e.runCommand(`memory:${n}`,"memory.correct",{factId:n,text:o});s&&(r.set(l=>l.sheet?.kind==="memory"?{sheet:{...l.sheet,factId:Number(s.result.factId),draft:void 0}}:{}),e.notify("\uAE30\uC5B5\uC744 \uC815\uC815\uD588\uC5B4\uC694. \uC6D0\uBB38\uC740 \uC774\uB825\uC5D0 \uB0A8\uC544\uC694."))},async setMemoryStatus(n,o){await e.runCommand(`memory:${n}`,"memory.setStatus",{factId:n,active:o})},setResidentsTab:n=>i({tab:n,page:0}),setResidentsQuery:n=>i({query:n,page:0}),setResidentsFilter:n=>i({filter:n,page:0}),setResidentsPage:n=>i({page:Math.max(0,n)}),showResidentsList:()=>i({detailOpen:!1}),selectResident:n=>i({selectedId:n}),openResidents(n){if(n){let o={...r.get().residentsView,tab:"all",query:"",filter:"all",selectedId:n,detailOpen:!1},s=e.currentWorld(),l=s?Ze(s.state,o).findIndex(d=>d.residentId===n):0;i({...o,page:Math.max(0,Math.floor(l/2))})}else i({detailOpen:!1});e.navigate("residents")},openRelations(n){r.set({focusResidentId:n}),e.navigate("relations")},openResidentImage(n){let o=a(n);r.set({focusResidentId:n,placementDraft:o?{...o.image.placement}:null}),e.navigate("resident-image")},openSheet(n){r.set({sheet:n,notice:null})},closeSheet(){r.set({sheet:null})},rememberProfile(n){r.remember(o=>o.sheet?.kind==="profile"?{sheet:{...o.sheet,...n}}:{})},toggleRelationsEditing(){r.set(n=>({relationsEditing:!n.relationsEditing}))},async updateWorldSetting(n,o){let s=await e.runCommand(`resident-setting:${n}`,"residents.update",{residentId:n,worldSetting:o});return s&&(r.remember(l=>l.sheet?.kind==="profile"?{sheet:{...l.sheet,draft:void 0}}:{}),e.notify("\uACF5\uBC29 \uC138\uACC4 \uC124\uC815\uC744 \uACE0\uCCE4\uC5B4\uC694. \uBCC0\uACBD \uC774\uB825\uC5D0 \uB0A8\uC558\uC5B4\uC694.")),s},async addPair(n,o){let s=a(n),l=a(o);if(!s||!l)return;let d=et(s.residentId,l.residentId),c=e.requestIdFor(`${d}:id`,d,Q);await e.runCommand(d,"pairs.add",{pairId:c,residentIds:[s.residentId,l.residentId]})&&(e.forgetRequest(`${d}:id`),r.set({sheet:null}),e.notify(`${s.displayName} \xD7 ${l.displayName} \uD398\uC5B4\uB97C \uB9CC\uB4E4\uC5C8\uC5B4\uC694.`))},archivePair:n=>e.runCommand(`pair-archive:${n}`,"pairs.archive",{pairId:n}),restorePair:n=>e.runCommand(`pair-restore:${n}`,"pairs.restore",{pairId:n}),setPlacementDraft(n){r.set(o=>o.placementDraft?{placementDraft:{...o.placementDraft,...n}}:{})},resetPlacementDraft(){let n=r.get().content?.residents.placement;n&&r.set({placementDraft:{scale:n.scale.default,offsetX:n.offsetX.default,markerHeight:n.markerHeight.default}})},async applyPlacement(n){let o=r.get().placementDraft;if(!o)return;await e.runCommand(`placement:${n}`,"residents.setPlacement",{residentId:n,placement:o})&&e.notify("\uBC30\uCE58\uB97C \uC801\uC6A9\uD588\uC5B4\uC694. \uADF8\uB9BC \uD30C\uC77C\uC740 \uADF8\uB300\uB85C\uC608\uC694.")},async uploadResidentImage(n,o){let s=e.currentWorld();if(!s)return null;let l=`image-upload:${n}`,d=e.requestIdFor(l,`${n}:${o.name}:${o.size}:${o.lastModified}`),c=await e.track(l,()=>W.uploadResidentImage({worldId:s.worldId,residentId:n,uploadKey:d,file:o}),"\uADF8\uB9BC\uC744 \uC800\uC7A5\uD558\uC9C0 \uBABB\uD588\uC5B4\uC694. \uAE30\uC874 \uADF8\uB9BC\uC740 \uADF8\uB300\uB85C\uC608\uC694.");if(!c)return null;let m=e.currentWorld()??s;return e.showWorld({worldId:m.worldId,revision:c.revision,updatedAt:new Date().toISOString(),state:c.state}),e.notify(c.duplicate?"\uC774\uBBF8 \uC800\uC7A5\uB41C \uADF8\uB9BC\uC774\uC5D0\uC694.":"\uADF8\uB9BC\uC744 WebP\uB85C \uC800\uC7A5\uD588\uC5B4\uC694."),c},async restoreResidentImage(n,o){await e.runCommand(`image-restore:${n}`,"residents.restoreImage",{residentId:n,reference:o})&&(r.set({sheet:null}),e.notify("\uC774\uC804 \uADF8\uB9BC\uC73C\uB85C \uB418\uB3CC\uB838\uC5B4\uC694."))},async clearImageHistory(){let n=await e.runCommand("image-history-clear","residents.clearImageHistory",{});if(!n)return;r.set({sheet:null});let o=Array.isArray(n.result.released)?n.result.released.length:0;e.notify(o?`\uC774\uC804 \uADF8\uB9BC ${o}\uC7A5\uC744 \uC815\uB9AC\uD588\uC5B4\uC694.`:"\uC815\uB9AC\uD560 \uC774\uC804 \uADF8\uB9BC\uC774 \uC5C6\uC5B4\uC694."),await e.refreshStorage()}}}function Qt(e){let{store:r}=e,a=0;async function i(){let n=e.currentWorld();if(!n)return;let o=++a;r.set({deliveries:{state:"loading"}});try{let s=await W.getDeliveries(n.worldId);o===a&&e.currentWorld()?.worldId===n.worldId&&r.set({deliveries:{state:"ready",value:s}})}catch(s){o===a&&e.currentWorld()?.worldId===n.worldId&&r.set({deliveries:{state:"error",message:F(s,"\uB0A9\uD488 \uC758\uB8B0\uB97C \uBD88\uB7EC\uC624\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4.")}})}}return{setInviteTab(n){r.set({inviteTab:n,invitePage:0})},setInvitePage(n){r.set({invitePage:Math.max(0,n)})},setInviteSheetPage(n){r.set(o=>{let s=o.sheet;return!s||s.kind!=="invite-result"&&s.kind!=="invite-chances"&&s.kind!=="invite-log"&&s.kind!=="invite-wish"?{}:{sheet:{...s,page:Math.max(0,n)}}})},async draw(n){let o=await e.runCommand(`invite:${n}`,"invite.draw",{count:n});o&&r.set({sheet:{kind:"invite-result",draws:o.result.draws}})},async setWish(n){await e.runCommand("invite-wish","invite.setWish",{residentId:n})&&r.set({sheet:null})},async exchange(n){let o=await e.runCommand(`exchange:${n}`,"invite.exchange",{residentId:n});o&&r.set({sheet:{kind:"invite-result",draws:[o.result]}})},openDeliveries(){r.set({sheet:{kind:"deliveries"}}),i()},selectDelivery(n){r.set(o=>o.sheet?.kind==="deliveries"?{sheet:{...o.sheet,selectedOrderId:n}}:{})},async deliver(n){let o=await e.runCommand(`deliver:${n}`,"economy.deliver",{orderId:n});if(!o)return;let s=o.result.reward;e.notify(`\uB0A9\uD488\uD588\uC5B4\uC694. \uCD08\uB300\uAD8C ${s.tickets}\uC7A5\uACFC ${s.gold} G\uB97C \uBC1B\uC558\uC5B4\uC694.`),await i()}}}function ge(e){return!e||e.kind==="choice"?[]:[e.text]}function Yt(e){return typeof Intl.Segmenter=="function"?Array.from(new Intl.Segmenter(void 0,{granularity:"grapheme"}).segment(e),r=>r.segment):Array.from(e)}function Ca(e,r){let a=Yt(e),i=[];for(let n=0;n<a.length;){let o=1,s=a.length-n,l=0;for(;o<=s;){let c=Math.floor((o+s)/2);r(a.slice(n,n+c).join(""))?(l=c,o=c+1):s=c-1}let d=n+Math.max(1,l);if(d<a.length){let c=n+Math.floor((d-n)*.6),m=a.slice(c,d).join(""),g=[...m.matchAll(/[.!?。！？…]+[”’"')\]]*\s*|\n+|\s+/gu)],f=g.filter(y=>/[.!?。！？…\n]/u.test(y[0])),b=(f.length?f:g).at(-1);b?.index!==void 0&&(d=c+Yt(m.slice(0,b.index+b[0].length)).length)}i.push(a.slice(n,d).join("")),n=d}return i.length?i:[""]}function Jt(e,r){let a=e.querySelector(".line, .narration");if(!a||!e.clientWidth||!e.clientHeight)return null;let i=getComputedStyle(e),n=e.querySelector(".speaker-tag"),o=e.clientHeight-parseFloat(i.paddingTop)-parseFloat(i.paddingBottom)-(n?n.getBoundingClientRect().height+(parseFloat(i.rowGap)||0):0),s=a.textContent;try{return Ca(r,l=>(a.textContent=l,a.getBoundingClientRect().height<=o+.5))}finally{a.textContent=s}}function Xt(e){let{store:r}=e,a,i=-1,n="";function o(u){r.set(x=>({explore:{...x.explore,...u}}))}function s(u){r.set(x=>x.reader?{reader:{...x.reader,...u}}:{})}async function l(u=!1){let x=e.currentWorld();if(x){u||o({overview:{state:"loading"}});try{let S=await W.getStoryOverview(x.worldId),$=r.get().explore.pairId;o({overview:{state:"ready",value:S},pairId:S.pairs.some(V=>V.pairId===$)?$:S.pairs[0]?.pairId??null})}catch(S){u||o({overview:{state:"error",message:F(S,"\uC774\uC57C\uAE30\uB97C \uBD88\uB7EC\uC624\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4.")}})}}}r.subscribe(u=>{u.route!==n&&(n=u.route,u.route!=="story"&&c(),u.route==="explore"&&l(u.explore.overview?.state==="ready"));let x=u.world?.state==="ready"?u.world.value.revision:-1;x!==i&&(i=x,(u.route==="explore"||u.route==="home")&&u.explore.overview?.state==="ready"&&l(!0))});function d(){clearInterval(a),a=void 0}function c(){d(),r.get().reader?.auto&&s({auto:!1})}function m(){let u=r.get().reader;if(!u||u.story.state!=="ready"||u.backlog||r.get().route!=="story")return;let x=u.story.value.segments[u.index];if(!x||x.kind==="choice"&&!f()){c();return}d(),s({auto:!0}),a=setInterval(()=>{let S=r.get(),$=S.reader;if(!$?.auto||S.route!=="story"||$.backlog||document.hidden||!document.hasFocus()){c();return}b()},(r.get().autoReading?.seconds??4)*1e3)}function g(){let u=r.get().reader;return u?.story.state==="ready"?u.story.value.segments:[]}function f(){let u=r.get().reader,x=e.currentWorld();if(!u||!x)return!1;let S=x.state.stories.pairs[u.pairId],V=[S?.current,...S?.completed??[]].find(H=>H?.episodes[u.episode]?.storyId===u.storyId)?.episodes[u.episode];return!!V?.choice||V?.state==="read"}function b(){let u=r.get().reader;if(!u)return;let x=g(),S=x[u.index],$=u.textPages??ge(S);if((u.textPage??0)+1<$.length){s({textPage:(u.textPage??0)+1});return}S?.kind==="choice"&&!f()||(u.index<x.length&&s({index:u.index+1,textPage:0,textPages:void 0,choiceView:"question"}),(u.index+1>=x.length||x[u.index+1]?.kind==="choice")&&c())}async function y(){let u=r.get().reader,x=e.currentWorld();if(!(!u||!x)){s({story:{state:"loading"}});try{let S;try{S=await W.getStory(x.worldId,u.storyId)}catch($){if(me($)!=="story_not_found")throw $;S=await W.generateStory(x.worldId,u.pairId,u.episode)}if(r.get().reader?.storyId!==u.storyId)return;s({story:{state:"ready",value:S},index:0}),r.get().autoReading?.enabled&&m()}catch(S){if(r.get().reader?.storyId!==u.storyId)return;s({story:{state:"error",message:F(S,"\uC774\uC57C\uAE30\uB97C \uC4F0\uC9C0 \uBABB\uD588\uC5B4\uC694. \uAC19\uC740 \uC774\uC57C\uAE30\uB85C \uB2E4\uC2DC \uC2DC\uB3C4\uD560 \uC218 \uC788\uC5B4\uC694.")}})}}}return{loadStoryOverview:l,selectActivityResident(u){o({activityResidentId:u})},async startActivity(u,x){let S=e.currentWorld();if(!S)return;let $=e.requestIdFor("activity-id",JSON.stringify([S.worldId,u,x]),Q);await e.runCommand("activity-start","activities.start",{id:$,kind:u,placeId:"workshop-edge",residentId:x})&&(e.forgetRequest("activity-id"),e.notify("\uACF5\uBC29 \uC8FC\uBCC0\uC73C\uB85C \uCD9C\uBC1C\uD588\uC5B4\uC694."))},async cancelActivity(u){await e.runCommand(`activity-cancel:${u}`,"activities.cancel",{id:u})},openExplore(){e.navigate("explore")},setExploreTab(u){o({tab:u})},setExploreSection(u){o({section:u})},setExploreHistoryPage(u){o({historyPage:Math.max(0,u)})},selectStoryPair(u){o({pairId:u,historyPage:0,selectedEpisode:void 0})},selectStoryEpisode(u){o({selectedEpisode:u})},async depart(u,x){let S=await e.runCommand(`depart:${u}:${x}`,"stories.depart",{pairId:u,episode:x});S&&(e.notify(`\uD0D0\uD5D8\uC744 \uB5A0\uB0AC\uC5B4\uC694. ${String(S.result.minutes)}\uBD84 \uB4A4\uC5D0 \uC774\uC57C\uAE30\uAC00 \uC5F4\uB824\uC694.`),await l(!0))},async cancelExpedition(){await e.runCommand("expedition-cancel","stories.cancel",{})&&(e.notify("\uD0D0\uD5D8\uC744 \uCDE8\uC18C\uD588\uC5B4\uC694. \uC900\uBE44\uBB3C\uC740 \uBAA8\uB450 \uB3CC\uB824\uBC1B\uC558\uC5B4\uC694."),await l(!0))},openStory(u,x,S){d();let $=r.get().route==="story"?"explore":r.get().route;r.set({reader:{pairId:u,episode:x,storyId:S,story:{state:"loading"},index:0,auto:!1,backlog:!1,from:$}}),e.navigate("story"),y()},retryStory(){y()},advanceStory:b,setStoryTextPages(u,x,S){let $=r.get().reader;if(!$||$.storyId!==u||$.index!==x||$.story.state!=="ready")return;let V=$.story.value.segments[x];if(!V||V.kind==="choice"||S.join("")!==V.text)return;let H=$.textPages??ge(V);if(JSON.stringify(H)===JSON.stringify(S))return;let A=H.slice(0,$.textPage??0).reduce((N,R)=>N+Array.from(R).length,0),h=0,v=Array.from(S[0]??"").length;for(;h<S.length-1&&v<=A;)v+=Array.from(S[++h]).length;s({textPages:S,textPage:h})},setChoiceView(u){s({choiceView:u})},pauseAutoReading:c,toggleAuto(){r.get().reader?.auto?c():m()},toggleBacklog(){let u=r.get().reader;u&&(c(),s({backlog:!u.backlog,backlogPage:void 0}))},setBacklogPage(u){s({backlogPage:Math.max(0,u)})},async chooseAnswer(u){let x=r.get().reader;if(!x)return;await e.runCommand(`choose:${x.storyId}`,"stories.choose",{pairId:x.pairId,episode:x.episode,storyId:x.storyId,optionId:u})&&b()},async finishStory(){let u=r.get().reader;if(!u)return;d();let x=await e.runCommand(`read:${u.storyId}`,"stories.markRead",{pairId:u.pairId,episode:u.episode,storyId:u.storyId});x&&(o({tab:"story",section:"history",pairId:u.pairId,historyPage:0}),r.set({reader:null}),e.navigate("explore"),x.result.alreadyRead||e.notify(x.result.arcDone?"\uC774 \uD0D0\uD5D8\uC758 \uC774\uC57C\uAE30\uB97C \uBAA8\uB450 \uC77D\uC5C8\uC5B4\uC694. \uB2E4\uC74C \uD0D0\uD5D8\uC774 \uC5F4\uB838\uC5B4\uC694.":"\uC774\uC57C\uAE30\uB97C \uB2E4 \uC77D\uC5C8\uC5B4\uC694. \uB2E4\uC74C \uC774\uC57C\uAE30\uB97C \uB5A0\uB0A0 \uC218 \uC788\uB294\uC9C0 \uD655\uC778\uD574 \uBCF4\uC138\uC694."),await l(!0))},closeStory(){let u=r.get().reader;d(),r.set({reader:null}),e.navigate(u?.from&&u.from!=="story"?u.from:"explore")}}}var rt="forest-workshop:last-world";function Ra(){try{return localStorage.getItem(rt)}catch{return null}}function Zt(e){try{e?localStorage.setItem(rt,e):localStorage.removeItem(rt)}catch{}}function Aa(e){let r=e.status;return typeof r=="number"&&r>=400&&r<500&&me(e)!==null}function er(){let e=Gt({route:"worlds",worlds:{state:"loading"},world:null,content:null,busy:{},notice:null,restore:null,fontSize:It(),autoReading:Et(),weatherEffects:zt(),seasonChoice:At(),artReady:[],facilitiesTab:"facilities",storage:null,starterSheetHidden:!1,residentsView:{tab:"all",query:"",filter:"all",selectedId:null},focusResidentId:null,relationsEditing:!1,sheet:null,placementDraft:null,register:null,work:{facilityId:"gather-yard",drafts:{},selected:{},queueRecipe:{}},inviteTab:"invite",deliveries:null,explore:{tab:"story",pairId:null,overview:null},reader:null,worldReceivedAt:Date.now()}),r=new Map,a=new We;function i(){for(let{path:h}of Ye(ee(e.get())))Ft(h).then(v=>{v&&!e.get().artReady.includes(h)&&e.set(N=>({artReady:[...N.artReady,h]}))})}i();let n=4e3,o=null,s;e.subscribe(h=>{if(h.notice!==o&&(o=h.notice,clearTimeout(s),o?.kind==="info")){let v=o;s=setTimeout(()=>{e.get().notice===v&&e.set({notice:null})},n)}});function l(h,v,N=Ae){let R=r.get(h);if(R&&R.signature===v)return R.id;let D=N();return r.set(h,{id:D,signature:v}),D}function d(h,v){e.set(N=>({busy:{...N.busy,[h]:v}}))}async function c(h,v,N){if(e.get().busy[h])return null;d(h,!0),e.set({notice:null});try{let R=await v();return r.delete(h),R}catch(R){return Aa(R)&&r.delete(h),e.set({notice:{kind:"error",text:F(R,N)}}),me(R)==="stale_view"&&S(),null}finally{d(h,!1)}}function m(h,v){Zt(h.worldId),e.set(N=>({world:{state:"ready",value:{worldId:h.worldId,revision:h.revision,updatedAt:h.updatedAt,state:h.state}},worldReceivedAt:Date.now(),work:N.world?.state==="ready"&&N.world.value.worldId===h.worldId?N.work:{facilityId:N.work.facilityId,drafts:{},selected:{},queueRecipe:{}},content:v??N.content,route:N.route==="worlds"?"home":N.route}))}function g(h,v){a.acceptsUpdate($(),h)&&m(h,v)}function f(h,v){a.beginNavigation(),m(h,v)}function b(h){a.acceptsUpdate($(),h)&&e.remember({world:{state:"ready",value:{worldId:h.worldId,revision:h.revision,updatedAt:h.updatedAt,state:h.state}},worldReceivedAt:Date.now()})}async function y(){e.set({worlds:{state:"loading"}});try{let{worlds:h}=await W.listWorlds();return e.set({worlds:{state:"ready",value:h}}),h}catch(h){return e.set({worlds:{state:"error",message:F(h,"\uC138\uACC4 \uBAA9\uB85D\uC744 \uBD88\uB7EC\uC624\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4.")}}),null}}async function u(h){let v=a.beginNavigation();e.set({world:{state:"loading"},route:"home",notice:null});try{let N=await W.getState(h);if(!a.isCurrentNavigation(v))return;m(N,N.content)}catch(N){if(!a.isCurrentNavigation(v))return;me(N)==="world_not_found"&&Zt(null),e.set({world:{state:"error",message:F(N,"\uC138\uACC4\uB97C \uBD88\uB7EC\uC624\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4.")}})}}async function x(){let h=$();if(h){e.set({storage:{state:"loading"}});try{e.set({storage:{state:"ready",value:await W.getStorage(h.worldId)}})}catch(v){e.set({storage:{state:"error",message:F(v,"\uC800\uC7A5 \uACF5\uAC04\uC744 \uD655\uC778\uD558\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4.")}})}}}async function S(){let h=e.get().world;h?.state==="ready"&&await u(h.value.worldId)}function $(){let h=e.get().world;return h?.state==="ready"?h.value:null}function V(h){e.set({route:h,notice:null,restore:null,sheet:null,relationsEditing:!1}),h==="worlds"&&y(),h==="backup"&&x()}async function H(h,v,N={}){let R=$();if(!R)return null;let D=JSON.stringify([R.worldId,v,N]),ya=l(h,D),Re=await c(h,()=>W.sendCommand({worldId:R.worldId,commandId:ya,expectedRevision:R.revision,type:v,payload:N}),"\uC694\uCCAD\uC744 \uCC98\uB9AC\uD558\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4. \uB2E4\uC2DC \uC2DC\uB3C4\uD574 \uC8FC\uC138\uC694.");return!Re||$()?.worldId!==R.worldId?null:(g({worldId:R.worldId,revision:Re.revision,updatedAt:new Date().toISOString(),state:Re.state}),Re)}let A={store:e,track:c,runCommand:H,currentWorld:$,requestIdFor:l,forgetRequest:h=>r.delete(h),showWorld:g,rememberWorld:b,navigate:V,refreshStorage:x,notify:(h,v="info")=>e.set({notice:{kind:v,text:h}})};return{store:e,...Ut(A),..._t(A),...Kt(A),...Qt(A),...Xt(A),async start(){let h=await y(),v=Ra();h&&v&&h.some(N=>N.worldId===v&&N.readable)&&await u(v)},loadWorlds:y,openWorld:u,reloadWorld:S,setWorldsPage(h){e.set({worldsPage:Math.max(0,h)})},rememberWorldDraft(h){e.remember({worldDraft:h})},rememberWorldCreateOpen(h){e.remember({worldCreateOpen:h})},navigate:V,notify:A.notify,notifyLocked(h){e.set({notice:{kind:"info",text:St(h)}})},setSeasonChoice(h){Mt(h),e.set({seasonChoice:h}),i()},setWeatherEffects(h){let v=Z(h);Lt(v),e.set({weatherEffects:v})},setAutoReading(h){let v=ye(h);Tt(v),e.set({autoReading:v})},setFontSize(h){let v=Pe(h);Ct(v),e.set({fontSize:v})},setFacilitiesTab(h){e.set(v=>({facilitiesTab:h,work:{...v.work,inventoryPage:0}}))},setSettingsSection(h){e.set({settingsSection:h})},rememberSettingsNickname(h,v){e.remember({settingsNicknameDraft:{worldId:h,value:v}})},async saveSettingsNickname(h,v){let N=await H("rename-nickname","settings.update",{playerNickname:v}),R=e.get().settingsNicknameDraft;return N&&R?.worldId===h&&R.value===v&&e.remember({settingsNicknameDraft:void 0}),N},openGroundEditor(){let h=$();h&&(V("home"),e.set({groundEditingWorld:h.worldId,settingsGroundDraft:{worldId:h.worldId,value:{...h.state.settings.ground}}}))},resetGroundEditor(){let h=$();h&&e.set({settingsGroundDraft:{worldId:h.worldId,value:{left:12,right:88,top:58,bottom:90}}})},cancelGroundEditor(){e.set({groundEditingWorld:void 0,settingsGroundDraft:void 0})},rememberGround(h,v){e.remember({settingsGroundDraft:{worldId:h,value:{...v}}})},async saveGround(h){let v=$()?.worldId,N={...h},R=await H("ground-save","settings.update",{ground:N});if(R){let D=e.get().settingsGroundDraft;D&&D.worldId===v&&JSON.stringify(D.value)===JSON.stringify(N)&&e.remember({settingsGroundDraft:void 0,groundEditingWorld:void 0}),A.notify("\uC9C0\uBA74 \uC124\uC815\uC744 \uC800\uC7A5\uD588\uC5B4\uC694.")}return R},hideStarterSheet(){e.set({starterSheetHidden:!0})},showStarterSheet(){e.set({starterSheetHidden:!1})},dismissNotice(){e.set({notice:null})},async createWorld(h,v){let N=JSON.stringify([h.trim(),v.trim()]),R=l("create-world",N,Q),D=await c("create-world",()=>W.createWorld({worldId:R,worldName:h,playerNickname:v}),"\uC138\uACC4\uB97C \uB9CC\uB4E4\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4.");D&&(e.remember({worldDraft:void 0,worldCreateOpen:!1}),f(D,D.content))},runCommand:H,async downloadBackup(){let h=$();if(!h)return;let v=await c("backup",()=>W.getBackup(h.worldId),"\uBC31\uC5C5\uC744 \uB9CC\uB4E4\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4.");if(!v)return;let N=new Blob([`${JSON.stringify(v,null,2)}
`],{type:"application/json"}),R=URL.createObjectURL(N),D=document.createElement("a");D.href=R,D.download=`forest-workshop-${h.state.settings.worldName}-${v.exportedAt.slice(0,10)}.json`,document.body.append(D),D.click(),D.remove(),setTimeout(()=>URL.revokeObjectURL(R),1e4),e.set({notice:{kind:"info",text:"\uBC31\uC5C5 \uD30C\uC77C\uC744 \uC800\uC7A5\uD588\uC2B5\uB2C8\uB2E4. \uBE44\uBC00\uD0A4\uB294 \uB4E4\uC5B4 \uC788\uC9C0 \uC54A\uC2B5\uB2C8\uB2E4."}})},async selectRestoreFile(h){let v;try{v=JSON.parse(await h.text())}catch{e.set({restore:null,notice:{kind:"error",text:"\uBC31\uC5C5 \uD30C\uC77C\uC744 \uC77D\uC744 \uC218 \uC5C6\uC2B5\uB2C8\uB2E4. JSON \uBC31\uC5C5 \uD30C\uC77C\uC744 \uACE8\uB77C \uC8FC\uC138\uC694."}});return}let N=kt(v);if(!N.ok){e.set({restore:null,notice:{kind:"error",text:N.message}});return}e.set({notice:null,restore:{fileName:h.name,signature:`${h.name}:${h.size}:${h.lastModified}`,backup:v,summary:N.summary}})},cancelRestore(){e.set({restore:null})},async confirmRestore(){let h=e.get().restore;if(!h)return;let v=l("restore",h.signature,Q),N=await c("restore",()=>W.restore(v,h.backup),"\uBC31\uC5C5\uC744 \uBCF5\uC6D0\uD558\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4.");N&&(f(N,N.content),e.set({route:"home",restore:null,notice:{kind:"info",text:`\uBC31\uC5C5\uC744 \uC0C8 \uC138\uACC4 '${N.state.settings.worldName}'(\uC73C)\uB85C \uBCF5\uC6D0\uD588\uC2B5\uB2C8\uB2E4. \uAE30\uC874 \uC138\uACC4\uB294 \uADF8\uB300\uB85C\uC785\uB2C8\uB2E4.`}}))}}}function ee(e){return jt(e.seasonChoice)}function tr(e){return Ye(ee(e)).filter(({path:r})=>e.artReady.includes(r)).map(({flag:r})=>` ${r}`).join("")}function rr(e){return e.route==="residents"?`residents:list:${e.residentsView.page??0}`:e.route==="work"?`work:${e.work.facilityId}:${e.work.section??"status"}:${e.work.queueView??""}:${e.work.queuePage??0}:${e.work.priorityPage??0}`:e.route==="facilities"?`facilities:${e.facilitiesTab}:${e.work.inventoryPage??0}`:e.route==="settings"?`settings:${e.settingsSection??"workshop"}`:e.route==="explore"?`explore:${e.explore?.pairId??""}:${e.explore?.section??"episode"}:${e.explore?.historyPage??0}`:e.route==="invite"?`invite:${e.inviteTab??"invite"}:${e.invitePage??0}`:e.route==="register"?`register:${e.register?.step??1}:${e.register?.panel??"source"}:${e.register?.sourcePage??0}:${e.register?.starterPage??0}`:e.route==="worlds"?`worlds:${e.worldsPage??0}`:e.route}function t(e,r={},a=[]){let i=document.createElement(e);r.className&&(i.className=r.className),r.text!==void 0&&(i.textContent=r.text);for(let[n,o]of Object.entries(r.attrs??{}))o!==void 0&&i.setAttribute(n,o);for(let[n,o]of Object.entries(r.on??{}))o&&i.addEventListener(n,o);r.disabled!==void 0&&"disabled"in i&&(i.disabled=r.disabled);for(let n of a)n==null||n===!1||i.append(typeof n=="string"?document.createTextNode(n):n);return i}function w(e,r,a={}){return t("button",{className:a.variant==="secondary"?"button secondary":"button",text:e,attrs:{type:"button",...a.attrs},disabled:a.disabled,on:{click:r}})}function M(e){return t("p",{className:"muted",text:e,attrs:{role:"status"}})}function Y(e){return t("p",{className:"error",text:e,attrs:{role:"alert"}})}function at(e){return e>=1024*1024?`${(e/(1024*1024)).toFixed(1)}MiB`:e>=1024?`${Math.round(e/1024)}KiB`:`${e}B`}function L(e,r,a,i=""){return t("div",{className:"sheet-backdrop"},[t("section",{className:`sheet card ${i}`.trim(),attrs:{role:"dialog","aria-modal":"true","aria-labelledby":e}},[t("h2",{className:"section-title",text:r,attrs:{id:e}}),...a])])}function se(e,r,a,i,n={}){let o=Math.min(i,Math.max(a,r)),s=t("output",{className:"step-value big",text:String(o),attrs:{id:e,"aria-live":"polite",...n.label?{"aria-label":n.label}:{}}}),l=c=>t("button",{className:"step",text:c>0?`+${c}`:String(c),attrs:{type:"button","aria-label":`${n.label??""} ${c>0?"\uB298\uB9AC\uAE30":"\uC904\uC774\uAE30"} ${Math.abs(c)}`.trim()},on:{click:()=>{o=Math.min(i,Math.max(a,o+c)),s.textContent=String(o),n.onChange?.(o)}}}),d=n.small?[l(-1),s,l(1)]:[l(-10),l(-1),s,l(1),l(10)];return{node:t("div",{className:`stepper wide${n.small?" compact":""}`},d),read:()=>o}}function _(e,r,a,i){if(a.length<=1)return null;let n=Math.max(0,Math.min(r,a.length-1)),o=t("summary",{className:"page-picker-summary",attrs:{"aria-label":e,id:`fw-picker-${encodeURIComponent(e)}`}},[t("span",{text:a[n]}),t("span",{className:"page-picker-arrow",text:"\u25BE",attrs:{"aria-hidden":"true"}})]),s=t("details",{className:"page-picker",on:{keydown:l=>{l.key==="Escape"&&s.open&&(l.preventDefault(),s.open=!1,o.focus())}}},[o,t("div",{className:"page-picker-options"},a.map((l,d)=>t("button",{className:"page-picker-option",text:l,attrs:{type:"button","aria-pressed":String(d===n)},on:{click:()=>{s.open=!1,o.focus(),d!==n&&i(d)}}})))]);return s}function ar(e,r){let a=e.sheet,i=e.world?.state==="ready"?e.world.value:null;if(a?.kind!=="mailbox"||!i)return null;let n=(i.state.mailbox?.letters??[]).filter(d=>d.archived===!!a.archived).slice().sort((d,c)=>c.createdAt.localeCompare(d.createdAt)||d.id.localeCompare(c.id)),o=n.find(d=>d.id===a.id),s=Math.max(0,Math.min(a.page??0,Math.ceil(n.length/4)-1)),l=!!e.busy[`mail:${o?.id}`];return L("fw-mailbox","\uC6B0\uD3B8\uD568",[t("div",{className:"mail-tabs",attrs:{role:"group","aria-label":"\uC6B0\uD3B8 \uBD84\uB958"}},[!1,!0].map(d=>w(d?"\uBCF4\uAD00\uD568":"\uBC1B\uC740 \uD3B8\uC9C0",()=>r.setMailboxView({archived:d,page:0,id:void 0}),{variant:"secondary",attrs:{"aria-pressed":String(!!a.archived===d)}}))),o?t("article",{className:"letter-detail"},[t("h3",{text:o.title}),t("p",{className:"muted",text:`${o.sender} \xB7 ${o.createdAt.slice(0,10)}`}),t("p",{className:"letter-body",text:o.body}),w(o.archived?"\uBC1B\uC740 \uD3B8\uC9C0\uB85C":"\uBCF4\uAD00\uD558\uAE30",()=>{r.archiveLetter(o.id,!o.archived)},{disabled:l}),w("\uBAA9\uB85D\uC73C\uB85C",()=>r.setMailboxView({id:void 0}),{variant:"secondary",disabled:l})]):t("div",{className:"mail-list"},n.length?n.slice(s*4,s*4+4).map(d=>w(`${d.readAt?"\uC77D\uC74C":"\uC0C8 \uD3B8\uC9C0"} \xB7 ${d.sender} \xB7 ${d.title}`,()=>{r.openLetter(d.id)},{variant:"secondary",disabled:!!e.busy[`mail:${d.id}`]})):[t("p",{className:"empty",text:a.archived?"\uBCF4\uAD00\uD55C \uD3B8\uC9C0\uAC00 \uC5C6\uC5B4\uC694.":"\uBC1B\uC740 \uD3B8\uC9C0\uAC00 \uC5C6\uC5B4\uC694."})]),o?null:_("\uD3B8\uC9C0 \uBAA9\uB85D \uACE0\uB974\uAE30",s,Array.from({length:Math.ceil(n.length/4)},(d,c)=>`${c+1} \xB7 ${c*4+1}\u2013${Math.min(n.length,c*4+4)}`),d=>r.setMailboxView({page:d})),w("\uB2EB\uAE30",()=>r.closeSheet(),{variant:"secondary"})])}function ir(e,r){let a=e.sheet,i=e.world?.state==="ready"?e.world.value:null;if(a?.kind!=="guidelines"||!i)return null;let n=a.pairId?i.state.guidelines?.pairs[a.pairId]:i.state.guidelines?.world,o=a.draft??n??{enabled:!1,text:""},s=a.pairId?500:1e3,l=!!e.busy[`guidelines:${a.pairId??"world"}`],d=t("output",{className:"muted",text:`${o.text.length} / ${s}`}),c=t("textarea",{className:"textarea",attrs:{"aria-label":"AI \uC11C\uC220 \uC9C0\uCE68",maxlength:String(s),rows:"6"},on:{input:()=>{d.textContent=`${c.value.length} / ${s}`,g()}}});c.value=o.text;let m=t("input",{attrs:{type:"checkbox","aria-label":"\uC9C0\uCE68 \uC0AC\uC6A9"},on:{change:()=>g()}});m.checked=o.enabled;function g(){r.rememberGuidelines({enabled:m.checked,text:c.value})}return L("fw-guidelines",a.pairId?"\uD398\uC5B4 AI \uC9C0\uCE68":"\uACF5\uBC29 AI \uC9C0\uCE68",[t("p",{className:"muted",text:"\uB9D0\uD22C\xB7\uBD84\uC704\uAE30\xB7\uAD00\uACC4 \uC9C4\uD589 \uC18D\uB3C4\uB97C \uC815\uD574\uC694. \uC8FC\uBBFC\uC774 \uC544\uB294 \uAE30\uC5B5\uC774\uB098 \uBCF4\uC0C1\xB7\uAC8C\uC784 \uADDC\uCE59\uC740 \uBC14\uAFB8\uC9C0 \uC54A\uC544\uC694. \uC774\uBBF8 \uC791\uC131\uD55C \uC774\uC57C\uAE30\uB294 \uADF8\uB300\uB85C\uC608\uC694."}),t("p",{className:"muted",text:a.pairId?"\uC774 \uD398\uC5B4\uC758 \uC0C8 \uC774\uC57C\uAE30\uC5D0\uB9CC \uC801\uC6A9\uB3FC\uC694. \uACF5\uBC29 \uC9C0\uCE68\uBCF4\uB2E4 \uC774 \uD398\uC5B4\uC758 \uC11C\uC220 \uC120\uD638\uB97C \uC6B0\uC120\uD574\uC694.":"\uACF5\uBC29\uC758 \uBAA8\uB4E0 \uC0C8 \uC774\uC57C\uAE30\uC5D0\uC11C \uACF5\uD1B5\uC73C\uB85C \uCC38\uACE0\uD574\uC694."}),t("form",{className:"guidelines-form",on:{submit:f=>{if(f.preventDefault(),m.checked&&!c.value.trim()){r.notify("\uC0AC\uC6A9\uD560 \uC9C0\uCE68\uC744 \uC791\uC131\uD574 \uC8FC\uC138\uC694.");return}let b={enabled:m.checked,text:c.value};r.rememberGuidelines(b),r.saveGuidelines(a.pairId,b)}}},[t("label",{className:"guidelines-toggle"},[m,"\uC9C0\uCE68 \uC0AC\uC6A9"]),c,d,t("p",{className:"muted",text:`\uC800\uC7A5 \uBC84\uC804 ${n?.revision??0} \xB7 ${n?.updatedAt?.slice(0,10)??"\uC544\uC9C1 \uC800\uC7A5\uD558\uC9C0 \uC54A\uC558\uC5B4\uC694"}`}),t("button",{className:"button",text:l?"\uC800\uC7A5 \uC911\u2026":"\uC9C0\uCE68 \uC800\uC7A5",attrs:{type:"submit"},disabled:l}),w("\uCD08\uAE30\uD654",()=>{c.value="",m.checked=!1,d.textContent=`0 / ${s}`,g()},{variant:"secondary",disabled:l})]),w("\uB2EB\uAE30",()=>r.closeSheet(),{variant:"secondary",disabled:l})])}var it={active:"\uC0AC\uC6A9 \uC911",corrected:"\uC815\uC815 \uC804 \uC6D0\uBB38",invalidated:"\uC0AC\uC6A9 \uC911\uC9C0"},Ma={event:"\uC0AC\uAC74",feeling:"\uAC10\uC815",player:"\uD50C\uB808\uC774\uC5B4 \uB2F5\uBCC0"};function nr(e,r){let a=e.sheet,i=e.world?.state==="ready"?e.world.value:null;if(a?.kind!=="memory"||!i)return null;let n=a.pairId?i.state.pairs[a.pairId]:null,o=i.state.memory.facts.filter(y=>!a.pairId||n&&(y.visibility==="public"||n.residentIds.every(u=>y.knowerIds.includes(u)))).filter(y=>!a.status||a.status==="all"||y.status===a.status).filter(y=>!a.residentId||y.visibility==="public"||y.knowerIds.includes(a.residentId)).slice().reverse(),s=o.find(y=>y.factId===a.factId)??o[0],l=Math.max(0,Math.min(a.page??0,Math.ceil(o.length/3)-1)),d=s?!!e.busy[`memory:${s.factId}`]:!1,c=a.draft??s?.text??"",m=y=>{let u=r.store.get().sheet;if(u?.kind==="memory"&&u.draft!==void 0&&u.draft!==s?.text){r.notify("\uC815\uC815\uBB38\uC744 \uC800\uC7A5\uD55C \uB4A4 \uD544\uD130\uB97C \uBC14\uAFD4 \uC8FC\uC138\uC694.");return}r.updateMemoryView({...y,page:0,factId:void 0,draft:void 0})},g=t("select",{className:"input",attrs:{"aria-label":"\uAE30\uC5B5 \uC0C1\uD0DC \uD544\uD130"},on:{change:()=>m({status:g.value})}},[t("option",{text:"\uBAA8\uB4E0 \uC0C1\uD0DC",attrs:{value:"all"}}),...Object.entries(it).map(([y,u])=>t("option",{text:u,attrs:{value:y}}))]);g.value=a.status??"all";let f=t("select",{className:"input",attrs:{"aria-label":"\uAE30\uC5B5 \uC778\uC9C0 \uC8FC\uBBFC \uD544\uD130"},on:{change:()=>m({residentId:f.value})}},[t("option",{text:"\uBAA8\uB4E0 \uC778\uC9C0 \uC8FC\uBBFC",attrs:{value:""}}),...Object.entries(i.state.residents).map(([y,u])=>t("option",{text:u.displayName,attrs:{value:y}}))]);f.value=a.residentId??"";let b=t("textarea",{className:"textarea",attrs:{"aria-label":"\uAE30\uC5B5 \uC815\uC815\uBB38",maxlength:"160",rows:"3"},on:{input:()=>r.rememberMemoryDraft(b.value)}});return b.value=c,L("fw-memory",a.pairId?"\uD398\uC5B4 \uACF5\uC720 \uAE30\uC5B5":"\uAE30\uC5B5 \uAD00\uB9AC",[t("p",{className:"muted",text:a.pairId?"\uB450 \uC8FC\uBBFC\uC774 \uD568\uAED8 \uC544\uB294 \uAE30\uC5B5\uACFC \uACF5\uAC1C \uAE30\uC5B5\uB9CC \uBCF4\uC5EC\uC694. \uC815\uC815\uD574\uB3C4 \uC778\uC9C0 \uBC94\uC704\uB294 \uBC14\uB00C\uC9C0 \uC54A\uC544\uC694.":"\uC138\uACC4 \uAD00\uB9AC\uC790\uB294 \uC804\uCCB4 \uAE30\uC5B5\uC744 \uBCFC \uC218 \uC788\uC5B4\uC694. \uC8FC\uBBFC\uC740 \uC790\uC2E0\uC774 \uC544\uB294 \uAE30\uC5B5\uACFC \uACF5\uAC1C \uAE30\uC5B5\uB9CC \uC0AC\uC6A9\uD574\uC694."}),t("div",{className:"memory-filters"},[g,f]),o.length?t("div",{className:"memory-choices",attrs:{role:"group","aria-label":"\uAE30\uC5B5 \uC120\uD0DD"}},o.slice(l*3,l*3+3).map(y=>w(`#${y.factId} \xB7 ${it[y.status]} \xB7 ${y.text.slice(0,32)}`,()=>{let u=r.store.get().sheet;if(u?.kind==="memory"&&u.draft!==void 0&&u.draft!==s?.text){r.notify("\uC815\uC815\uBB38\uC744 \uC800\uC7A5\uD55C \uB4A4 \uB2E4\uB978 \uAE30\uC5B5\uC744 \uC120\uD0DD\uD574 \uC8FC\uC138\uC694.");return}r.updateMemoryView({factId:y.factId,draft:void 0})},{variant:"secondary",attrs:{"aria-pressed":String(y.factId===s?.factId)}}))):t("p",{className:"empty",text:"\uC544\uC9C1 \uAE30\uB85D\uB41C \uAE30\uC5B5\uC774 \uC5C6\uC5B4\uC694."}),_("\uAE30\uC5B5 \uBAA9\uB85D \uACE0\uB974\uAE30",l,Array.from({length:Math.ceil(o.length/3)},(y,u)=>`${u+1} \xB7 ${u*3+1}\u2013${Math.min(o.length,u*3+3)}`),y=>r.updateMemoryView({page:y})),s?t("section",{className:"memory-detail"},[t("strong",{text:`#${s.factId} \xB7 ${Ma[s.factType]} \xB7 ${it[s.status]}`}),t("p",{text:s.text}),t("p",{className:"muted",text:`\uC544\uB294 \uC8FC\uBBFC: ${s.visibility==="public"?"\uBAA8\uB450":s.knowerIds.map(y=>i.state.residents[y]?.displayName??"\uC8FC\uBBFC").join(", ")}`}),t("p",{className:"muted",text:`${s.occurredAt.slice(0,10)} \xB7 ${s.storyId?`\uCD9C\uCC98 \uC774\uC57C\uAE30 ${s.storyId}`:"\uACF5\uBC29 \uAE30\uB85D"}${s.supersedes?` \xB7 \uC815\uC815 \uC6D0\uBB38 #${s.supersedes}`:""}`}),s.status==="active"?t("form",{on:{submit:y=>{y.preventDefault(),b.value.trim()&&b.value.trim()!==s.text&&r.correctMemory(s.factId,b.value)}}},[t("label",{className:"compare-title",text:"\uAE30\uC5B5 \uC815\uC815\uBB38"}),b,t("p",{className:"muted",text:"\uC6D0\uBB38\uACFC \uCD9C\uCC98\uB294 \uBCF4\uC874\uD558\uBA70 \uB2E4\uC74C \uC0DD\uC131\uBD80\uD130 \uC815\uC815\uBCF8\uC744 \uC0AC\uC6A9\uD574\uC694. \uC774\uBBF8 \uC4F4 \uC774\uC57C\uAE30\uB294 \uBC14\uB00C\uC9C0 \uC54A\uC544\uC694."}),t("button",{className:"button",text:"\uC815\uC815 \uC800\uC7A5",attrs:{type:"submit"},disabled:d})]):null,s.status!=="corrected"?w(s.status==="active"?"\uC0AC\uC6A9 \uC911\uC9C0":"\uB2E4\uC2DC \uC0AC\uC6A9",()=>{r.setMemoryStatus(s.factId,s.status!=="active")},{variant:"secondary",disabled:d}):null]):null,w("\uB2EB\uAE30",()=>r.closeSheet(),{variant:"secondary"})],"memory-sheet")}var nt="http://www.w3.org/2000/svg";function k(e){return(r="icon")=>{let a=document.createElementNS(nt,"svg");a.setAttribute("viewBox","0 0 24 24"),a.setAttribute("aria-hidden","true"),a.setAttribute("focusable","false"),a.setAttribute("class",r);for(let i of e){let n=typeof i=="string"?{d:i}:i,o=n.circle?document.createElementNS(nt,"circle"):document.createElementNS(nt,"path");n.circle?(o.setAttribute("cx",String(n.circle[0])),o.setAttribute("cy",String(n.circle[1])),o.setAttribute("r",String(n.circle[2]))):o.setAttribute("d",n.d??""),n.fill&&o.setAttribute("class","fill"),a.append(o)}return a}}var p={back:k(["M15 5l-7 7 7 7"]),chevron:k(["M9 5l7 7-7 7"]),gear:k([{circle:[12,12,3.2]},"M19.4 13.5l1.6 1.2-2 3.4-1.9-.7a7.6 7.6 0 0 1-2 1.2l-.3 2h-4l-.3-2a7.6 7.6 0 0 1-2-1.2l-1.9.7-2-3.4 1.6-1.2a7.6 7.6 0 0 1 0-3l-1.6-1.2 2-3.4 1.9.7a7.6 7.6 0 0 1 2-1.2l.3-2h4l.3 2a7.6 7.6 0 0 1 2 1.2l1.9-.7 2 3.4-1.6 1.2a7.6 7.6 0 0 1 0 3z"]),lock:k(["M7 11V8a5 5 0 0 1 10 0v3","M5.5 11h13v9h-13z"]),home:k(["M3.5 11.5L12 4l8.5 7.5","M6 10v10h12V10","M10 20v-5h4v5"]),hammer:k(["M14 4l6 6-2.5 2.5-6-6z","M12.5 8.5L4 17l3 3 8.5-8.5"]),compass:k([{circle:[12,12,8.5]},"M15.5 8.5l-2 5-5 2 2-5z"]),residents:k([{circle:[9,9,3.2]},{circle:[16.5,10,2.6]},"M3.5 19c.8-3.2 3-5 5.5-5s4.7 1.8 5.5 5","M14.5 15.5c2.6-.6 5 .8 6 3.5"]),ticket:k(["M4 7h16v3a2 2 0 0 0 0 4v3H4v-3a2 2 0 0 0 0-4z","M10 9.5c1.5 0 3 1 3 2.5s-1.5 2.5-3 2.5"]),mail:k(["M4 6.5h16v11H4z","M4.5 7l7.5 6 7.5-6"]),weather:k(["M7 18h10a3.5 3.5 0 0 0 .4-7A5 5 0 0 0 7.8 10 4 4 0 0 0 7 18z"]),clock:k([{circle:[12,12,8.5]},"M12 7.5V12l3 2"]),info:k([{circle:[12,12,8.5]},"M12 11v5.5","M12 7.6v.4"]),check:k(["M5 12.5l4.5 4.5L19 7.5"]),eye:k(["M2.5 12s3.5-6 9.5-6 9.5 6 9.5 6-3.5 6-9.5 6-9.5-6-9.5-6z",{circle:[12,12,2.8]}]),image:k(["M4 5h16v14H4z",{circle:[9,10,1.6]},"M4.5 17l5-5 4 4 2.5-2.5 3.5 3.5"]),landscape:k(["M4 5h16v14H4z","M4.5 17l5.5-6 4 4 2-2 3.5 4"]),document:k(["M7 3.5h7l4 4V20.5H7z","M14 3.5v4h4","M9.5 12h6","M9.5 15.5h6"]),folder:k(["M3.5 7h6l2 2h9v10h-17z"]),book:k(["M12 6.5c-2-1.3-4.7-1.6-8-1v13c3.3-.6 6-.3 8 1 2-1.3 4.7-1.6 8-1v-13c-3.3-.6-6-.3-8 1z","M12 6.5v13"]),flower:k([{circle:[12,12,2.4]},{circle:[12,6.5,2.6]},{circle:[17.2,10.3,2.6]},{circle:[15.2,16.5,2.6]},{circle:[8.8,16.5,2.6]},{circle:[6.8,10.3,2.6]}]),people:k([{circle:[8,8.5,2.8]},{circle:[16,8.5,2.8]},"M3 19c.6-3 2.5-4.6 5-4.6s4.4 1.6 5 4.6","M11 19c.6-3 2.5-4.6 5-4.6s4.4 1.6 5 4.6"]),pair:k([{circle:[9,12,4.5]},{circle:[15,12,4.5]}]),upload:k(["M12 15.5V4.5","M7.5 9l4.5-4.5L16.5 9","M5 14v5.5h14V14"]),download:k(["M12 4.5v11","M7.5 11l4.5 4.5 4.5-4.5","M5 14v5.5h14V14"]),restore:k(["M4.5 12a7.5 7.5 0 1 0 2.2-5.3","M4.5 4.5v4h4"]),leaf:k(["M5 19c0-8 5-13 14-14-1 9-6 14-14 14z","M5 19l7-7"]),sprout:k(["M12 20v-8","M12 12c0-3.5-2.5-6-6.5-6 0 3.5 2.5 6 6.5 6z","M12 12c0-3.5 2.5-6 6.5-6 0 3.5-2.5 6-6.5 6z"]),search:k([{circle:[10.5,10.5,6]},"M15 15l5 5"]),jar:k(["M8 4.5h8v3H8z","M7 7.5h10l1 3v8a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2v-8z","M9 14h6"]),box:k(["M3.5 8l8.5-4 8.5 4v9l-8.5 4-8.5-4z","M3.5 8l8.5 4 8.5-4","M12 12v9"]),house:k(["M4 11l8-6.5 8 6.5","M6.5 9.5V19h11V9.5","M10.5 19v-4.5h3V19"]),pencil:k(["M15.5 4.5l4 4L9 19H5v-4z","M13.5 6.5l4 4"]),swap:k(["M5 9h12l-3-3","M19 15H7l3 3"]),minus:k(["M6 12h12"]),plus:k(["M6 12h12","M12 6v12"]),grip:k([{circle:[9,7,1.2],fill:!0},{circle:[15,7,1.2],fill:!0},{circle:[9,12,1.2],fill:!0},{circle:[15,12,1.2],fill:!0},{circle:[9,17,1.2],fill:!0},{circle:[15,17,1.2],fill:!0}]),menu:k(["M5 8h14","M5 12h14","M5 16h14"]),filter:k(["M4 5.5h16l-6 7.5v5.5l-4 1.5v-7z"]),heart:k(["M12 19s-7-4.4-7-9.5A4 4 0 0 1 12 7a4 4 0 0 1 7 2.5C19 14.6 12 19 12 19z"]),sparkle:k(["M12 4l1.8 5.2L19 11l-5.2 1.8L12 18l-1.8-5.2L5 11l5.2-1.8z"]),zoom:k([{circle:[10.5,10.5,6]},"M15 15l5 5","M10.5 8v5","M8 10.5h5"]),arrows:k(["M4 12h16","M7.5 8.5L4 12l3.5 3.5","M16.5 8.5L20 12l-3.5 3.5"]),updown:k(["M12 4v16","M8.5 7.5L12 4l3.5 3.5","M8.5 16.5L12 20l3.5-3.5"]),archive:k(["M3.5 5h17v4h-17z","M5 9v10h14V9","M10 13h4"]),berry:k([{circle:[9,13,3.6]},{circle:[15,13,3.6]},{circle:[12,17.5,3.6]},"M12 9.5V5","M12 6.5c1.5-1.8 3.5-2 5-1.5"]),log:k([{circle:[7.5,12,3.8]},"M7.5 8.2h11a3.8 3.8 0 0 1 0 7.6h-11",{circle:[7.5,12,1.3]}]),hourglass:k(["M7 4h10","M7 20h10","M8 4c0 5 8 5 8 8s-8 3-8 8","M16 4c0 5-8 5-8 8s8 3 8 8"]),up:k(["M6 15l6-6 6 6"]),down:k(["M6 9l6 6 6-6"]),addImage:k(["M6 3.5h8l4 4v13H6z","M14 3.5v4h4","M9 16l2.5-3 2 2 1-1.2",{circle:[17.5,17.5,3.5]},"M17.5 16v3","M16 17.5h3"]),acorn:k(["M6 10.5h12a6 6 0 0 1-12 0z","M5.5 10.5c0-3 3-4.5 6.5-4.5s6.5 1.5 6.5 4.5z","M12 6V3.5"]),pinecone:k(["M12 3.5c3.5 3 5 6.5 5 10a5 5 0 0 1-10 0c0-3.5 1.5-7 5-10z","M8 11h8","M7.5 15h9","M10 7.5h4"]),feather:k(["M19 4.5C11 5 6 10 5.5 19.5","M19 4.5c.5 7-4 12-11 12.5","M9 14l4-4"]),pumpkin:k(["M12 7.5c-4.5 0-7 2.8-7 6s2.5 6 7 6 7-2.8 7-6-2.5-6-7-6z","M12 7.5v12","M12 7.5c0-2 1-3.5 2.5-4"]),candle:k(["M9 9.5h6v10.5H9z","M12 9.5V7","M12 3.5c1.3 1.3 1.3 2.7 0 3.5-1.3-.8-1.3-2.2 0-3.5z"]),cup:k(["M5 9h11v5a5 5 0 0 1-5 5h-1a5 5 0 0 1-5-5z","M16 10.5h1.5a2.5 2.5 0 0 1 0 5H16","M9 4.5c0 1.5 1 1.5 1 3","M12.5 4.5c0 1.5 1 1.5 1 3"]),cake:k(["M5 12h14v8H5z","M5 15.5c2.3 1.4 4.7 1.4 7 0s4.7-1.4 7 0","M12 12V8.5",{circle:[12,6.5,1.4]}]),scarf:k(["M6 5h12v5H6z","M13 10v9l3-1V10","M8 7.5h1M11 7.5h1M14 7.5h1"]),wheat:k(["M12 20.5V7","M12 7c-2 0-3-1.5-3-3.5 2 0 3 1.5 3 3.5zM12 7c2 0 3-1.5 3-3.5-2 0-3 1.5-3 3.5z","M12 12c-2 0-3-1.5-3-3.5 2 0 3 1.5 3 3.5zM12 12c2 0 3-1.5 3-3.5-2 0-3 1.5-3 3.5z","M12 17c-2 0-3-1.5-3-3.5 2 0 3 1.5 3 3.5zM12 17c2 0 3-1.5 3-3.5-2 0-3 1.5-3 3.5z"]),clover:k([{circle:[9.5,9.5,2.8]},{circle:[14.5,9.5,2.8]},{circle:[9.5,14.5,2.8]},{circle:[14.5,14.5,2.8]},"M14 17l3.5 4"]),spool:k(["M7 4.5h10","M7 19.5h10","M9 4.5v15","M15 4.5v15","M9 8l6 3M9 12l6 3"]),mushroom:k(["M4.5 12a7.5 7.5 0 0 1 15 0z","M10 12v6.5a2 2 0 0 0 4 0V12"])};var Pa={"wild-berry":p.berry,herb:p.leaf,wood:p.log,pinecone:p.pinecone,acorn:p.acorn,wheat:p.wheat,flower:p.flower,pumpkin:p.pumpkin,cotton:p.weather,"tea-leaf":p.sprout,honey:p.jar,mushroom:p.mushroom,beeswax:p.box,feather:p.feather,clover:p.clover,"berry-jam":p.jar,"dried-herb":p.leaf,flour:p.box,plank:p.log,thread:p.spool,"herb-tea":p.cup,"pumpkin-puree":p.pumpkin,"acorn-flour":p.acorn,"herb-sachet":p.heart,"berry-pie":p.cake,"wooden-tray":p.log,"beeswax-candle":p.candle,"knit-scarf":p.scarf,"flower-wreath":p.flower,"pumpkin-soup":p.cup,"honey-cake":p.cake,birdhouse:p.house,"acorn-cookie":p.acorn,"tea-gift":p.clover},re={gather:"\uCC44\uC9D1",grow:"\uC7AC\uBC30",survey:"\uC870\uC0AC",process:"\uAC00\uACF5",craft:"\uC81C\uC791"},fe={gather:p.leaf,grow:p.sprout,survey:p.search,process:p.jar,craft:p.hammer};function B(e,r){return e?.items.find(a=>a.id===r)?.name??r}function Ea(e,r="icon"){return(Pa[e]??p.box)(r)}function j(e,r="small"){return t("span",{className:`item-tile ${r} item-${e}`,attrs:{"aria-hidden":"true"}},[E(Dt(e),{className:"item-art",lazy:!0,fallback:()=>Ea(e,"icon")})])}function Ne(e,r="big"){return E(Bt[e]??null,{className:`facility-image ${r}`,fallback:()=>p.house(`icon ${r}`)})}function X(e,r){return e?.recipes.find(a=>a.id===r)??null}function te(e,r){return e?.facilities.find(a=>a.id===r)??null}function de(e){let r=Math.max(0,Math.ceil(e/1e3)),a=Math.floor(r/3600),i=Math.floor(r%3600/60),n=r%60,o=s=>String(s).padStart(2,"0");return a?`${a}:${o(i)}:${o(n)}`:`${o(i)}:${o(n)}`}function Se(e){let r=e/36e5;return r>=10||Number.isInteger(r)?`${Math.floor(r)}`:r.toFixed(1)}function or(e,r,a,i=0){return Math.max(6e4,Math.round(r.minutes*6e4/(1+e.production.speedBonusPerLevel*(a-1)+i)))}function ie(e,r){let a=Math.min(e.crew.maxBreakthrough,Math.max(0,r));return Math.round((e.crew.passiveBase+e.crew.passivePerBreakthrough*a)*1e3)/1e3}function ne(e,r,a){let i=new Set(Object.values(r.production.facilities).map(g=>g.residentId).filter(g=>g!==null)),n=Object.values(r.pairs).filter(g=>!g.archived&&g.residentIds.every(f=>i.has(f))).length,o=Math.min(e.crew.setBonusMax,Math.round(e.crew.setBonusPerPair*n*1e3)/1e3),s=r.production.facilities[a]?.residentId??null,l=s?r.residents[s]:void 0,d=l!==void 0&&l.field===te(e,a)?.field,c=d?ie(e,l.breakthrough):0,m=d?oe(e,l.talentId)??null:null;return{resident:l??null,matches:d,passive:c,set:o,talent:m,total:Math.round((c+o)*1e3)/1e3}}function oe(e,r){return e?.talents.find(a=>a.id===r)}function Le(e,r){let a={...e.inputs},i=r.total,n=r.talent?.effect,o=!1;return n&&n.recipeId===e.id&&(o=!0,n.kind==="speed"?i+=n.bonus:a[n.itemId]!==void 0&&(a[n.itemId]=Math.max(1,a[n.itemId]-n.amount))),{extraBonus:Math.round(i*1e3)/1e3,inputs:a,talentApplies:o}}function q(e){return`${Math.round(e*1e3)/10}%`}function sr(e,r,a){let i=te(e,a)?.unlock;if(!i)return[];let n=[];if(i.facilityLevel){let o=r.production.facilities[i.facilityLevel.facilityId],s=o?.unlocked?o.level:0,l=i.facilityLevel.level,d=te(e,i.facilityLevel.facilityId)?.name??"";n.push({text:`${d} Lv. ${l} \uC774\uC0C1`,have:s,need:l,met:s>=l})}if(i.made){let o=r.production.made[i.made.itemId]??0,s=i.made.amount;n.push({text:`${B(e,i.made.itemId)} ${s}\uAC1C \uB9CC\uB4E4\uAE30`,have:o,need:s,met:o>=s})}return n}function lr(e,r){return e.production.queueSlotLevels.filter(a=>r>=a).length}function ot(e,r){return Math.round((e?.production.speedBonusPerLevel??0)*(r-1)*100)}function Ta(e,r,a){return e.worldReceivedAt+(a.endsSim-r.state.production.simMs)}function he(e,r,a){let i=Ta(e,r,a),n=a.endsSim-a.startedSim,o=t("span",{className:"bar-fill",attrs:{"data-progress-end":String(i),"data-progress-total":String(n)}}),s=Math.max(0,i-Date.now());return o.style.width=`${Math.round((n-s)/Math.max(1,n)*100)}%`,{bar:t("span",{className:"bar teal"},[o]),countdown:t("span",{className:"countdown",text:de(s),attrs:{"data-countdown-end":String(i)}})}}function dr(e,r){if(!r)return"";if(r.reason==="no_rules")return"\uCF1C \uB454 \uC6B4\uC601 \uADDC\uCE59\uC774 \uC5C6\uC5B4 \uC26C\uACE0 \uC788\uC5B4\uC694.";if(r.reason==="target_reached")return"\uBAA8\uB4E0 \uBAA9\uD45C \uC7AC\uACE0\uB97C \uCC44\uC6CC \uC26C\uACE0 \uC788\uC5B4\uC694. \uC7AC\uACE0\uAC00 \uC904\uBA74 \uB2E4\uC2DC \uC2DC\uC791\uD574\uC694.";if(r.reason==="queue_empty")return"\uC9C0\uC815 \uD69F\uC218 \uB300\uAE30\uC5F4\uC774 \uBE44\uC5B4 \uC26C\uACE0 \uC788\uC5B4\uC694.";if(r.reason==="locked")return"\uC544\uC9C1 \uC5F4\uB9AC\uC9C0 \uC54A\uC740 \uC2DC\uC124\uC774\uC5D0\uC694.";let a=B(e,r.itemId??""),i=r.protectedAmount?` (\uBCF4\uD638 ${r.protectedAmount}\uAC1C\uB294 \uC4F0\uC9C0 \uC54A\uC544\uC694)`:"";return`${a}\uC774(\uAC00) \uBD80\uC871\uD574 \uAE30\uB2E4\uB9AC\uB294 \uC911: \uD55C \uBC88\uC5D0 ${r.needed??"?"}\uAC1C \uD544\uC694, \uC4F8 \uC218 \uC788\uB294 \uC591 ${r.usable??0}\uAC1C${i}.`}function Wa(e,r,a,i,n){let o=e.content,s=c=>Math.max(0,(r.state.inventory[c]??0)-(r.state.production.protectedStock[c]??0)),l=Object.entries(a.items).every(([c,m])=>s(c)>=m),d=!!e.busy[`deliver:${a.id}`];return t("div",{className:`order${i?" done":""}`},[t("strong",{className:"order-title",text:a.title}),t("ul",{className:"order-items"},Object.entries(a.items).map(([c,m])=>{let g=r.state.inventory[c]??0,f=r.state.production.protectedStock[c]??0;return t("li",{className:s(c)>=m?"enough":"short"},[j(c),t("span",{text:`${B(o,c)} ${s(c)}/${m}`}),f?t("small",{className:"muted",text:`\uBCF4\uC720 ${g} \xB7 \uBCF4\uD638 ${f}`}):null])})),t("p",{className:"order-reward"},[p.ticket("icon tiny"),` \uCD08\uB300\uAD8C ${a.reward.tickets}\uC7A5 \xB7 ${a.reward.gold} G`]),i?t("span",{className:"status-pill done",text:"\uB0A9\uD488 \uC644\uB8CC"}):w(d?"\uB0A9\uD488\uD558\uB294 \uC911\u2026":l?"\uB0A9\uD488\uD558\uAE30":"\uC7AC\uB8CC\uAC00 \uBD80\uC871\uD574\uC694",()=>{n.deliver(a.id)},{disabled:d||!l,variant:l?void 0:"secondary"})])}function za(e,r,a,i,n){let o=e.sheet?.kind==="deliveries"?e.sheet.selectedOrderId:void 0,s=a.find(l=>l.id===o)??a.find(l=>!i.includes(l.id))??a[0];return s?t("div",{className:"delivery-board"},[t("div",{className:"delivery-choices",attrs:{role:"group","aria-label":"\uB0A9\uD488 \uC758\uB8B0 \uC120\uD0DD"}},a.map(l=>{let d=Object.keys(l.items)[0]??"";return t("button",{className:`delivery-choice${l.id===s.id?" selected":""}`,attrs:{type:"button","aria-pressed":l.id===s.id?"true":"false","aria-label":`${l.title}${i.includes(l.id)?" \uB0A9\uD488 \uC644\uB8CC":""}`},on:{click:()=>n.selectDelivery(l.id)}},[j(d),t("span",{text:l.title}),t("small",{text:i.includes(l.id)?"\uC644\uB8CC":`\uCD08\uB300\uAD8C ${l.reward.tickets} \xB7 ${l.reward.gold} G`})])})),Wa(e,r,s,i.includes(s.id),n)]):t("p",{className:"empty",text:"\uC624\uB298\uC758 \uC758\uB8B0\uAC00 \uC5C6\uC5B4\uC694."})}function cr(e,r){let a=e.world?.state==="ready"?e.world.value:null,i=e.deliveries,n=!a||!i||i.state==="loading"?[M("\uC624\uB298\uC758 \uB0A9\uD488 \uC758\uB8B0\uB97C \uBD88\uB7EC\uC624\uB294 \uC911\u2026")]:i.state==="error"?[Y(i.message)]:[t("p",{className:"muted",text:"\uC758\uB8B0\uB294 \uD558\uB8E8(UTC \uAE30\uC900)\uB9C8\uB2E4 \uBC14\uB00C\uC5B4\uC694. \uC9C0\uB09C \uB0A0\uC758 \uC758\uB8B0\uB294 \uBAA8\uC544 \uB450\uC9C0 \uC54A\uC544\uC694. \uBCF4\uD638\uD55C \uC7AC\uACE0\uB294 \uB0A9\uD488\uD558\uC9C0 \uC54A\uC544\uC694."}),za(e,a,i.value.orders,i.value.done,r)];return L("fw-deliveries","\uCD08\uB300\uAD8C \uBC1B\uAE30 \xB7 \uC624\uB298\uC758 \uB0A9\uD488",[...n,w("\uB2EB\uAE30",()=>r.closeSheet(),{variant:"secondary",attrs:{"data-wide":""}})])}function st(e){return t("span",{className:"lock-tag",attrs:{"aria-hidden":"true"}},[p.lock("icon tiny"),"\uC900\uBE44 \uC911"])}function mr(e,r,a){let i=Me(r)||!a.onOpen;return t("button",{className:`${a.className}${i?" is-locked":""}`,attrs:{type:"button","aria-label":i?`${a.label} (\uC900\uBE44 \uC911)`:a.label},on:{click:()=>i?e.notifyLocked(r):a.onOpen?.()}},[...a.children,i?st(r):null])}var La=[{label:"\uD648",icon:p.home,art:pe.home,routes:["home","settings","backup","diagnostics"]},{label:"\uC791\uC5C5",icon:p.hammer,art:pe.work,routes:["work","facilities"]},{label:"\uD0D0\uC0AC",icon:p.compass,art:pe.explore,routes:["explore","story"]},{label:"\uC8FC\uBBFC",icon:p.residents,art:pe.residents,routes:["residents","relations","resident-image"]},{label:"\uCD08\uB300",icon:p.ticket,art:pe.invite,routes:["invite"]}];function pr(e,r){return t("nav",{className:"tabbar",attrs:{"aria-label":"\uACF5\uBC29 \uBA54\uB274"}},La.map(a=>{let i=a.feature?Me(a.feature):!1,n=a.routes.includes(e.route);return t("button",{className:`tab${n?" current":""}${i?" is-locked":""}`,attrs:{type:"button","aria-current":n?"page":void 0,"aria-label":i?`${a.label} (\uC900\uBE44 \uC911)`:a.label},on:{click:()=>{i&&a.feature?r.notifyLocked(a.feature):a.routes[0]==="residents"?r.openResidents():a.routes[0]&&r.navigate(a.routes[0])}}},[t("span",{className:"tab-icon"},[E(a.art,{className:"tab-glyph tab-art",fallback:()=>a.icon("icon tab-glyph")}),i&&a.feature?st(a.feature):null]),t("span",{className:"tab-label",text:a.label})])}))}function ja(e,r){let i=(e.world?.state==="ready"?e.world.value:null)?.state.wallet.tickets??0;return t("button",{className:"counter ticket",attrs:{type:"button","aria-label":`\uCD08\uB300\uAD8C ${i}\uC7A5 \u2014 \uCD08\uB300\uAD8C \uBC1B\uAE30`},on:{click:()=>r.openDeliveries()}},[t("span",{className:"ticket-mark"},[p.ticket("icon")]),t("span",{className:"counter-value",text:String(i)})])}function ur(e,r){let a=e.world?.state==="ready"?e.world.value:null;if(!a)return null;let i=a.state.wallet.gold.toLocaleString("ko-KR");return t("div",{className:"resources"},[t("span",{className:"counter gold",attrs:{"aria-label":`\uACE8\uB4DC ${i}`}},[t("span",{className:"coin",attrs:{"aria-hidden":"true"}}),t("span",{className:"counter-value",text:i})]),ja(e,r),e.route==="settings"?null:t("button",{className:"icon-button gear",attrs:{type:"button","aria-label":"\uC124\uC815"},on:{click:()=>r.navigate("settings")}},[p.gear()])])}function gr(e,r,a){if(a.kind==="home"){let n=e.world?.state==="ready"&&(e.world.value.state.mailbox?.letters.some(s=>!s.readAt&&!s.archived)??!1),o=Z(e.weatherEffects);return t("header",{className:"top top-home"},[t("div",{className:"top-row"},[t("h1",{className:"sign sign-home",attrs:{id:"fw-screen-title"}},[t("span",{className:"sign-title",text:"\uC232\uACB0 \uACF5\uBC29"})]),ur(e,r)]),t("div",{className:"top-row second"},[t("div",{className:"season-weather"},[t("span",{className:"season-badge",text:xe[ee(e)],attrs:{"aria-label":`\uD604\uC7AC \uACC4\uC808 ${xe[ee(e)]}`}}),t("button",{className:"chip-button weather",attrs:{type:"button","aria-label":`\uB0A0\uC528 \uC5F0\uCD9C ${o.enabled?ve[o.kind]:"\uAEBC\uC9D0"} \u2014 \uC124\uC815`},on:{click:()=>{r.setSettingsSection("display"),r.navigate("settings")}}},[p.weather(),t("span",{text:o.enabled?ve[o.kind]:"\uD6A8\uACFC \uAEBC\uC9D0"})])]),t("button",{className:"icon-button mail",attrs:{type:"button","aria-label":n?"\uC6B0\uD3B8\uD568 \xB7 \uC0C8 \uD3B8\uC9C0 \uC788\uC74C":"\uC6B0\uD3B8\uD568"},on:{click:()=>r.openMailbox()}},[p.mail(),n?t("span",{className:"mail-new",attrs:{"aria-hidden":"true"}},[p.sparkle("icon tiny")]):null])])])}let i=a.back;return t("header",{className:`top top-sub${a.resources||a.counters?" with-resources":""}`},[t("div",{className:"top-row"},[i?t("button",{className:"back-button",attrs:{type:"button","aria-label":`${i.label}(\uC73C)\uB85C \uB3CC\uC544\uAC00\uAE30`},on:{click:()=>r.navigate(i.route)}},[p.back()]):t("span",{className:"back-spacer",attrs:{"aria-hidden":"true"}}),t("h1",{className:"sign",attrs:{id:"fw-screen-title"}},[t("span",{className:"sign-title",text:a.title})]),a.resources?ur(e,r):a.counters??null]),a.subtitle?t("p",{className:"ribbon",text:a.subtitle}):null])}function Oa(e,r){return e.notice?t("div",{className:`notice ${e.notice.kind}`,attrs:{role:e.notice.kind==="error"?"alert":"status"}},[t("p",{text:e.notice.text}),t("button",{className:"notice-close",text:"\uB2EB\uAE30",attrs:{type:"button","aria-label":"\uC54C\uB9BC \uB2EB\uAE30"},on:{click:()=>r.dismissNotice()}})]):null}function P(e,r,a){return t("div",{className:`shell backdrop-${a.backdrop} season-${ee(e)}${tr(e)}${a.nav?" has-nav":""}${a.homeLayout?" home-layout":""}${a.storyLayout?" story-layout":""}${e.notice?" has-notice":""}`},[t("div",{className:"scroll"},[t("div",{className:"column"},[gr(e,r,a.top),a.hero??null,t("main",{className:"page",attrs:{"aria-labelledby":"fw-screen-title"}},a.body)])]),Oa(e,r),a.nav?pr(e,r):null,a.sheet??(e.sheet?.kind==="mailbox"?ar(e,r):e.sheet?.kind==="guidelines"?ir(e,r):e.sheet?.kind==="memory"?nr(e,r):e.sheet?.kind==="deliveries"?cr(e,r):null)])}function C(e,r,a={}){return t("section",{className:`card ${a.className??""}`.trim(),attrs:a.id?{"aria-labelledby":a.id}:{}},[e?t("h2",{className:"section-title",text:e,attrs:a.id?{id:a.id}:{}}):null,...r])}var je="/forest-workshop/p0",Va={pass:"\uD1B5\uACFC",fail:"\uC2E4\uD328",unavailable:"\uC0AC\uC6A9 \uBD88\uAC00"};function I(e,r={},a=[]){let i=document.createElement(e);r.className&&(i.className=r.className),r.text!==void 0&&(i.textContent=r.text);for(let[n,o]of Object.entries(r.attrs??{}))i.setAttribute(n,o);for(let n of a)n&&i.append(n);return i}var Oe=class{constructor(){T(this,"node",I("div",{className:"diagnostics"}));T(this,"started",!1);T(this,"status",{state:"loading"});T(this,"probe",null);T(this,"image",{state:"loading"});T(this,"uploading",!1);T(this,"uploadError",null);T(this,"pendingUpload",null)}start(){this.started||(this.started=!0,this.render(),this.loadStatus(),this.loadImage())}async loadStatus(){this.status={state:"loading"},this.render();try{this.status={state:"ready",value:await z().get(`${je}/status`)}}catch(r){this.status={state:"error",message:F(r,"\uD328\uD0A4\uC9C0 \uC0C1\uD0DC\uB97C \uBD88\uB7EC\uC624\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4.")}}this.render()}async loadImage(){this.image={state:"loading"},this.render();try{let r=await z().get(`${je}/image`);this.image={state:"ready",value:r.current}}catch(r){this.image={state:"error",message:F(r,"\uC800\uC7A5\uB41C \uADF8\uB9BC\uC744 \uBD88\uB7EC\uC624\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4.")}}this.render()}async runProbe(){if(this.probe?.state!=="loading"){this.probe={state:"loading"},this.render();try{let r=await z().post(`${je}/probe`);this.probe={state:"ready",value:r.checks}}catch(r){this.probe={state:"error",message:F(r,"\uC5F0\uACB0 \uC810\uAC80\uC744 \uC2E4\uD589\uD558\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4.")}}this.render()}}async upload(r){if(this.uploading)return;let a=this.pendingUpload?.file===r?this.pendingUpload:{file:r,key:Ae()};this.pendingUpload=a,this.uploading=!0,this.uploadError=null,this.render();try{let i=new FormData;i.append("uploadKey",a.key),i.append("file",r,r.name);let n=await z().upload(`${je}/image`,i);this.image={state:"ready",value:n.image},this.pendingUpload=null}catch(i){this.uploadError=F(i,"\uADF8\uB9BC\uC744 \uC62C\uB9AC\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4. \uAE30\uC874 \uADF8\uB9BC\uC740 \uADF8\uB300\uB85C\uC785\uB2C8\uB2E4.")}finally{this.uploading=!1,this.render()}}render(){this.node.replaceChildren(I("p",{className:"muted",text:"\uC5D4\uC9C4 \uC5F0\uACB0\uACFC \uC8FC\uBBFC \uADF8\uB9BC \uC800\uC7A5 \uACBD\uB85C\uB97C \uD655\uC778\uD569\uB2C8\uB2E4. \uACB0\uACFC\uB294 \uC138\uACC4\uC5D0 \uC601\uD5A5\uC744 \uC8FC\uC9C0 \uC54A\uC2B5\uB2C8\uB2E4."}),this.renderStatus(),this.renderProbe(),this.renderImage())}retryButton(r,a){let i=I("button",{className:"button secondary",text:r,attrs:{type:"button"}});return i.addEventListener("click",a),i}renderStatus(){let r=I("section",{className:"card",attrs:{"aria-labelledby":"fw-status"}},[I("h2",{text:"\uC5D4\uC9C4 \uC5F0\uACB0",attrs:{id:"fw-status"}})]);if(this.status.state==="loading")r.append(I("p",{className:"muted",text:"\uBD88\uB7EC\uC624\uB294 \uC911\u2026",attrs:{role:"status"}}));else if(this.status.state==="error")r.append(I("p",{className:"error",text:this.status.message,attrs:{role:"alert"}}),this.retryButton("\uB2E4\uC2DC \uC2DC\uB3C4",()=>{this.loadStatus()}));else{let{value:a}=this.status;r.append(I("p",{className:"muted",text:`\uD328\uD0A4\uC9C0 ${a.version} \xB7 \uB2E8\uACC4 ${a.stage}`}),I("ul",{className:"list"},a.host.map(i=>I("li",{className:"row"},[I("span",{className:"name",text:i.name}),I("span",{className:`badge ${i.available?"pass":i.required?"fail":"unavailable"}`,text:i.available?"\uC788\uC74C":i.required?"\uC5C6\uC74C (\uD544\uC218)":"\uC5C6\uC74C"})]))))}return r}renderProbe(){let r=I("button",{className:"button",text:this.probe?.state==="loading"?"\uC810\uAC80 \uC911\u2026":"\uC5F0\uACB0 \uC810\uAC80 \uC2E4\uD589",attrs:{type:"button"}});r.disabled=this.probe?.state==="loading",r.addEventListener("click",()=>{this.runProbe()});let a=I("section",{className:"card",attrs:{"aria-labelledby":"fw-probe"}},[I("h2",{text:"\uC800\uC7A5\xB7\uC790\uB8CC\xB7\uBAA8\uB378 \uC810\uAC80",attrs:{id:"fw-probe"}}),I("p",{className:"muted",text:"\uC784\uC2DC \uBB38\uC11C\uB97C \uC4F0\uACE0 \uC9C0\uC6C1\uB2C8\uB2E4. \uCE90\uB9AD\uD130\xB7\uD398\uB974\uC18C\uB098 \uC6D0\uBCF8\uC740 \uC77D\uAE30\uB9CC \uD558\uBA70, \uBAA8\uB378 \uC0DD\uC131 \uC694\uCCAD\uC740 \uBCF4\uB0B4\uC9C0 \uC54A\uC2B5\uB2C8\uB2E4."}),r]);return!this.probe||this.probe.state==="loading"?a:this.probe.state==="error"?(a.append(I("p",{className:"error",text:this.probe.message,attrs:{role:"alert"}})),a):(a.append(I("ul",{className:"list",attrs:{"aria-live":"polite"}},this.probe.value.map(i=>I("li",{className:"row stacked"},[I("div",{className:"row-head"},[I("span",{className:"name",text:i.label}),I("span",{className:`badge ${i.status}`,text:Va[i.status]})]),I("span",{className:"detail",text:i.detail})])))),a)}renderImage(){let r=I("input",{className:"file",attrs:{type:"file",accept:"image/png,image/webp",id:"fw-file"}});r.disabled=this.uploading,r.addEventListener("change",()=>{let i=r.files?.[0];i&&this.upload(i)});let a=I("section",{className:"card",attrs:{"aria-labelledby":"fw-image"}},[I("h2",{text:"\uC8FC\uBBFC \uADF8\uB9BC \uC800\uC7A5 \uC810\uAC80",attrs:{id:"fw-image"}}),I("p",{className:"muted",text:"PNG \uB610\uB294 \uC815\uC801 WebP(\uCD5C\uB300 20MiB, 4096\xD74096)\uB97C \uACE0\uB974\uBA74 \uD22C\uBA85\uB3C4\uB97C \uC720\uC9C0\uD55C WebP \uD488\uC9C895\uB85C \uBC14\uAFD4 \uC804\uC5ED \uAC24\uB7EC\uB9AC\uC5D0 \uC800\uC7A5\uD569\uB2C8\uB2E4. PNG \uC6D0\uBCF8\uC740 \uBCF4\uAD00\uD558\uC9C0 \uC54A\uC2B5\uB2C8\uB2E4."}),I("label",{className:"field-label",text:"\uADF8\uB9BC \uD30C\uC77C \uACE0\uB974\uAE30",attrs:{for:"fw-file"}}),r]);if(this.uploading&&a.append(I("p",{className:"muted",text:"\uBCC0\uD658\uD558\uACE0 \uC800\uC7A5\uD558\uB294 \uC911\u2026",attrs:{role:"status"}})),this.uploadError){a.append(I("p",{className:"error",text:this.uploadError,attrs:{role:"alert"}}));let i=this.pendingUpload;i&&!this.uploading&&a.append(this.retryButton("\uAC19\uC740 \uD30C\uC77C\uB85C \uB2E4\uC2DC \uC2DC\uB3C4",()=>{this.upload(i.file)}))}if(this.image.state==="loading")a.append(I("p",{className:"muted",text:"\uBD88\uB7EC\uC624\uB294 \uC911\u2026",attrs:{role:"status"}}));else if(this.image.state==="error")a.append(I("p",{className:"error",text:this.image.message,attrs:{role:"alert"}}),this.retryButton("\uB2E4\uC2DC \uBD88\uB7EC\uC624\uAE30",()=>{this.loadImage()}));else if(!this.image.value)a.append(I("p",{className:"empty",text:"\uC544\uC9C1 \uC800\uC7A5\uB41C \uADF8\uB9BC\uC774 \uC5C6\uC2B5\uB2C8\uB2E4."}));else{let i=this.image.value,n=I("img",{className:"preview",attrs:{src:`${i.url}${i.url.includes("?")?"&":"?"}v=${i.imageVersion}`,alt:"\uC800\uC7A5\uB41C \uC8FC\uBBFC \uADF8\uB9BC \uBBF8\uB9AC\uBCF4\uAE30",width:String(i.width),height:String(i.height)}});a.append(I("div",{className:"stage"},[n]),I("dl",{className:"facts"},[I("dt",{text:"\uCC38\uC870"}),I("dd",{text:i.reference}),I("dt",{text:"\uD06C\uAE30"}),I("dd",{text:`${i.width}\xD7${i.height}`}),I("dt",{text:"\uC6A9\uB7C9"}),I("dd",{text:`\uC785\uB825 ${at(i.inputBytes)} \u2192 WebP ${at(i.outputBytes)}`}),I("dt",{text:"\uD22C\uBA85\uB3C4"}),I("dd",{text:i.hasTransparency?"\uD22C\uBA85 \uC601\uC5ED \uC788\uC74C (\uC720\uC9C0\uB428)":"\uBD88\uD22C\uBA85 \uADF8\uB9BC"}),I("dt",{text:"\uBC84\uC804"}),I("dd",{text:String(i.imageVersion)})]))}return a}};function be(e){return!!e.groundEditingWorld&&e.world?.state==="ready"&&e.groundEditingWorld===e.world.value.worldId}function fr(e,r,a){if(e.world?.state!=="ready")return null;let i=e.world.value,n={...e.settingsGroundDraft?.worldId===i.worldId?e.settingsGroundDraft.value:i.state.settings.ground},o=t("div",{className:"ground-overlay",attrs:{"aria-label":"\uD648 \uC774\uB3D9\uC601\uC5ED \uD3B8\uC9D1"}}),s=t("div",{className:"ground-selection"},[t("span",{className:"ground-caption",text:"\uC8FC\uBBFC \uC774\uB3D9 \uAC00\uB2A5 \uC601\uC5ED"})]),l=()=>{let d=`left:${n.left}%;top:${n.top}%;width:${n.right-n.left}%;height:${n.bottom-n.top}%;`;s.style.cssText=d,a&&(a.style.cssText=d+"right:auto;bottom:auto;padding:0;")};for(let[d,c]of[["left","\uC67C\uCABD"],["right","\uC624\uB978\uCABD"],["top","\uC704\uCABD"],["bottom","\uC544\uB798\uCABD"]]){let m=t("button",{className:`ground-handle ${d}`,text:d==="left"||d==="right"?"\u2194":"\u2195",attrs:{type:"button","aria-label":`\uC774\uB3D9\uC601\uC5ED ${c} \uACBD\uACC4 \uC870\uC808`}}),g=f=>{let b=d==="left"?0:d==="right"?n.left+20:d==="top"?35:Math.max(55,n.top+10),y=d==="left"?n.right-20:d==="right"?100:d==="top"?Math.min(85,n.bottom-10):100;n[d]=Math.round(Math.max(b,Math.min(y,f))),r.rememberGround(i.worldId,n),m.setAttribute("aria-label",`\uC774\uB3D9\uC601\uC5ED ${c} \uACBD\uACC4 ${n[d]}%`),l()};m.addEventListener("pointerdown",f=>{f.button===0&&(f.preventDefault(),m.setPointerCapture(f.pointerId))}),m.addEventListener("pointermove",f=>{if(!m.hasPointerCapture(f.pointerId))return;let b=o.getBoundingClientRect();!b.width||!b.height||g(d==="left"||d==="right"?(f.clientX-b.left)/b.width*100:(f.clientY-b.top)/b.height*100)}),m.addEventListener("pointerup",f=>{m.hasPointerCapture(f.pointerId)&&m.releasePointerCapture(f.pointerId)}),m.addEventListener("keydown",f=>{let b=f.key==="ArrowLeft"||f.key==="ArrowUp"?-1:f.key==="ArrowRight"||f.key==="ArrowDown"?1:0;b&&(f.preventDefault(),g(n[d]+b))}),s.append(m)}return o.append(s),l(),o}function hr(e,r){let a=e.world?.state==="ready"?e.world.value:null;if(!a)return null;let i=!!e.busy["ground-save"];return t("div",{className:"ground-actions"},[t("p",{text:"\uBC30\uACBD \uC704 \uACBD\uACC4\uB97C \uB04C\uC5B4 \uC8FC\uBBFC\uC774 \uB2E4\uB2D0 \uACF3\uC744 \uC815\uD574 \uC8FC\uC138\uC694. \uC800\uC7A5 \uC804\uC5D0\uB294 \uC801\uC6A9\uB418\uC9C0 \uC54A\uC544\uC694."}),t("div",{className:"ground-action-row"},[w("\uAE30\uBCF8 \uBC94\uC704",()=>r.resetGroundEditor(),{variant:"secondary",disabled:i}),w("\uCDE8\uC18C",()=>r.cancelGroundEditor(),{variant:"secondary",disabled:i}),w(i?"\uC800\uC7A5 \uC911\u2026":"\uC800\uC7A5",()=>{r.saveGround(r.store.get().settingsGroundDraft?.value??a.state.settings.ground)},{disabled:i})])])}var Ba="http://www.w3.org/2000/svg";function br(e){let r=document.createElementNS(Ba,"svg");return r.setAttribute("viewBox","0 0 60 80"),r.setAttribute("aria-hidden","true"),r.setAttribute("class",e),r.innerHTML='<circle cx="30" cy="24" r="15"/><path d="M6 80c0-17 11-29 24-29s24 12 24 29z"/>',r}function wr(e,r){let a=e.image.current;return t("img",{className:r,attrs:{src:`${a.url}${a.url.includes("?")?"&":"?"}v=${encodeURIComponent(a.reference)}`,alt:"",width:String(a.width),height:String(a.height),decoding:"async",draggable:"false"}})}function lt(e){return{bottom:Math.max(15,Math.min(82,4+e.scale*.9-12+e.markerHeight*.4)),left:Math.max(10,Math.min(90,50+e.offsetX*.5))}}function J(e,r={}){let a=r.placement??e.image.placement,i=t("span",{className:"figure",attrs:{"aria-hidden":"true"}});if(!e.image.current)i.append(t("span",{className:"figure-empty"},[br("figure-silhouette"),t("span",{className:"figure-empty-text",text:"\uADF8\uB9BC \uC5C6\uC74C"})]));else{let n=t("span",{className:"figure-body"},[wr(e,"figure-image")]);n.style.height=`${a.scale*.9}%`,n.style.left=`${50+a.offsetX*.5}%`,i.append(n)}if(r.marker){let n=t("span",{className:"emotion-bubble",text:"?"}),o=lt(a);n.style.bottom=`${o.bottom}%`,n.style.left=`${o.left}%`,i.append(n)}return i}function O(e,r="small"){let a=t("span",{className:`avatar ${r}`,attrs:{"aria-hidden":"true"}});return e?.image.current?a.append(wr(e,"avatar-image")):(a.append(br("avatar-silhouette")),e||a.append(t("span",{className:"avatar-unknown",text:"?"}))),a}var $e={character:"\uCE90\uB9AD\uD130",persona:"\uD398\uB974\uC18C\uB098"};function U(e){return t("span",{className:`tag ${e.kind}`,text:$e[e.kind]})}function yr(e){let r=Z(e.weatherEffects);if(!r.enabled)return null;let a=(i,n)=>E(Te[i],{className:n,fallback:()=>t("span")});return t("div",{className:`weather-layer weather-${r.kind}`,attrs:{"aria-hidden":"true"}},[r.kind==="clear"?a("sun","weather-sun"):a("cloud","weather-cloud"),...r.kind==="rain"||r.kind==="snow"?Array.from({length:r.kind==="rain"?10:8},(i,n)=>{let o=t("span",{className:"weather-particle"},[a(r.kind==="snow"?"snow":"rain","weather-sprite")]);return o.style.cssText=`--weather-x:${5+n*37%90}%;--weather-delay:${-n*.47}s;--weather-duration:${r.kind==="snow"?7+n%3:2+n%3}s;--weather-top:${12+n*19%72}%;`,o}):[]])}var Da="http://www.w3.org/2000/svg";function Fa(){let e=document.createElementNS(Da,"svg");return e.setAttribute("viewBox","0 0 390 300"),e.setAttribute("preserveAspectRatio","xMidYMax slice"),e.setAttribute("aria-hidden","true"),e.setAttribute("class","scene-art"),e.innerHTML=`
    <g stroke="#4b2e1a" stroke-width="3" stroke-linejoin="round" stroke-linecap="round">
      <rect width="390" height="300" fill="#cfe5c0" stroke="none"/>
      <path d="M-10 70 Q20 10 70 30 Q100 -10 150 20 L150 -10 H-10z" fill="#8fbf6e"/>
      <path d="M400 80 Q370 20 320 40 Q300 -5 250 15 L250 -10 H400z" fill="#e2a55a"/>
      <circle cx="60" cy="120" r="34" fill="#8fbf6e"/>
      <circle cx="335" cy="115" r="30" fill="#8fbf6e"/>
      <path d="M-5 215 Q100 188 200 203 T395 198 V305 H-5z" fill="#a9cc86"/>
      <g transform="translate(150 70)">
        <rect x="0" y="62" width="170" height="108" rx="6" fill="#b98250"/>
        <rect x="10" y="74" width="150" height="96" fill="#dcb07c"/>
        <path d="M-22 70 L85 8 L192 70 Z" fill="#3f8a86"/>
        <path d="M10 62 L85 20 L160 62" fill="none" stroke-width="2.5"/>
        <rect x="66" y="104" width="38" height="66" rx="4" fill="#7a4b2a"/>
        <rect x="20" y="96" width="34" height="30" rx="3" fill="#f8de98"/>
        <rect x="116" y="96" width="34" height="30" rx="3" fill="#f8de98"/>
        <rect x="56" y="78" width="58" height="18" rx="3" fill="#f6e9cb"/>
        <circle cx="147" cy="84" r="7" fill="#f5c45c"/>
      </g>
      <path d="M150 305 Q190 240 235 240 Q280 240 302 305z" fill="#ead6a8"/>
      <circle cx="40" cy="232" r="25" fill="#6fa452"/><circle cx="76" cy="248" r="19" fill="#6fa452"/>
      <circle cx="350" cy="232" r="23" fill="#6fa452"/><circle cx="318" cy="250" r="17" fill="#6fa452"/>
      <g stroke-width="2"><circle cx="30" cy="224" r="4" fill="#fff6e4"/><circle cx="54" cy="240" r="4" fill="#fff6e4"/>
      <circle cx="345" cy="226" r="4" fill="#fff6e4"/><circle cx="326" cy="246" r="4" fill="#fff6e4"/>
      <circle cx="70" cy="232" r="4" fill="#d5a9e3"/><circle cx="360" cy="246" r="4" fill="#d5a9e3"/></g>
    </g>`,e}function Ga(e){let r=e.progress.starterResidentId;return Object.values(e.residents).filter(a=>a.recruited).sort((a,i)=>+(i.residentId===r)-+(a.residentId===r)||a.registeredAt.localeCompare(i.registeredAt)).slice(0,2)}function vr(e,r,a,i){if(r)return t("button",{className:`resident-spot filled ${e}`,attrs:{type:"button","aria-label":`${r.displayName} \uD504\uB85C\uD544 \uBCF4\uAE30`},on:{click:()=>{i.openResidents(r.residentId),i.openSheet({kind:"profile",residentId:r.residentId})}}},[J(r)]);if(a.progress.starterResidentId===null&&e==="left"){let n=Object.keys(a.residents).length>0;return t("button",{className:`resident-spot invite ${e}`,attrs:{type:"button"},on:{click:()=>i.openRegister(n?3:1)}},[t("span",{className:"spot-shadow"}),t("span",{className:"spot-text",text:n?"\uC2DC\uC791 \uC8FC\uBBFC \uACE0\uB974\uAE30":"\uC8FC\uBBFC \uB9DE\uC774\uD558\uAE30"})])}return t("button",{className:`resident-spot ${e}`,attrs:{type:"button","aria-label":"\uBE48 \uC790\uB9AC \u2014 \uCD08\uB300\uB85C \uC0C8 \uC8FC\uBBFC \uB9DE\uC774\uD558\uAE30"},on:{click:()=>i.navigate("invite")}},[t("span",{className:"spot-shadow"}),t("span",{className:"spot-text",text:"\uCD08\uB300"})])}function xr(e,r){let a=e.world?.state==="ready"?e.world.value.state:null,i=a?Ga(a):[],n=a?.settings.ground??{left:12,right:88,top:58,bottom:90},o=a?t("div",{className:"scene-stage ground-stage"},[vr("left",i[0]??null,a,r),vr("right",i[1]??null,a,r)]):null;return o&&(o.style.cssText=`left:${n.left}%;top:${n.top}%;width:${n.right-n.left}%;height:${n.bottom-n.top}%;right:auto;bottom:auto;padding:0;`),t("section",{className:`scene${be(e)?" editing-ground":""}`,attrs:{"aria-label":"\uACF5\uBC29 \uC7A5\uBA74"}},[E(ke[ee(e)].scene,{className:"scene-art",fallback:Fa}),be(e)?null:yr(e),o,be(e)?fr(e,r,o):a?t("button",{className:"ground-launch icon-button",attrs:{type:"button","aria-label":"\uC9C0\uBA74 \uD3B8\uC9D1",title:"\uC9C0\uBA74 \uD3B8\uC9D1"},on:{click:()=>r.openGroundEditor()}},[p.pencil("icon")]):null,i.length===0?t("p",{className:"scene-caption"},[p.leaf("icon tiny"),"\uC8FC\uBBFC\uC744 \uB9DE\uC774\uD558\uBA74 \uC774\uACF3\uC5D0 \uBAA8\uC5EC\uC694"]):null])}function _a(e,r){return e.items.find(a=>a.id===r)?.name??r}function kr(e,r){let a=e.world?.state==="ready"?e.world.value:null,i=e.content;if(!a||!i||a.state.progress.starterKitClaimed||e.starterSheetHidden)return null;let n=!!e.busy["claim-starter-kit"],o=i.starterKit;return t("div",{className:"sheet-backdrop"},[t("section",{className:"sheet card",attrs:{role:"dialog","aria-modal":"true","aria-labelledby":"fw-starter"}},[t("div",{className:"kit-heading"},[E(G.gift,{className:"kit-gift",fallback:()=>p.box("icon kit-gift")}),t("h2",{className:"section-title",text:"\uACF5\uBC29 \uC2DC\uC791 \uAFB8\uB7EC\uBBF8",attrs:{id:"fw-starter"}})]),t("p",{className:"muted",text:"\uCCAB \uCC44\uC9D1\uACFC \uAC00\uACF5\uC744 \uC2DC\uC791\uD560 \uC7AC\uB8CC\uC608\uC694. \uD55C \uBC88\uB9CC \uBC1B\uC744 \uC218 \uC788\uC5B4\uC694."}),t("ul",{className:"kit"},[t("li",{className:"kit-item"},[t("span",{className:"coin"}),t("span",{text:"\uACE8\uB4DC"}),t("strong",{text:o.gold.toLocaleString("ko-KR")})]),o.tickets?t("li",{className:"kit-item"},[p.ticket("icon"),t("span",{text:"\uCD08\uB300\uAD8C"}),t("strong",{text:`${o.tickets}\uC7A5`})]):null,...Object.entries(o.items).map(([s,l])=>t("li",{className:"kit-item"},[j(s),t("span",{text:_a(i,s)}),t("strong",{text:l.toLocaleString("ko-KR")})]))]),w(n?"\uBC1B\uB294 \uC911\u2026":"\uBC1B\uAE30",()=>{r.runCommand("claim-starter-kit","onboarding.claimStarterKit")},{disabled:n,attrs:{"data-wide":""}}),w("\uB098\uC911\uC5D0",()=>r.hideStarterSheet(),{variant:"secondary",attrs:{"data-wide":""}})])])}function Nr(e){let r=e.state.production.reportsReadThrough;return e.state.production.reports.filter(a=>a.reportId>r)}function Ve(e,r){let a={};for(let i of e)for(let[n,o]of Object.entries(i[r]))a[n]=(a[n]??0)+o;return a}function qa(e){let r=Object.values(e.state.production.facilities);return r.some(a=>a.waiting?.reason==="materials")?"\uC7AC\uB8CC\uB97C \uAE30\uB2E4\uB9AC\uB294 \uC2DC\uC124\uC774 \uC788\uC5B4\uC694":r.some(a=>a.job)?"\uACF5\uBC29\uC774 \uC798 \uB3CC\uC544\uAC00\uACE0 \uC788\uC5B4\uC694":"\uACF5\uBC29\uC774 \uC26C\uACE0 \uC788\uC5B4\uC694"}function Sr(e,r,a){let i=Nr(e),n=Object.entries(Ve(i,"produced")).sort(([,s],[,l])=>l-s),o=s=>s?t("div",{className:"report-slot"},[j(s[0],"big"),t("span",{className:"slot-name",text:B(r,s[0])}),t("strong",{text:`+${s[1]}`})]):t("div",{className:"report-slot empty"},[t("span",{className:"slot-art"}),t("span",{className:"slot-name",text:"\uC0C8 \uC785\uACE0 \uC5C6\uC74C"}),t("strong",{text:"\u2013"})]);return C(null,[t("h2",{className:"report-title",text:qa(e)}),t("div",{className:"report-body"},[t("div",{className:"report-items"},[o(n[0]),o(n[1])]),t("div",{className:"report-actions"},[t("button",{className:"button report-button",attrs:{type:"button"},on:{click:()=>a.openSheet({kind:"work-report"})}},[t("span",{text:"\uC791\uC5C5 \uBCF4\uACE0"}),i.length?t("span",{className:"count-badge",text:String(i.length)}):null,p.chevron("icon")]),t("span",{className:"report-caption"},[p.leaf("icon tiny"),"\uC790\uB3D9 \uC785\uACE0 \uC644\uB8CC"])])])],{className:"report-card"})}function $r(e,r,a){let i=e.state.production.activity.lastAbsence,n=r?.production.absenceLimitMs??72*36e5;return t("button",{className:"strip offline",attrs:{type:"button"},on:{click:()=>a.notify(i&&i.totalMs>i.creditedMs?`\uC9C0\uB09C\uBC88\uC5D4 ${Se(i.totalMs)}\uC2DC\uAC04 \uBE44\uC6E0\uACE0, \uADF8\uC911 \uCD5C\uB300 72\uC2DC\uAC04\uB9CC \uACF5\uBC29\uC774 \uC77C\uD588\uC5B4\uC694. \uB0A8\uC740 \uC791\uC5C5\uC740 \uBA48\uCD98 \uC790\uB9AC\uC5D0\uC11C \uC774\uC5B4\uC838\uC694.`:"\uC790\uB9AC\uB97C \uBE44\uC6B4 \uB3D9\uC548\uC5D0\uB3C4 \uCD5C\uB300 72\uC2DC\uAC04\uAE4C\uC9C0 \uACF5\uBC29\uC774 \uC77C\uD574\uC694. \uADF8 \uB4A4\uC5D4 \uBA48\uCD98 \uC790\uB9AC\uC5D0\uC11C \uAE30\uB2E4\uB824\uC694.")}},[p.clock(),t("span",{},["\uBBF8\uC811\uC18D \uB204\uC801 ",t("strong",{text:`${i?Se(i.creditedMs):"0"}\uC2DC\uAC04`}),` / \uCD5C\uB300 ${Se(n)}\uC2DC\uAC04`]),p.info("icon muted-icon")])}function Ha(e){let r=new Date(e);return Number.isNaN(r.getTime())?e:new Intl.DateTimeFormat("ko-KR",{month:"numeric",day:"numeric",hour:"2-digit",minute:"2-digit",hour12:!1}).format(r)}function we(e,r,a){let i=Object.entries(r);return t("span",{className:"report-items"},i.length?i.map(([n,o])=>t("span",{className:"report-item"},[j(n),t("span",{text:`${B(e,n)} ${a}${o}`})])):[t("span",{text:"\uC5C6\uC74C"})])}function Ir(e,r,a){let i=e.content,n=r.state.production.reports,o=Nr(r),s=!!e.busy["reports-read"];return t("div",{className:"sheet-backdrop"},[t("section",{className:"sheet card",attrs:{role:"dialog","aria-modal":"true","aria-labelledby":"fw-work-report"}},[t("h2",{className:"section-title",text:"\uC791\uC5C5 \uBCF4\uACE0",attrs:{id:"fw-work-report"}}),t("p",{className:"muted",text:"\uB9CC\uB4E0 \uBB3C\uAC74\uC740 \uB9CC\uB4E4\uC5B4\uC9C4 \uC21C\uAC04 \uCC3D\uACE0\uC5D0 \uB4E4\uC5B4\uAC14\uC5B4\uC694. \uBCF4\uACE0\uB97C \uC77D\uC5B4\uB3C4 \uB2E4\uC2DC \uC9C0\uAE09\uB418\uC9C0 \uC54A\uC544\uC694."}),o.length?t("div",{className:"report-total"},[t("p",{},[t("strong",{text:"\uC0C8\uB85C \uB4E4\uC5B4\uC628 \uAC83 "}),we(i,Ve(o,"produced"),"+")]),t("p",{},[t("strong",{text:"\uC7AC\uB8CC\uB85C \uC4F4 \uAC83 "}),we(i,Ve(o,"consumed"),"\u2212")]),o.some(l=>l.gold>0)?t("p",{},[t("strong",{text:"\uC790\uB3D9 \uD310\uB9E4 "}),we(i,Ve(o,"sold"),"\u2212"),t("span",{text:` \u2192 +${o.reduce((l,d)=>l+d.gold,0)} G`})]):null]):t("p",{className:"empty",text:"\uC0C8 \uBCF4\uACE0\uAC00 \uC5C6\uC5B4\uC694."}),n.length?t("ol",{className:"report-list"},n.slice(0,10).map(l=>t("li",{className:`report-entry${l.reportId>r.state.production.reportsReadThrough?" new":""}`},[t("span",{className:"report-time",text:`${Ha(l.at)}${l.offlineMs?` \xB7 \uBE44\uC6B4 \uB3D9\uC548 ${Se(l.offlineMs)}\uC2DC\uAC04`:""}`}),l.runs?t("span",{text:`${l.runs}\uD68C \uC644\uB8CC`}):null,Object.keys(l.produced).length?t("div",{},[t("strong",{text:"\uB4E4\uC5B4\uC634 "}),we(i,l.produced,"+")]):null,Object.keys(l.consumed).length?t("div",{},[t("strong",{text:"\uC7AC\uB8CC "}),we(i,l.consumed,"\u2212")]):null,l.gold?t("div",{},[t("strong",{text:"\uC790\uB3D9 \uD310\uB9E4 "}),we(i,l.sold,"\u2212"),t("span",{text:` +${l.gold} G`})]):null]))):null,o.length?w(s?"\uD655\uC778\uD558\uB294 \uC911\u2026":"\uD655\uC778",()=>{a.readReports(n[0].reportId)},{disabled:s,attrs:{"data-wide":""}}):null,w("\uB2EB\uAE30",()=>a.closeSheet(),{variant:"secondary",attrs:{"data-wide":""}})])])}function Cr(e,r){let a=n=>r?.stories.arcs.find(o=>o.id===n)?.title??"\uC774\uC57C\uAE30";for(let n of Object.values(e.stories.pairs)){let o=n.current;if(o?.episodes.some(s=>s.state==="unlocked"))return`\uC0C8 \uC774\uC57C\uAE30\uAC00 \uC5F4\uB838\uC5B4\uC694 \xB7 ${a(o.arcId)}`}let i=e.stories.expedition;if(i){let n=e.stories.pairs[i.pairId]?.current;return`\uD0D0\uD5D8 \uC911 \xB7 ${n?a(n.arcId):"\uC774\uC57C\uAE30 \uD0D0\uD5D8"}`}return Object.keys(e.pairs).length?"\uD0D0\uC0AC\uC5D0\uC11C \uC774\uC57C\uAE30 \uD0D0\uD5D8\uC744 \uB5A0\uB0A0 \uC218 \uC788\uC5B4\uC694":"\uD398\uC5B4\uB97C \uB9CC\uB4E4\uBA74 \uB450 \uC8FC\uBBFC\uC758 \uC774\uC57C\uAE30\uAC00 \uC5F4\uB824\uC694"}function Ka(e,r,a){return t("button",{className:"strip story",attrs:{type:"button","aria-label":`\uC8FC\uBBFC \uC774\uC57C\uAE30 \u2014 ${Cr(e,r)}`},on:{click:()=>a.openExplore()}},[t("span",{className:"story-art",attrs:{"aria-hidden":"true"}},[E(G.storyVignette,{className:"story-vignette",fallback:()=>p.book("icon")})]),t("span",{className:"story-text"},[t("strong",{text:"\uC8FC\uBBFC \uC774\uC57C\uAE30"}),t("span",{text:Cr(e,r)})]),t("span",{className:"round-arrow"},[p.chevron()])])}function Rr(e,r){let a=e.world;return!a||a.state!=="ready"?P(e,r,{top:{kind:"home"},backdrop:"forest",nav:!1,body:[a?.state==="error"?C(null,[Y(a.message),w("\uC138\uACC4 \uBAA9\uB85D\uC73C\uB85C",()=>r.navigate("worlds"),{variant:"secondary"})]):M("\uC138\uACC4\uB97C \uBD88\uB7EC\uC624\uB294 \uC911\u2026")]}):P(e,r,{top:{kind:"home"},backdrop:"forest",hero:xr(e,r),homeLayout:!0,body:be(e)?[hr(e,r)]:[Sr(a.value,e.content,r),Ka(a.value.state,e.content,r),$r(a.value,e.content,r)],nav:!0,sheet:e.sheet?.kind==="work-report"?Ir(e,a.value,r):kr(e,r)})}var dt={new:"\uC0C8 \uC8FC\uBBFC",breakthrough:"\uB3CC\uD30C",token:"\uC885\uD45C"};function Ar(e,r){return e.outcome==="new"?"\uACF5\uBC29\uC5D0 \uC654\uC5B4\uC694!":e.outcome==="breakthrough"?`\uB3CC\uD30C ${e.breakthrough}/${r}`:"\uCD5C\uB300 \uB3CC\uD30C\uB77C \uC885\uD45C 1\uAC1C\uAC00 \uB410\uC5B4\uC694"}function Be(e){return w("\uB2EB\uAE30",()=>e.closeSheet(),{variant:"secondary",attrs:{"data-wide":""}})}function De(e,r,a,i,n=!1){let o=e.sheet,s=o&&(o.kind==="invite-result"||o.kind==="invite-chances"||o.kind==="invite-log"||o.kind==="invite-wish")?o.page??0:0,l=Math.max(1,Math.ceil(a.length/2)),d=Math.min(s,l-1);return t("div",{className:"paged-rows"},[t(n?"ol":"ul",{className:i},a.slice(d*2,d*2+2)),_("\uCD08\uB300 \uBAA9\uB85D \uACE0\uB974\uAE30",d,Array.from({length:l},(c,m)=>`${m*2+1}\u2013${Math.min(a.length,m*2+2)} / ${a.length}`),c=>r.setInviteSheetPage(c))])}function Ua(e,r,a,i,n){let o=i.length===1?i[0]:null,s=o?r.state.residents[o.residentId]:null;return L("fw-invite-result",i.length>1?`${i.length}\uD68C \uCD08\uB300 \uACB0\uACFC`:"\uCD08\uB300 \uACB0\uACFC",[o&&s?t("div",{className:"result-hero"},[t("span",{className:"result-stage"},[J(s)]),t("strong",{className:"result-name",text:s.displayName}),t("span",{className:`result-badge ${o.outcome}`,text:dt[o.outcome]}),t("p",{className:"muted",text:Ar(o,a.crew.maxBreakthrough)})]):De(e,n,i.map(l=>{let d=r.state.residents[l.residentId];return t("li",{className:`result-row ${l.outcome}`},[O(d??null),t("strong",{text:d?.displayName??"\uC8FC\uBBFC"}),t("span",{className:`result-badge ${l.outcome}`,text:dt[l.outcome]}),t("small",{className:"muted",text:`${Ar(l,a.crew.maxBreakthrough)}${l.via==="guarantee"?" \xB7 \uBCF4\uC7A5":""}`})])}),"result-list",!0),Be(n)])}function Qa(e,r,a,i){let n=Object.keys(r.state.residents).sort(),o=r.state.invite.wishResidentId,s=d=>d===o?a.invite.wishWeight:a.invite.baseWeight,l=n.reduce((d,c)=>d+s(c),0);return L("fw-invite-chances","\uD655\uB960 \uBCF4\uAE30",[t("p",{className:"muted",text:`\uB4F1\uB85D\uB41C \uC8FC\uBBFC\uC740 \uBAA8\uB450 \uAC19\uC740 \uD655\uB960\uC774\uC5D0\uC694(\uB4F1\uAE09 \uC5C6\uC74C). \uD76C\uB9DD \uC8FC\uBBFC\uC740 ${a.invite.wishWeight}\uBC30\uB85C \uB9CC\uB098\uC694. \uC0C8 \uC8FC\uBBFC \uC5C6\uC774 ${a.invite.guaranteeAfter}\uBC88\uC774 \uC9C0\uB098\uBA74 \uB2E4\uC74C \uCD08\uB300\uB294 \uC544\uC9C1 \uC624\uC9C0 \uC54A\uC740 \uC8FC\uBBFC\uC774\uC5D0\uC694(\uD76C\uB9DD \uC8FC\uBBFC\uC774 \uAE30\uB2E4\uB9AC\uBA74 \uADF8 \uC8FC\uBBFC). 10\uD68C \uCD08\uB300\uB294 \uD55C \uBC88\uC529 \uCC28\uB840\uB85C \uC801\uC6A9\uB3FC\uC694.`}),n.length===0?t("p",{className:"empty",text:"\uB4F1\uB85D\uB41C \uC8FC\uBBFC\uC774 \uC5C6\uC5B4\uC694."}):De(e,i,n.map(d=>{let c=r.state.residents[d],m=l?s(d)/l*100:0;return t("li",{className:"chance-row"},[O(c),t("span",{className:"chance-name"},[t("strong",{text:c.displayName}),d===o?t("span",{className:"tag wish",text:"\uD76C\uB9DD"}):null]),t("strong",{className:"chance-value",text:`${m.toFixed(m<10?2:1)}%`})])}),"chance-list"),t("p",{className:"muted",text:`\uCC98\uC74C \uB9CC\uB098\uBA74 \uC601\uC785, \uB2E4\uC2DC \uB9CC\uB098\uBA74 \uB3CC\uD30C(\uCD5C\uB300 ${a.crew.maxBreakthrough}), \uCD5C\uB300 \uB3CC\uD30C \uB4A4\uC5D0\uB294 \uC885\uD45C 1\uAC1C. \uC885\uD45C ${a.invite.tokensPerExchange}\uAC1C\uB85C \uC6D0\uD558\uB294 \uC8FC\uBBFC\uC744 \uACE0\uB97C \uC218 \uC788\uC5B4\uC694.`}),Be(i)])}function Ya(e,r,a,i){let n=r.state.invite.log,o=new Intl.DateTimeFormat("ko-KR",{dateStyle:"short",timeStyle:"short"});return L("fw-invite-log","\uCD08\uB300 \uAE30\uB85D",[n.length===0?t("p",{className:"empty",text:"\uC544\uC9C1 \uCD08\uB300 \uAE30\uB85D\uC774 \uC5C6\uC5B4\uC694."}):De(e,i,n.map(s=>t("li",{className:`result-row ${s.outcome}`},[O(r.state.residents[s.residentId]??null),t("strong",{text:r.state.residents[s.residentId]?.displayName??s.name}),t("span",{className:`result-badge ${s.outcome}`,text:dt[s.outcome]}),t("small",{className:"muted",text:`${o.format(new Date(s.at))}${s.via==="guarantee"?" \xB7 \uBCF4\uC7A5":s.via==="exchange"?" \xB7 \uC885\uD45C \uAD50\uD658":""}${s.outcome==="breakthrough"?` \xB7 \uB3CC\uD30C ${s.breakthrough}/${a.crew.maxBreakthrough}`:""}`})])),"result-list",!0),t("p",{className:"muted",text:`\uCD5C\uADFC ${a.invite.logLimit}\uAC74\uAE4C\uC9C0 \uBCF4\uAD00\uD574\uC694.`}),Be(i)])}function Ja(e,r,a){let i=r.state.invite.wishResidentId,n=!!e.busy["invite-wish"],o=Object.values(r.state.residents).sort((s,l)=>s.displayName.localeCompare(l.displayName,"ko"));return L("fw-invite-wish","\uD76C\uB9DD \uC8FC\uBBFC \uC124\uC815",[t("p",{className:"muted",text:"\uB4F1\uB85D\uB41C \uCE90\uB9AD\uD130\xB7\uD398\uB974\uC18C\uB098 \uC911 \uD55C \uBA85\uC744 \uACE0\uB974\uBA74 \uADF8 \uC8FC\uBBFC\uC744 \uB354 \uC798 \uB9CC\uB098\uC694."}),o.length===0?t("p",{className:"empty",text:"\uB4F1\uB85D\uB41C \uC8FC\uBBFC\uC774 \uC5C6\uC5B4\uC694."}):De(e,a,o.map(s=>t("li",{},[t("button",{className:`pick-row${s.residentId===i?" selected":""}`,attrs:{type:"button","aria-pressed":s.residentId===i?"true":"false"},disabled:n,on:{click:()=>{a.setWish(s.residentId)}}},[O(s),t("strong",{text:s.displayName}),U(s),t("small",{className:"muted",text:s.recruited?"\uC601\uC785 \uC644\uB8CC":"\uCD08\uB300 \uB300\uAE30"}),s.residentId===i?p.check("icon"):null])])),"pick-list"),i?w("\uD76C\uB9DD \uC8FC\uBBFC \uD574\uC81C",()=>{a.setWish(null)},{variant:"secondary",disabled:n}):null,Be(a)])}function Mr(e,r,a,i){let n=e.sheet;return n?n.kind==="invite-result"?Ua(e,r,a,n.draws,i):n.kind==="invite-chances"?Qa(e,r,a,i):n.kind==="invite-log"?Ya(e,r,a,i):n.kind==="invite-wish"?Ja(e,r,i):null:null}function Xa(e,r){let a=e.world?.state==="ready"?e.world.value:null;if(!a)return null;let{tickets:i,tokens:n}=a.state.wallet;return t("div",{className:"resources invite-counters"},[t("button",{className:"counter ticket",attrs:{type:"button","aria-label":`\uCD08\uB300\uAD8C ${i}\uC7A5 \u2014 \uCD08\uB300\uAD8C \uBC1B\uAE30`},on:{click:()=>r.openDeliveries()}},[t("span",{className:"ticket-mark"},[p.ticket("icon")]),t("span",{className:"counter-value",text:String(i)}),t("span",{className:"counter-plus"},[p.plus("icon tiny")])]),t("span",{className:"counter token",attrs:{"aria-label":`\uC885\uD45C ${n}\uAC1C`}},[t("span",{className:"token-mark"},[p.leaf("icon")]),t("span",{className:"counter-value",text:String(n)})])])}function Za(e,r){let a=(i,n,o)=>t("button",{className:`segment${e.inviteTab===i?" selected":""}`,attrs:{type:"button",role:"tab","aria-selected":e.inviteTab===i?"true":"false"},on:{click:()=>r.setInviteTab(i)}},[o,t("span",{text:n})]);return t("div",{className:"segmented invite-tabs",attrs:{role:"tablist","aria-label":"\uCD08\uB300"}},[a("invite","\uC8FC\uBBFC \uCD08\uB300",p.sprout("icon")),a("exchange","\uC885\uD45C \uAD50\uD658",p.leaf("icon"))])}function Pr(e,r,a,i,n){let o=i*a.invite.ticketsPerDraw,s=Math.max(0,o-r.state.wallet.tickets),l=Object.keys(r.state.residents).length===0,d=!!e.busy[`invite:${i}`];return t("button",{className:`draw-button${s?" short":""}`,attrs:{type:"button","aria-label":`${i}\uD68C \uCD08\uB300 \u2014 \uCD08\uB300\uAD8C ${o}\uC7A5${s?`, ${s}\uC7A5 \uBD80\uC871`:""}`},disabled:d||s>0||l||r.state.progress.starterResidentId===null,on:{click:()=>{n.draw(i)}}},[t("strong",{className:"draw-title",text:d?"\uCD08\uB300\uD558\uB294 \uC911\u2026":`${i}\uD68C \uCD08\uB300`}),t("span",{className:"draw-cost"},[p.ticket("icon"),`${o}\uC7A5`]),s?t("span",{className:"draw-short"},[p.info("icon tiny"),`\uCD08\uB300\uAD8C ${s}\uC7A5 \uBD80\uC871`]):null])}function ei(e,r,a,i){let n=Object.values(r.state.residents),o=r.state.invite.wishResidentId?r.state.residents[r.state.invite.wishResidentId]:null,s=n.filter(d=>!d.recruited).length,l=a.invite.guaranteeAfter-r.state.invite.sinceNew+1;return[t("div",{className:"invite-stage"},[E(G.inviteScene,{className:"invite-scene",fallback:()=>p.ticket("icon huge")})]),C(null,[t("button",{className:"menu-row wish-row",attrs:{type:"button"},on:{click:()=>i.openSheet({kind:"invite-wish"})}},[t("span",{className:"menu-icon light"},[p.sprout("icon")]),t("span",{className:"menu-text"},[t("span",{className:"menu-title",text:"\uD76C\uB9DD \uC8FC\uBBFC \uC124\uC815"}),t("span",{className:"menu-detail",text:o?`${o.displayName} \xB7 \uB2E4\uB978 \uC8FC\uBBFC\uBCF4\uB2E4 \uC798 \uB9CC\uB098\uC694`:"\uB4F1\uB85D\uB41C \uCE90\uB9AD\uD130\xB7\uD398\uB974\uC18C\uB098 \uC911\uC5D0\uC11C \uB9CC\uB098\uC694."})]),t("span",{className:"menu-chevron"},[p.chevron()])]),n.length===0?t("div",{className:"invite-empty"},[t("p",{className:"empty",text:"\uCD08\uB300\uD560 \uC8FC\uBBFC\uC774 \uC5C6\uC5B4\uC694. \uBA3C\uC800 \uCE90\uB9AD\uD130\uB098 \uD398\uB974\uC18C\uB098\uB97C \uBD88\uB7EC\uC640 \uC8FC\uC138\uC694."}),w("\uC8FC\uBBFC \uBD88\uB7EC\uC624\uAE30",()=>i.navigate("residents"))]):r.state.progress.starterResidentId===null?t("div",{className:"invite-empty"},[t("p",{className:"empty",text:"\uC2DC\uC791 \uC8FC\uBBFC\uC744 \uBA3C\uC800 \uC815\uD558\uBA74 \uCD08\uB300\uD560 \uC218 \uC788\uC5B4\uC694."}),w("\uC8FC\uBBFC \uD654\uBA74\uC73C\uB85C",()=>i.navigate("residents"))]):null,t("div",{className:"draw-row"},[Pr(e,r,a,1,i),Pr(e,r,a,a.invite.multiDraw,i)]),t("p",{className:"hint center",text:n.length===0?"\uB4F1\uB85D\uD55C \uC8FC\uBBFC \uC911\uC5D0\uC11C \uC0C8\uB85C\uC6B4 \uC778\uC5F0\uC744 \uB9CC\uB0A0 \uC218 \uC788\uC5B4\uC694.":s>0?`\uC544\uC9C1 \uC624\uC9C0 \uC54A\uC740 \uC8FC\uBBFC ${s}\uBA85 \xB7 \uB2A6\uC5B4\uB3C4 ${Math.max(1,l)}\uBC88\uC9F8 \uCD08\uB300\uC5D0\uB294 \uC0C8 \uC8FC\uBBFC\uC744 \uB9CC\uB098\uC694.`:"\uBAA8\uB450 \uACF5\uBC29\uC5D0 \uC654\uC5B4\uC694. \uB2E4\uC2DC \uB9CC\uB098\uBA74 \uB3CC\uD30C, \uCD5C\uB300 \uB3CC\uD30C \uB4A4\uC5D0\uB294 \uC885\uD45C\uAC00 \uB3FC\uC694."}),t("div",{className:"link-row"},[t("button",{className:"link-button with-icon",attrs:{type:"button"},on:{click:()=>i.openSheet({kind:"invite-chances"})}},[p.info("icon"),t("span",{text:"\uD655\uB960 \uBCF4\uAE30"})]),t("button",{className:"link-button with-icon",attrs:{type:"button"},on:{click:()=>i.openSheet({kind:"invite-log"})}},[p.document("icon"),t("span",{text:"\uCD08\uB300 \uAE30\uB85D"})])])])]}function ti(e,r,a,i,n){let o=a.crew.maxBreakthrough,s=r.recruited&&r.breakthrough>=o,l=!!e.busy[`exchange:${r.residentId}`],d=r.recruited?s?"\uCD5C\uB300 \uB3CC\uD30C":`\uB3CC\uD30C ${r.breakthrough}/${o} \u2192 ${r.breakthrough+1}`:"\uCD08\uB300 \uB300\uAE30 \u2192 \uC601\uC785";return t("li",{className:"exchange-row"},[O(r),t("span",{className:"exchange-name"},[t("strong",{text:r.displayName}),t("span",{className:"tag-row"},[U(r),t("small",{className:"muted",text:d})])]),t("button",{className:"button small",text:l?"\uAD50\uD658 \uC911\u2026":"\uAD50\uD658",attrs:{type:"button","aria-label":`${r.displayName}\uC640(\uACFC) \uC885\uD45C \uAD50\uD658`},disabled:l||s||i<a.invite.tokensPerExchange,on:{click:()=>{n.exchange(r.residentId)}}})])}function ri(e,r,a,i){let n=r.state.wallet.tokens,o=Object.values(r.state.residents).sort((d,c)=>Number(d.recruited)-Number(c.recruited)||d.displayName.localeCompare(c.displayName,"ko")),s=Math.max(1,Math.ceil(o.length/2)),l=Math.min(e.invitePage??0,s-1);return[C("\uC885\uD45C \uAD50\uD658",[t("p",{className:"exchange-summary"},[t("span",{className:"token-coin"},[p.leaf("icon")]),t("strong",{text:`${n} / ${a.invite.tokensPerExchange}`}),t("span",{className:"muted",text:` \uC885\uD45C ${a.invite.tokensPerExchange}\uAC1C\uB85C \uC6D0\uD558\uB294 \uC8FC\uBBFC\uC744 \uBC14\uB85C \uB9DE\uC774\uD558\uAC70\uB098 \uB3CC\uD30C\uD574\uC694.`})]),o.length===0?t("p",{className:"empty",text:"\uB4F1\uB85D\uB41C \uC8FC\uBBFC\uC774 \uC5C6\uC5B4\uC694."}):t("ul",{className:"exchange-list"},o.slice(l*2,l*2+2).map(d=>ti(e,d,a,n,i))),_("\uAD50\uD658 \uC8FC\uBBFC \uBAA9\uB85D \uACE0\uB974\uAE30",l,Array.from({length:s},(d,c)=>`${c+1} \xB7 ${o.slice(c*2,c*2+2).map(m=>m.displayName).join(" \xB7 ")}`),d=>i.setInvitePage(d))])]}function Er(e,r){let a=e.world?.state==="ready"?e.world.value:null,i=e.content,n=a&&i;return P(e,r,{top:{kind:"sub",title:"\uCD08\uB300",subtitle:"\uC0C8\uB85C\uC6B4 \uC778\uC5F0\uC744 \uB9DE\uC774\uD574\uC694",resources:!1,counters:Xa(e,r)},backdrop:"forest",body:n?[Za(e,r),...e.inviteTab==="invite"?ei(e,a,i,r):ri(e,a,i,r)]:[M("\uC138\uACC4\uB97C \uBD88\uB7EC\uC624\uB294 \uC911\u2026")],nav:!0,sheet:n?Mr(e,a,i,r):null})}function Tr(e,r,a){let i=e.explore.tab==="patrol"?"patrol":"survey",n=i==="survey"?"\uC870\uC0AC":"\uC21C\uCC30",o=r.state.activities?.running,l=Object.values(r.state.residents).filter(b=>b.recruited).filter(b=>!r.state.stories.expedition?.participants.includes(b.residentId)),d=l.find(b=>b.residentId===e.explore.activityResidentId)??l[0],c=t("select",{className:"input",attrs:{"aria-label":"\uD65C\uB3D9 \uC8FC\uBBFC \uC120\uD0DD"},on:{change:()=>a.selectActivityResident(c.value)}},l.map(b=>t("option",{text:b.displayName,attrs:{value:b.residentId}})));c.value=d?.residentId??"";let m=Math.max(0,Date.now()-(e.worldReceivedAt??Date.now())),g=o?Math.max(0,o.endsSim-r.state.production.simMs-m):0,f=(r.state.activities?.completed.length??0)>=100||(r.state.mailbox?.letters.length??0)>=200;return C("\uACF5\uBC29 \uC8FC\uBCC0",[t("p",{text:i==="survey"?"\uC8FC\uBCC0\uC758 \uD480\uACFC \uB098\uBB47\uC78E\uC744 \uC0B4\uD3B4\uBCF4\uACE0 \uBC1C\uACAC\uC744 \uAE30\uB85D\uD574\uC694.":"\uAE38\uACFC \uC27C\uD130\uB97C \uD55C \uBC14\uD034 \uB3CC\uBA70 \uC548\uBD80\uB97C \uD655\uC778\uD574\uC694."}),o?t("div",{className:"activity-running"},[t("strong",{text:`${r.state.residents[o.residentId]?.displayName??"\uC8FC\uBBFC"} \xB7 ${o.kind==="survey"?"\uC870\uC0AC":"\uC21C\uCC30"} \uC911`}),t("span",{className:"countdown",text:de(g),attrs:{"data-countdown-end":String(Date.now()+g)}}),w("\uD65C\uB3D9 \uCDE8\uC18C",()=>{a.cancelActivity(o.id)},{variant:"secondary",disabled:!!e.busy[`activity-cancel:${o.id}`]}),t("p",{className:"muted",text:"\uC644\uB8CC \uACB0\uACFC\uB294 \uAE30\uB85D\uACFC \uC6B0\uD3B8\uD568\uC5D0 \uB0A8\uC544\uC694. \uCDE8\uC18C\uD574\uB3C4 \uC7AC\uD654\uB294 \uC18C\uBAA8\uB418\uC9C0 \uC54A\uC544\uC694."})]):t("div",{className:"activity-prepare"},[l.length?c:t("p",{text:"\uC601\uC785\uD55C \uC8FC\uBBFC \uC911 \uC774\uC57C\uAE30 \uD0D0\uD5D8\uC5D0 \uCC38\uC5EC\uD558\uC9C0 \uC54A\uC740 \uC8FC\uBBFC\uC774 \uD544\uC694\uD574\uC694."}),t("p",{text:`\uC18C\uC694 ${i==="survey"?30:15}\uBD84 \xB7 \uC8FC\uBBFC 1\uBA85 \xB7 \uACB0\uACFC \uAE30\uB85D\uACFC \uD3B8\uC9C0`}),t("p",{className:"muted",text:"\uCD9C\uBC1C\uD558\uBA74 \uC2DC\uC124 \uBC30\uCE58\uC5D0\uC11C \uBE60\uC838\uC694. \uC0DD\uC0B0 \uC911\uC778 \uC791\uC5C5\uC740 \uCDE8\uC18C\uB418\uC9C0 \uC54A\uC544\uC694. \uC7AC\uB8CC\xB7\uACE8\uB4DC\xB7\uCD08\uB300\uAD8C \uBCF4\uC0C1\uC740 \uC5C6\uC5B4\uC694."}),w(f?"\uAE30\uB85D \uC800\uC7A5 \uD55C\uB3C4\uC5D0 \uB3C4\uB2EC\uD588\uC5B4\uC694":`${n} \uCD9C\uBC1C`,()=>{d&&a.startActivity(i,d.residentId)},{disabled:!d||f||!!e.busy["activity-start"]})]),t("p",{className:"muted",text:"\uC138\uACC4\uB2F9 \uC870\uC0AC\xB7\uC21C\uCC30 \uD55C \uD65C\uB3D9\uB9CC \uC9C4\uD589\uD574\uC694. \uBBF8\uC811\uC18D \uC2DC\uAC04\uC740 \uCD5C\uB300 72\uC2DC\uAC04\uAE4C\uC9C0 \uBC18\uC601\uB3FC\uC694. \uB0A8\uC740 \uC2DC\uAC04\uC740 \uCD94\uC815\uCE58\uC608\uC694."}),t("h3",{text:"\uCD5C\uADFC \uC644\uB8CC \uAE30\uB85D"}),...(r.state.activities?.completed??[]).slice(0,3).map(b=>t("div",{className:"activity-record"},[t("strong",{text:`${b.kind==="survey"?"\uC870\uC0AC":"\uC21C\uCC30"} \xB7 ${r.state.residents[b.residentId]?.displayName??"\uC8FC\uBBFC"}`}),t("p",{text:b.summary}),w("\uACB0\uACFC \uD3B8\uC9C0 \uC77D\uAE30",()=>{a.openActivityLetter(b.mailId)},{variant:"secondary",disabled:!!e.busy[`mail:${b.mailId}`],attrs:{"aria-label":`${b.kind==="survey"?"\uC870\uC0AC":"\uC21C\uCC30"} \uACB0\uACFC \uD3B8\uC9C0 \uC77D\uAE30`}})])),w("\uC6B0\uD3B8\uD568 \uC5F4\uAE30",()=>a.openMailbox(),{variant:"secondary"})],{className:"activity-card"})}var ai="http://www.w3.org/2000/svg",ct={locked:"\uC7A0\uAE40",available:"\uCD9C\uBC1C \uAC00\uB2A5",running:"\uD0D0\uD5D8 \uC911",unlocked:"\uC774\uC57C\uAE30 \uC5F4\uB9BC",read:"\uC77D\uC74C"};function Ie(e,r){let a=[["survey","\uC870\uC0AC",p.search],["patrol","\uC21C\uCC30",p.compass],["story","\uC774\uC57C\uAE30 \uD0D0\uD5D8",p.leaf]];return t("div",{className:"field-tabs explore-tabs work-fields",attrs:{role:"tablist","aria-label":"\uD0D0\uC0AC"}},a.map(([i,n,o])=>t("button",{className:`field-tab${e.explore.tab===i?" current":""}`,attrs:{type:"button",role:"tab","aria-selected":String(e.explore.tab===i)},on:{click:()=>r.setExploreTab(i)}},[o("icon field-glyph"),t("span",{text:n})])))}function ii(e,r){let a=document.createElementNS(ai,"svg");a.setAttribute("viewBox","0 0 360 170"),a.setAttribute("class","trail-art"),a.setAttribute("aria-hidden","true");let i=[[60,120],[170,92],[285,60]],n=o=>e.episodes[o].status==="read"?"#5a9a44":o===r?"#fff8e8":"#cdbf9f";return a.innerHTML=`
    <g stroke="#4b2e1a" stroke-width="3" stroke-linejoin="round" stroke-linecap="round">





      <path d="M20 135 Q60 120 ${i[0][0]} ${i[0][1]} Q120 100 ${i[1][0]} ${i[1][1]} Q230 80 ${i[2][0]} ${i[2][1]}"
        fill="none" stroke="#fff8e8" stroke-width="6" stroke-dasharray="10 8"/>
      ${i.map(([o,s],l)=>`<circle cx="${o}" cy="${s}" r="11" fill="${n(l)}"/>`).join("")}
      <g transform="translate(${i[r][0]-14} ${i[r][1]-46})">
        <path d="M14 30 L8 22 H4 a4 4 0 0 1-4-4 V4 a4 4 0 0 1 4-4 H24 a4 4 0 0 1 4 4 V18 a4 4 0 0 1-4 4 H20z" fill="#fff8e8"/>
        <path d="M14 18 c0-6 0-9 0-12 M14 12 c-4-1-6-4-6-7 4 1 6 3 6 7z M14 10 c4-1 5-4 5-7-4 1-5 3-5 7z" fill="#5a9a44" stroke-width="2"/>
      </g>
    </g>`,t("div",{className:"trail-scene"},[E(G.trail,{className:"trail-background",fallback:()=>t("span",{className:"trail-background"})}),a])}function ni(e,r,a,i){if(a.length<2)return null;let n=t("select",{className:"input",attrs:{"aria-label":"\uD398\uC5B4 \uACE0\uB974\uAE30"},on:{change:()=>i.selectStoryPair(n.value)}},a.map(o=>{let s=r.state.pairs[o.pairId].residentIds.map(l=>r.state.residents[l]?.displayName??"\uC8FC\uBBFC");return t("option",{text:s.join(" \xB7 "),attrs:{value:o.pairId}})}));return n.value=a.some(o=>o.pairId===e.explore.pairId)?e.explore.pairId:a[0].pairId,n}function oi(e,r,a){return t("ol",{className:"episode-row",attrs:{"aria-label":"\uC774\uC57C\uAE30 \uD3B8"}},e.episodes.map(i=>t("li",{},[t("button",{className:`episode-tile ${i.status}${i.index===r?" selected":""}`,attrs:{type:"button","aria-pressed":i.index===r?"true":"false","aria-label":`${i.index+1}\uD3B8 ${i.title} ${ct[i.status]}`},on:{click:()=>a.selectStoryEpisode(i.index)}},[t("span",{className:"episode-icon"},[(i.status==="locked"?p.lock:p.book)("icon big"),i.status==="read"?t("span",{className:"episode-check"},[p.check("icon tiny")]):null]),t("span",{className:"episode-text"},[t("strong",{text:`${i.index+1}\uD3B8`}),t("span",{text:i.title}),t("small",{text:i.status==="locked"?i.reasons[0]??ct.locked:ct[i.status]})])])])))}function si(e,r,a,i,n,o){let s=u=>Math.max(0,(r.state.inventory[u]??0)-(r.state.production.protectedStock[u]??0)),l=Object.entries(n.preparations),d=l.every(([u,x])=>s(u)>=x),c=n.participants.map(u=>r.state.residents[u]).filter(Boolean),m=r.state.stories.expedition,g=m&&m.pairId===i.pairId&&m.episode===n.index,f=u=>!!e.busy[u],b=c.filter(u=>Object.values(r.state.production.facilities).some(x=>x.residentId===u.residentId)),y;if(n.status==="available"){let u=`depart:${i.pairId}:${n.index}`;y=w(f(u)?"\uCD9C\uBC1C\uD558\uB294 \uC911\u2026":d?"\uD0D0\uD5D8 \uCD9C\uBC1C":"\uC900\uBE44\uBB3C\uC774 \uBD80\uC871\uD574\uC694",()=>{o.depart(i.pairId,n.index)},{disabled:f(u)||!d,attrs:{"data-wide":""}})}else if(n.status==="running"&&g){let u=he(e,r,m);y=t("div",{className:"expedition-running"},[t("p",{className:"running-line"},[p.compass("icon"),t("strong",{text:"\uD0D0\uD5D8 \uC911"}),u.countdown]),u.bar,w(f("expedition-cancel")?"\uCDE8\uC18C\uD558\uB294 \uC911\u2026":"\uD0D0\uD5D8 \uCDE8\uC18C (\uC900\uBE44\uBB3C\uC740 \uBAA8\uB450 \uB3CC\uB824\uBC1B\uC544\uC694)",()=>{o.cancelExpedition()},{variant:"secondary",disabled:f("expedition-cancel")})])}else if((n.status==="unlocked"||n.status==="read")&&n.storyId){let u=n.storyId;y=w(n.status==="read"?"\uB2E4\uC2DC \uC77D\uAE30":n.written?"\uC774\uC5B4 \uC77D\uAE30":"\uC774\uC57C\uAE30 \uC77D\uAE30",()=>o.openStory(i.pairId,n.index,u),{attrs:{"data-wide":""}})}else y=t("div",{className:"locked-reasons"},[t("p",{className:"hint",text:"\uC544\uC9C1 \uB5A0\uB0A0 \uC218 \uC5C6\uC5B4\uC694:"}),t("ul",{},n.reasons.map(u=>t("li",{text:u})))]);return t("div",{className:"expedition-details"},[t("div",{className:"detail-grid"},[t("div",{className:"detail-cell"},[p.clock("icon big"),t("span",{},[t("small",{text:"\uC18C\uC694 \uC2DC\uAC04"}),t("strong",{text:`${n.minutes}\uBD84`})])]),t("div",{className:"detail-cell"},[p.people("icon big"),t("span",{},[t("small",{text:"\uCC38\uC5EC \uC8FC\uBBFC"}),t("strong",{text:`${c.length}\uBA85`})]),t("span",{className:"avatar-row"},c.map(u=>O(u)))]),t("div",{className:"detail-cell wide"},[p.box("icon big"),t("span",{},[t("small",{text:"\uC900\uBE44\uBB3C"}),t("span",{className:"prep-list"},l.map(([u,x])=>t("span",{className:`prep${s(u)>=x?" ok":""}`},[j(u),`${B(a,u)} ${Math.min(s(u),x)}/${x}`,s(u)>=x?p.check("icon tiny"):null])))])]),t("div",{className:"detail-cell wide"},[p.sparkle("icon big"),t("span",{},[t("small",{text:"\uBC1C\uACAC\uD560 \uC218 \uC788\uB294 \uAC83"}),t("strong",{text:i.arc.discovery})])])]),t("p",{className:"hint",text:b.length?`${b.map(u=>u.displayName).join(", ")}\uC740(\uB294) \uCD9C\uBC1C\uD558\uBA74 \uC2DC\uC124\uC5D0\uC11C \uBE60\uC838\uC694. \uC2DC\uC124\uC740 \uAE30\uBCF8 \uD6A8\uC728\uB85C \uACC4\uC18D \uC77C\uD558\uACE0, \uC9C4\uD589 \uC911\uC778 \uC791\uC5C5\uC740 \uCDE8\uC18C\uD558\uC9C0 \uC54A\uC544\uC694.`:"\uC2DC\uC124\uC740 \uADF8\uB300\uB85C \uC77C\uD574\uC694. \uD0D0\uD5D8\uC740 \uC77C\uC0C1 \uC0DD\uC0B0\uACFC \uB530\uB85C \uD558\uB098\uC529 \uB5A0\uB098\uC694."}),y])}function li(e,r,a){let n=(e.world?.state==="ready"?e.world.value.state.stories.pairs?.[r.pairId]?.current:null)?.episodes.flatMap((l,d)=>l.state==="read"?[{index:d,storyId:l.storyId}]:[])??[];if(r.completed.length===0&&n.length===0)return C("\uC77D\uC740 \uC774\uC57C\uAE30",[t("p",{className:"empty",text:"\uC544\uC9C1 \uC77D\uC740 \uC774\uC57C\uAE30\uAC00 \uC5C6\uC5B4\uC694."})]);let o=Math.max(1,Math.ceil(r.completed.length/2)),s=Math.min(e.explore.historyPage??0,o-1);return C("\uC77D\uC740 \uC774\uC57C\uAE30",[n.length&&s===0?t("div",{className:"completed-arc"},[t("strong",{text:r.arc.title}),...n.map(({index:l,storyId:d})=>w(`${l+1}\uD3B8 \uB2E4\uC2DC \uC77D\uAE30`,()=>a.openStory(r.pairId,l,d),{variant:"secondary"}))]):null,t("ul",{className:"menu-list"},r.completed.slice().reverse().slice(s*2,s*2+2).map(l=>t("li",{className:"completed-arc"},[t("strong",{text:l.title}),t("span",{className:"row-actions"},l.storyIds.map((d,c)=>t("button",{className:"outline-button small",text:`${c+1}\uD3B8`,attrs:{type:"button","aria-label":`${l.title} ${c+1}\uD3B8 \uB2E4\uC2DC \uC77D\uAE30`},on:{click:()=>a.openStory(r.pairId,c,d)}})))]))),_("\uC77D\uC740 \uC774\uC57C\uAE30 \uBAA9\uB85D \uACE0\uB974\uAE30",s,Array.from({length:o},(l,d)=>`${d+1} \xB7 ${r.completed.slice().reverse().slice(d*2,d*2+2).map(c=>c.title).join(" \xB7 ")}`),l=>a.setExploreHistoryPage(l))])}function di(e,r,a,i){let n=r.state.stories.expedition,o=n?a.find(d=>d.pairId===n.pairId):null,s=Math.round(i.production.absenceLimitMs/36e5);if(!n||!o)return t("div",{className:"strip offline explore-strip"},[p.compass(),t("span",{text:"\uC9C0\uAE08\uC740 \uB5A0\uB09C \uD0D0\uD5D8\uC774 \uC5C6\uC5B4\uC694."}),t("small",{className:"muted",text:`\uBC29\uCE58 \uB204\uC801 \uCD5C\uB300 ${s}\uC2DC\uAC04`})]);let l=he(e,r,n);return t("div",{className:"strip offline explore-strip"},[p.compass(),t("span",{className:"strip-progress"},[t("span",{},[`${o.episodes[n.episode].title} \xB7 `,l.countdown," \uB0A8\uC74C"]),l.bar]),t("small",{className:"muted",text:`\uBC29\uCE58 \uB204\uC801 \uCD5C\uB300 ${s}\uC2DC\uAC04`})])}function ci(e,r,a,i){if(e.explore.tab!=="story")return[Ie(e,i),Tr(e,r,i)];let n=e.explore.overview;if(!n||n.state==="loading")return[Ie(e,i),M("\uC774\uC57C\uAE30\uB97C \uBD88\uB7EC\uC624\uB294 \uC911\u2026")];if(n.state==="error")return[Ie(e,i),C(null,[Y(n.message),w("\uB2E4\uC2DC \uBD88\uB7EC\uC624\uAE30",()=>{i.loadStoryOverview()})])];let o=n.value.pairs.filter(m=>e.explore.section==="history"||!r.state.pairs[m.pairId]?.archived);if(o.length===0)return[Ie(e,i),C(null,[t("p",{text:"\uD398\uC5B4\uB97C \uB9CC\uB4E4\uBA74 \uB450 \uC8FC\uBBFC\uC758 \uC774\uC57C\uAE30 \uD0D0\uD5D8\uC774 \uC5F4\uB824\uC694."}),t("p",{className:"muted",text:"1\uD3B8\uC740 \uD55C \uC8FC\uBBFC\uB9CC \uACF5\uBC29\uC5D0 \uC640 \uC788\uC5B4\uB3C4 \uB5A0\uB0A0 \uC218 \uC788\uC5B4\uC694."}),w("\uC8FC\uBBFC \uD654\uBA74\uC73C\uB85C",()=>i.navigate("residents"),{variant:"secondary"})])];let s=o.find(m=>m.pairId===e.explore.pairId)??o[0],l=s.episodes.some(m=>m.index===e.explore.selectedEpisode)?e.explore.selectedEpisode:s.episodes.find(m=>m.status!=="read")?.index??2,d=e.explore.section==="history"?"history":"episode",c=[["episode","\uD0D0\uD5D8 \uC900\uBE44"],["history","\uC77D\uC740 \uC774\uC57C\uAE30"]];return[Ie(e,i),ni(e,r,o,i),t("div",{className:"pill-tabs",attrs:{role:"group","aria-label":"\uC774\uC57C\uAE30 \uD654\uBA74"}},c.map(([m,g])=>t("button",{className:`pill-tab${d===m?" current":""}`,text:g,attrs:{type:"button","aria-pressed":d===m?"true":"false"},on:{click:()=>i.setExploreSection(m)}}))),d==="episode"?t("section",{className:"card trail-card",attrs:{"aria-label":`${s.arc.place} \uC9C0\uB3C4`}},[ii(s,l),t("span",{className:"place-sign",text:s.arc.place})]):null,d==="episode"?C(s.arc.title,[oi(s,l,i),si(e,r,a,s,s.episodes[l],i)],{className:"arc-card"}):null,d==="episode"?di(e,r,o,a):null,d==="history"?li(e,s,i):null]}function Wr(e,r){let a=e.world?.state==="ready"?e.world.value:null;return P(e,r,{top:{kind:"sub",title:"\uD0D0\uC0AC",back:{route:"home",label:"\uD648"},resources:!0},backdrop:"forest",body:a&&e.content?ci(e,a,e.content,r):[M("\uC138\uACC4\uB97C \uBD88\uB7EC\uC624\uB294 \uC911\u2026")],nav:!0})}var mi={calm:"affection",surprise:"curiosity",worry:"fluster",thinking:"inspiration",shy:"fluster"},pi={joy:"\u266A",affection:"\u2661",curiosity:"?",fluster:"\u{1F4A7}",inspiration:"\u2726",annoyance:"\u{1F4A2}"};function zr(e){let r=e in Ue?e:mi[e];return r?E(Ue[r],{className:"emotion-bubble emotion-art",fallback:()=>t("span",{className:"emotion-bubble",text:pi[r]})}):null}function Ce(e,r){return e.state.residents[r]?.displayName??"\uC8FC\uBBFC"}function ui(e,r,a,i){let n=a?.participants??[],o=i?.kind==="line"?i.speakerId:i?.kind==="choice"?i.askerId:null;return t("section",{className:"story-stage",attrs:{"aria-hidden":"true"}},[E(G.interior,{className:"stage-art",fallback:()=>t("span",{className:"stage-shelf"})}),t("div",{className:`stage-cast cast-${n.length}`},n.map(s=>{let l=r.state.residents[s];if(!l)return null;let d=o!==s?null:i?.kind==="line"?zr(i.emotion):zr("curiosity"),c=t("span",{className:`stage-spot${o===s?" speaking":""}`},[d,J(l)]),m=lt(l.image.placement);return c.style.setProperty("--mark-bottom",`${m.bottom}%`),c.style.setProperty("--mark-left",`${m.left}%`),c}))])}function gi(e,r,a,i){if(a.story.state==="loading")return t("div",{className:"dialogue-box loading",attrs:{role:"status"}},[t("p",{text:"\uC774\uC57C\uAE30\uB97C \uC4F0\uB294 \uC911\uC774\uC5D0\uC694\u2026"}),t("p",{className:"muted",text:"\uCC98\uC74C \uC5EC\uB294 \uC774\uC57C\uAE30\uB294 \uC5B8\uC5B4 \uBAA8\uB378\uC774 \uC9C0\uAE08 \uC368\uC694. \uC7A0\uC2DC \uAC78\uB9B4 \uC218 \uC788\uC5B4\uC694."})]);if(a.story.state==="error")return t("div",{className:"dialogue-box error",attrs:{role:"alert"}},[t("p",{text:a.story.message}),t("div",{className:"row-actions"},[w("\uAC19\uC740 \uC774\uC57C\uAE30\uB85C \uB2E4\uC2DC \uC2DC\uB3C4",()=>i.retryStory()),w("\uB2EB\uAE30",()=>i.closeStory(),{variant:"secondary"})])]);let o=a.story.value.segments;if(a.index>=o.length){let d=!!e.busy[`read:${a.storyId}`];return t("div",{className:"dialogue-box end"},[t("p",{className:"end-line",text:"\uC774\uC57C\uAE30\uB294 \uC5EC\uAE30\uAE4C\uC9C0\uC608\uC694."}),t("p",{className:"muted",text:"\uB2E4 \uC77D\uC73C\uBA74 \uC774 \uC7A5\uBA74\uC744 \uD568\uAED8\uD55C \uC8FC\uBBFC\uB4E4\uC758 \uAE30\uC5B5\uC5D0 \uB0A8\uC544\uC694."}),w(d?"\uAE30\uB85D\uD558\uB294 \uC911\u2026":"\uB2E4 \uC77D\uC74C",()=>{i.finishStory()},{disabled:d,attrs:{"data-wide":""}})])}let l=o[a.index];if(l.kind==="choice"){let d=mt(r,a),c=d?.choice?.optionId??null,m=!!e.busy[`choose:${a.storyId}`],g=l.question.length+l.options.reduce((f,b)=>f+b.text.length,0)>150;return g&&(a.choiceView??"question")==="question"?t("div",{className:"dialogue-box choice"},[t("span",{className:"speaker-tag"},[p.leaf("icon tiny"),Ce(r,l.askerId)]),t("p",{className:"line",text:l.question}),w("\uB2F5\uBCC0 \uACE0\uB974\uAE30",()=>i.setChoiceView("answers"))]):t("div",{className:"dialogue-box choice"},[t("span",{className:"speaker-tag"},[p.leaf("icon tiny"),Ce(r,l.askerId)]),g?w("\uC9C8\uBB38 \uB2E4\uC2DC \uBCF4\uAE30",()=>i.setChoiceView("question"),{variant:"secondary"}):t("p",{className:"line",text:l.question}),t("div",{className:"choice-options",attrs:{role:"group","aria-label":"\uB300\uB2F5 \uACE0\uB974\uAE30"}},l.options.map(f=>t("button",{className:`choice-option${c===f.optionId?" chosen":""}`,text:f.text,attrs:{type:"button","aria-pressed":c===f.optionId?"true":"false"},disabled:m||c!==null||d?.state==="read",on:{click:()=>{i.chooseAnswer(f.optionId)}}}))),c||d?.state==="read"?t("p",{className:"muted",text:c?"\uC774\uBBF8 \uB300\uB2F5\uD588\uC5B4\uC694.":"\uB2E4\uC2DC \uC77D\uC744 \uB54C\uB294 \uB300\uB2F5\uC774 \uB0A8\uC9C0 \uC54A\uC544\uC694."}):t("p",{className:"muted",text:"\uB300\uB2F5\uC740 \uD55C \uBC88\uB9CC \uD560 \uC218 \uC788\uC5B4\uC694. \uBB3C\uC5B4\uBCF8 \uC8FC\uBBFC\uB9CC \uAE30\uC5B5\uD574\uC694."})])}return t("div",{className:`dialogue-box${l.kind==="narration"?" narration-only":""}`},[l.kind==="line"?t("span",{className:"speaker-tag"},[p.leaf("icon tiny"),Ce(r,l.speakerId)]):null,t("p",{className:l.kind==="line"?"line":"narration",text:(a.textPages??ge(l))[a.textPage??0]??l.text})])}function mt(e,r){let a=e.state.stories.pairs[r.pairId];return[a?.current,...a?.completed??[]].find(n=>n?.episodes[r.episode]?.storyId===r.storyId)?.episodes[r.episode]}function fi(e,r,a){let i=r.story.state==="ready"?r.story.value:null,n=i?i.segments.slice(0,Math.min(r.index+1,i.segments.length)):[],o=Math.max(1,n.length),s=Math.min(r.backlogPage??o-1,o-1);return L("fw-backlog","\uAE30\uB85D",[t("ol",{className:"backlog-list"},n.slice(s,s+1).map(l=>t("li",{className:`backlog-${l.kind}`},[l.kind==="line"?t("strong",{text:Ce(e,l.speakerId)}):l.kind==="choice"?t("strong",{text:Ce(e,l.askerId)}):null,t("span",{text:l.kind==="choice"?l.question:l.text})]))),o>1?t("div",{className:"resident-pages"},[w("\uC774\uC804",()=>a.setBacklogPage(s-1),{variant:"secondary",disabled:s===0}),t("span",{text:`${s+1} / ${o}`,attrs:{"aria-live":"polite"}}),w("\uB2E4\uC74C",()=>a.setBacklogPage(s+1),{variant:"secondary",disabled:s+1>=o})]):null,w("\uB2EB\uAE30",()=>a.toggleBacklog(),{variant:"secondary",attrs:{"data-wide":""}})])}function Lr(e,r){let a=e.world?.state==="ready"?e.world.value:null,i=e.reader;if(!a||!i)return P(e,r,{top:{kind:"sub",title:"\uACF5\uBC29 \uC774\uC57C\uAE30",back:{route:"explore",label:"\uD0D0\uC0AC"},resources:!1},backdrop:"wood",body:[t("p",{className:"muted",text:"\uC5F4\uB9B0 \uC774\uC57C\uAE30\uAC00 \uC5C6\uC5B4\uC694."})],nav:!0});let n=i.story.state==="ready"?i.story.value:null,o=n?.segments.length??0,s=n?.segments[i.index],l=i.textPages??ge(s),d=(i.textPage??0)>=l.length-1,c=s?.kind==="choice"&&!mt(a,i)?.choice&&mt(a,i)?.state!=="read",m=t("div",{className:"resources reader-tools"},[t("button",{className:"chip-button",attrs:{type:"button","aria-pressed":i.backlog?"true":"false"},disabled:!n,on:{click:()=>r.toggleBacklog()}},[p.book("icon"),t("span",{text:"\uAE30\uB85D"})]),t("button",{className:`chip-button${i.auto?" active":""}`,attrs:{type:"button","aria-pressed":i.auto?"true":"false"},disabled:!n,on:{click:()=>r.toggleAuto()}},[p.chevron("icon"),t("span",{text:i.auto?"\uC790\uB3D9 \uB044\uAE30":"\uC790\uB3D9"})])]),g=P(e,r,{top:{kind:"sub",title:"\uACF5\uBC29 \uC774\uC57C\uAE30",subtitle:n?.title??"\uC774\uC57C\uAE30",resources:!1,counters:m},backdrop:"wood",storyLayout:!0,body:[ui(ee(e),a,n,s),gi(e,a,i,r),n&&i.index<o?t("div",{className:"reader-foot"},[t("span",{className:"count-pill",text:`${i.index+1} / ${o}`}),w(i.index===o-1&&d?"\uB2E4 \uC77D\uACE0 \uBCF4\uAD00":"\uACC4\uC18D",()=>{i.index===o-1&&d?r.finishStory():r.advanceStory()},{disabled:c||!!e.busy[`read:${i.storyId}`],attrs:{"data-wide":""}})]):null],nav:!1,sheet:i.backlog?fi(a,i,r):null}),f=g.querySelector(".back-button, .back-spacer");if(f){let b=t("button",{className:"back-button",attrs:{type:"button","aria-label":"\uC774\uC57C\uAE30 \uB2EB\uAE30"},on:{click:()=>r.closeStory()}},[p.back()]);f.replaceWith(b)}return g}var jr,pt=!1;function Fe(e){let r=()=>{clearTimeout(jr),jr=setTimeout(()=>{!pt&&a.isConnected&&e.onSearch(a.value)},300)},a=t("input",{className:"search-input",attrs:{id:e.id,type:"search",placeholder:e.placeholder,value:e.value,autocomplete:"off"},on:{compositionstart:()=>pt=!0,compositionend:()=>{pt=!1,r()},input:()=>r()}});return t("label",{className:"search-field",attrs:{for:e.id}},[p.search("icon"),t("span",{className:"visually-hidden",text:e.placeholder}),a])}function ut(e){let r=(a,i)=>t("li",{className:`step-item${e===a?" current":e>a?" done":""}`,attrs:e===a?{"aria-current":"step"}:{}},[t("span",{className:"step-number",text:String(a)}),t("span",{className:"step-label",text:i})]);return t("ol",{className:"steps card",attrs:{"aria-label":"\uC8FC\uBBFC \uB4F1\uB85D \uB2E8\uACC4"}},[r(1,"\uC790\uB8CC \uC120\uD0DD"),t("li",{className:"step-arrow",attrs:{"aria-hidden":"true"},text:"\u2192"}),r(2,"\uACF5\uBC29 \uC124\uC815"),t("li",{className:"step-arrow",attrs:{"aria-hidden":"true"},text:"\u2192"}),r(3,"\uC2DC\uC791 \uC8FC\uBBFC")])}function hi(e,r){if(e.sources.state==="loading")return M("\uCE90\uB9AD\uD130\xB7\uD398\uB974\uC18C\uB098\uB97C \uBD88\uB7EC\uC624\uB294 \uC911\u2026");if(e.sources.state==="error")return t("div",{},[Y(e.sources.message),w("\uB2E4\uC2DC \uBD88\uB7EC\uC624\uAE30",()=>{r.loadSources()},{variant:"secondary"})]);let a=e.query.trim().toLowerCase(),i=e.sources.value.filter(s=>s.kind===e.kindTab).filter(s=>!a||s.name.toLowerCase().includes(a));if(i.length===0)return t("p",{className:"empty",text:a?"\uC774\uB984\uC774 \uB9DE\uB294 \uC790\uB8CC\uAC00 \uC5C6\uC5B4\uC694.":`${$e[e.kindTab]}\uAC00 \uC544\uC9C1 \uC5C6\uC5B4\uC694. \uC5D4\uC9C4\uC758 \uC11C\uC7AC\uC5D0\uC11C \uBA3C\uC800 \uB9CC\uB4E4\uC5B4 \uC8FC\uC138\uC694.`});let n=Math.ceil(i.length/2),o=Math.min(e.sourcePage??0,n-1);return t("div",{className:"source-pages"},[t("ul",{className:"source-list"},i.slice(o*2,o*2+2).map(s=>t("li",{},[t("button",{className:"menu-row source-row",attrs:{type:"button"},disabled:s.residentId!==null,on:{click:()=>{r.chooseSource(s)}}},[E(le.portrait,{className:"manage-art",fallback:()=>p.document()}),t("span",{className:"menu-text"},[t("span",{className:"menu-title",text:s.name}),t("span",{className:"menu-detail",text:s.residentId?"\uC774\uBBF8 \uC774 \uC138\uACC4\uC758 \uC8FC\uBBFC\uC774\uC5D0\uC694":s.summary||"\uC124\uBA85 \uC5C6\uC74C"})]),t("span",{className:"menu-chevron"},[s.residentId?p.check():p.chevron()])])]))),n>1?t("div",{className:"resident-pages"},[w("\uC774\uC804",()=>r.setRegisterSourcePage(o-1),{variant:"secondary",disabled:o===0}),t("span",{text:`${o+1} / ${n}`,attrs:{"aria-live":"polite"}}),w("\uB2E4\uC74C",()=>r.setRegisterSourcePage(o+1),{variant:"secondary",disabled:o+1>=n})]):null])}function bi(e,r){return[C("\uC790\uB8CC \uC120\uD0DD",[t("p",{className:"muted",text:"\uC8FC\uBBFC\uC73C\uB85C \uB9DE\uC774\uD560 \uCE90\uB9AD\uD130\uB098 \uD398\uB974\uC18C\uB098\uB97C \uACE8\uB77C \uC8FC\uC138\uC694. \uC6D0\uBCF8\uC740 \uC77D\uAE30\uB9CC \uD558\uACE0 \uBC14\uAFB8\uC9C0 \uC54A\uC544\uC694."}),t("div",{className:"pill-tabs two",attrs:{role:"tablist","aria-label":"\uC790\uB8CC \uC885\uB958"}},["character","persona"].map(a=>t("button",{className:`pill-tab${e.kindTab===a?" current":""}`,text:$e[a],attrs:{type:"button",role:"tab","aria-selected":e.kindTab===a?"true":"false"},on:{click:()=>r.setRegisterKind(a)}}))),Fe({id:"fw-source-search",value:e.query,placeholder:"\uC774\uB984\uC73C\uB85C \uCC3E\uAE30",onSearch:a=>r.setRegisterQuery(a)}),hi(e,r)],{id:"fw-source-title"})]}function wi(e){if(!e||e.state==="loading")return M("\uC6D0\uB798 \uC124\uC815\uC744 \uC77D\uB294 \uC911\u2026");if(e.state==="error")return Y(e.message);let r=e.value;return t("div",{className:"readonly-box"},[t("p",{text:r.summary||"\uC6D0\uBCF8\uC5D0 \uC801\uD78C \uC124\uBA85\uC774 \uC5C6\uC5B4\uC694."})])}function yi(e,r){if(!r||r.state!=="ready"||!e.content)return null;let a=oe(e.content,r.value.talent.talentId),i=r.value.talent.field;return t("div",{className:"talent-card",attrs:{"aria-label":"\uB9DE\uC774\uD558\uBA74 \uC815\uD574\uC9C0\uB294 \uC804\uBB38 \uBD84\uC57C\uC640 \uD2B9\uAE30"}},[t("p",{className:"talent-field"},[fe[i]("icon"),t("strong",{text:`\uC804\uBB38 \uBD84\uC57C \xB7 ${re[i]}`})]),a?t("p",{className:"talent-name"},[t("strong",{text:`\uD2B9\uAE30 \xB7 ${a.name}`}),t("span",{text:a.description})]):null,t("p",{className:"muted",text:"\uC6D0\uB798 \uC124\uC815\uC744 \uBC14\uD0D5\uC73C\uB85C \uC815\uD574\uC838\uC694. \uC8FC\uBBFC\uC744 \uB9DE\uC774\uD558\uBA74 \uBC14\uB00C\uC9C0 \uC54A\uC544\uC694."})])}function vi(e,r,a){let i=t("input",{className:"visually-hidden",attrs:{id:"fw-register-image",type:"file",accept:"image/png,image/webp"},on:{change:()=>{let o=i.files?.[0];if(i.value="",!!o){if(o.size>a){r.notify(`\uD30C\uC77C\uC774 ${Math.round(a/1024/1024)}MiB\uB97C \uB118\uC5B4\uC694. \uB2E4\uB978 \uADF8\uB9BC\uC744 \uACE8\uB77C \uC8FC\uC138\uC694.`,"error");return}r.pickPendingImage(o)}}}}),n=e.pendingImage;return t("div",{className:"image-drop"},[i,t("label",{className:"drop-zone checker",attrs:{for:"fw-register-image"}},[n?t("img",{className:"drop-preview",attrs:{src:n.previewUrl,alt:""}}):p.addImage("icon drop-icon"),t("span",{className:"drop-text"},[t("strong",{text:n?n.file.name:"\uC8FC\uBBFC \uADF8\uB9BC \uC9C1\uC811 \uB4F1\uB85D"}),t("span",{text:n?`${Math.max(1,Math.round(n.file.size/1024))} KB \xB7 \uB4F1\uB85D\uD558\uBA74 WebP\uB85C \uC800\uC7A5\uD574\uC694`:"PNG \xB7 WebP \u2192 WebP \uC800\uC7A5"})])]),n?w("\uACE0\uB978 \uADF8\uB9BC \uBE7C\uAE30",()=>r.clearPendingImage(),{variant:"secondary"}):null])}function xi(e,r,a){let i=e.selected,n=r.content?.residents.worldSettingMax??200,o=!!r.busy["rebuild-suggestion"],s=!!r.busy[`register:${i.kind}:${i.id}`],l=Object.keys(r.busy).some(y=>y.startsWith("image-upload:")&&r.busy[y]),d=s||l,c=t("span",{className:"counter-text",text:`${e.draft.length} / ${n}`,attrs:{id:"fw-draft-count"}}),m=t("textarea",{className:"textarea",attrs:{id:"fw-world-setting",maxlength:String(n),rows:"4",placeholder:"\uC774 \uC138\uACC4\uC5D0\uC11C \uC5B4\uB5A4 \uC8FC\uBBFC\uC778\uC9C0 \uC801\uC5B4 \uC8FC\uC138\uC694.","aria-describedby":"fw-world-setting-help fw-draft-count"},on:{input:()=>{c.textContent=`${m.value.length} / ${n}`,a.setDraft(m.value),b.disabled=!m.value.trim()}}});m.value=e.draft;let g=e.preview?.state==="ready",f=e.panel??"source",b=w("\uB2E4\uC74C: \uC8FC\uBBFC \uADF8\uB9BC",()=>a.setRegisterPanel("image"),{disabled:!e.draft.trim()});return[t("section",{className:"card selected-source"},[t("button",{className:"menu-row quiet",attrs:{type:"button"},on:{click:()=>a.backToSources()}},[E(le.portrait,{className:"manage-art",fallback:()=>p.document()}),t("span",{className:"menu-text"},[t("small",{className:"muted",text:"\uC120\uD0DD\uD55C \uC790\uB8CC"}),t("span",{className:"menu-title",text:`${$e[i.kind]} \xB7 ${i.name}`})]),t("span",{className:"menu-chevron"},[p.chevron()])])]),f==="source"?t("section",{className:"card rebuild",attrs:{"aria-labelledby":"fw-original"}},[t("h2",{className:"section-title doc",text:"\uC6D0\uB798 \uC124\uC815",attrs:{id:"fw-original"}}),wi(e.preview),yi(r,e.preview),w("\uB2E4\uC74C: \uACF5\uBC29 \uC124\uC815",()=>a.setRegisterPanel("setting"),{disabled:!g})]):null,f==="setting"?t("section",{className:"card rebuild"},[t("label",{className:"section-title",text:"\uACF5\uBC29 \uC138\uACC4 \uC124\uC815",attrs:{for:"fw-world-setting"}}),t("p",{className:"muted",text:"\uC774 \uC8FC\uBBFC\uC774 \uACF5\uBC29\uC5D0\uC11C \uC5B4\uB5A4 \uBAA8\uC2B5\uC778\uC9C0 \uD55C\uB450 \uBB38\uC7A5\uC73C\uB85C \uC801\uC5B4 \uC8FC\uC138\uC694. \uB0B4\uC6A9\uC744 \uC801\uC73C\uBA74 \uB2E4\uC74C\uC73C\uB85C \uAC08 \uC218 \uC788\uC5B4\uC694.",attrs:{id:"fw-world-setting-help"}}),t("div",{className:"textarea-wrap"},[m,c]),t("div",{className:"rule-actions even"},[t("button",{className:"button",attrs:{type:"button"},on:{click:()=>{m.focus(),m.setSelectionRange(m.value.length,m.value.length)}}},[p.pencil("icon"),t("span",{text:"\uC218\uC815"})]),t("button",{className:"button secondary",attrs:{type:"button"},disabled:o||!g,on:{click:()=>{a.suggestSetting()}}},[p.sparkle("icon"),t("span",{text:o?"\uC81C\uC548 \uBC1B\uB294 \uC911\u2026":"\uB2E4\uC2DC \uC81C\uC548"})])]),t("p",{className:"hint",text:"\uB2E4\uC2DC \uC81C\uC548\uC740 \uC5D4\uC9C4\uC758 \uAE30\uBCF8 \uC5B8\uC5B4 \uBAA8\uB378\uC5D0 \uD55C \uBC88 \uC694\uCCAD\uD574\uC694. \uD655\uC815\uD558\uAE30 \uC804\uC5D0\uB294 \uC800\uC7A5\uB418\uC9C0 \uC54A\uC544\uC694."}),t("div",{className:"rule-actions even"},[w("\uC774\uC804",()=>a.setRegisterPanel("source"),{variant:"secondary"}),b])]):null,f==="image"?C("\uC8FC\uBBFC \uADF8\uB9BC \uC9C1\uC811 \uB4F1\uB85D",[vi(e,a,r.content?.residents.maxImageBytes??20*1024*1024),t("p",{className:"hint center"},[p.info("icon"),"\uC6D0\uBCF8 \uD504\uB85C\uD544\uC740 \uBC14\uB00C\uC9C0 \uC54A\uC544\uC694."])],{id:"fw-register-image-title"}):null,f==="image"?t("button",{className:"button big-action",attrs:{type:"button","data-wide":""},disabled:d||!g,on:{click:()=>{a.confirmRegister(!0,(y,u)=>a.uploadResidentImage(y,u))}}},[p.leaf("icon"),t("span",{text:s?"\uB4F1\uB85D\uD558\uB294 \uC911\u2026":l?"\uADF8\uB9BC \uC800\uC7A5 \uC911\u2026":"\uC8FC\uBBFC \uB4F1\uB85D\uD558\uAE30"}),p.chevron("icon")]):null,f==="image"?t("button",{className:"button secondary",attrs:{type:"button","data-wide":""},disabled:d||!g,on:{click:()=>{a.confirmRegister(!1,async()=>{})}}},[p.clock("icon"),t("span",{text:"\uADF8\uB9BC \uC5C6\uC774 \uC8FC\uBBFC \uB4F1\uB85D"})]):null,f==="image"?w("\uC774\uC804: \uACF5\uBC29 \uC124\uC815",()=>a.setRegisterPanel("setting"),{variant:"secondary"}):null]}function ki(e,r,a,i){let n=Object.values(r.state.residents),o=!!a.busy["choose-starter"],s=Math.max(1,n.length),l=Math.min(e.starterPage??0,s-1);return[C("\uC2DC\uC791 \uC8FC\uBBFC",[t("p",{className:"muted",text:"\uACF5\uBC29\uC5D0\uC11C \uD568\uAED8 \uC2DC\uC791\uD560 \uC8FC\uBBFC \uD55C \uBA85\uC744 \uACE8\uB77C \uC8FC\uC138\uC694. \uB2E4\uB978 \uC8FC\uBBFC\uC740 \uCD08\uB300\uB85C \uB9DE\uC774\uD574\uC694."}),t("ul",{className:"starter-list",attrs:{role:"radiogroup","aria-label":"\uC2DC\uC791 \uC8FC\uBBFC"}},n.slice(l,l+1).map(d=>t("li",{},[t("button",{className:`starter-option${e.starterChoice===d.residentId?" chosen":""}`,attrs:{type:"button",role:"radio","aria-checked":e.starterChoice===d.residentId?"true":"false"},on:{click:()=>i.setStarterChoice(d.residentId)}},[t("span",{className:"starter-stage"},[J(d)]),t("strong",{text:d.displayName}),U(d)])]))),s>1?t("div",{className:"resident-pages"},[w("\uC774\uC804",()=>i.setRegisterStarterPage(l-1),{variant:"secondary",disabled:l===0}),t("span",{text:`${l+1} / ${s}`,attrs:{"aria-live":"polite"}}),w("\uB2E4\uC74C",()=>i.setRegisterStarterPage(l+1),{variant:"secondary",disabled:l+1>=s})]):null],{id:"fw-starter-title"}),t("button",{className:"button big-action",attrs:{type:"button","data-wide":""},disabled:o||!e.starterChoice,on:{click:()=>{i.confirmStarter()}}},[p.house("icon"),t("span",{text:o?"\uB9DE\uC774\uD558\uB294 \uC911\u2026":e.starterChoice?`${r.state.residents[e.starterChoice]?.displayName??"\uC120\uD0DD\uD55C \uC8FC\uBBFC"}\uACFC(\uC640) \uC2DC\uC791\uD558\uAE30`:"\uC8FC\uBBFC\uC744 \uACE8\uB77C \uC8FC\uC138\uC694"})]),w("\uC8FC\uBBFC \uB354 \uB4F1\uB85D\uD558\uAE30",()=>i.registerAnother(),{variant:"secondary",attrs:{"data-wide":""}})]}function Or(e,r){let a=e.world?.state==="ready"?e.world.value:null,i=e.register,n;return!a||!i?n=[M("\uC138\uACC4\uB97C \uBD88\uB7EC\uC624\uB294 \uC911\u2026")]:i.step===3?n=[ut(3),...ki(i,a,e,r)]:i.step===2&&i.selected?n=[ut(2),...xi(i,e,r)]:n=[ut(1),...bi(i,r)],P(e,r,{top:{kind:"sub",title:"\uC8FC\uBBFC \uB4F1\uB85D",back:{route:"residents",label:"\uC8FC\uBBFC"},resources:!1},backdrop:"wood",body:n,nav:!1})}var Br="ABCDEFGHIJKLMNOPQRSTUVWXYZ";function Ni(e,r){return[...e?.relationStages??[]].reverse().find(i=>r>=i.from)?.label??"\u2013"}function Dr(e,r,a){return a.state.residents[tt(e,r.residentId)]??null}function Si(e,r){let a=r.map((i,n)=>`A\u2013${Br[n+1]??"?"}`).join(" \xB7 ");return C(null,[t("div",{className:"relation-hero"},[O(e,"large"),t("span",{className:"hero-label",text:`\uACF5\uC720 \uC8FC\uBBFC \xB7 ${e.displayName}`}),t("strong",{className:"hero-pairs",text:r.length?a:"\uC544\uC9C1 \uD398\uC5B4\uAC00 \uC5C6\uC5B4\uC694"}),t("p",{className:"hero-note",text:r.length>1?"\uB450 \uAD00\uACC4\uB294 \uAC19\uC740 \uC138\uACC4\uC5D0\uC11C \uC774\uC5B4\uC838\uC694":r.length===1?"\uAC19\uC740 \uC138\uACC4\uC5D0\uC11C \uC774\uC5B4\uC9C0\uB294 \uAD00\uACC4\uC608\uC694":"\uB2E4\uB978 \uC8FC\uBBFC\uACFC \uD398\uC5B4\uB97C \uB9CC\uB4E4 \uC218 \uC788\uC5B4\uC694"})])],{className:"hero-card"})}function Vr(e,r,a){return t("button",{className:"button secondary",attrs:{type:"button"},on:{click:a}},[E(le[e],{className:"action-art",fallback:()=>p.book("icon")}),t("span",{text:r})])}function $i(e,r,a,i,n,o){let s=Dr(e,a,i),l=n.relationsEditing,d=!!n.busy[`pair-archive:${e.pairId}`];return t("li",{className:"pair-row card"},[t("div",{className:"pair-faces"},[t("span",{className:"pair-letters"},[t("span",{className:"letter",text:"A"}),"\xD7",t("span",{className:"letter",text:Br[r+1]??"?"})]),t("span",{className:"faces"},[O(a),t("span",{className:"times",text:"\xD7"}),O(s)]),t("span",{className:"partner-name",text:s?.displayName??"\uC54C \uC218 \uC5C6\uB294 \uC8FC\uBBFC"})]),t("div",{className:"pair-info"},[t("div",{className:"relation-now"},[t("small",{text:"\uD604\uC7AC \uAD00\uACC4"}),t("strong",{text:Ni(n.content,e.familiarity)})]),t("p",{className:"recent"},[t("span",{className:"recent-label",text:"\uCD5C\uADFC \uC0AC\uAC74"}),t("span",{text:e.lastEvent?.summary??"\uC544\uC9C1 \uC5C6\uC5B4\uC694"})]),l?t("div",{className:"pair-actions"},[w(d?"\uBCF4\uAD00 \uC911\u2026":"\uBCF4\uAD00",()=>{o.archivePair(e.pairId)},{variant:"secondary",disabled:d})]):t("div",{className:"pair-actions"},[Vr("memory","\uAE30\uC5B5 \uBCF4\uAE30",()=>o.openMemory(e.pairId)),Vr("guidelines","\uC9C0\uCE68 \uAD00\uB9AC",()=>o.openGuidelines(e.pairId))])])])}function Ii(e,r,a,i,n){return e.length===0?null:C("\uBCF4\uAD00\uD55C \uD398\uC5B4",[t("ul",{className:"archived-list"},e.map(o=>{let s=Dr(o,r,a),l=!!i.busy[`pair-restore:${o.pairId}`];return t("li",{className:"archived-row"},[O(s),t("span",{className:"archived-name",text:`${r.displayName} \xD7 ${s?.displayName??"?"}`}),w(l?"\uB418\uB3CC\uB9AC\uB294 \uC911\u2026":"\uB418\uB3CC\uB9AC\uAE30",()=>{n.restorePair(o.pairId)},{variant:"secondary",disabled:l})])}))],{id:"fw-archived"})}function Ci(e,r,a,i){let n=new Map(Object.values(r.state.pairs).filter(s=>s.residentIds.includes(e.residentId)).map(s=>[tt(s,e.residentId),s.archived])),o=Object.values(r.state.residents).filter(s=>s.residentId!==e.residentId);return t("div",{className:"sheet-backdrop"},[t("section",{className:"sheet card",attrs:{role:"dialog","aria-modal":"true","aria-labelledby":"fw-pair-add"}},[t("h2",{className:"section-title",text:"\uD398\uC5B4 \uCD94\uAC00",attrs:{id:"fw-pair-add"}}),t("p",{className:"muted",text:`${e.displayName}\uC640(\uACFC) \uC774\uC5B4\uC9C8 \uC8FC\uBBFC\uC744 \uACE8\uB77C \uC8FC\uC138\uC694. \uCE90\uB9AD\uD130\uB4E0 \uD398\uB974\uC18C\uB098\uB4E0 \uAD1C\uCC2E\uC544\uC694. \uC9C0\uB09C \uAE30\uC5B5\uC774 \uC0C8\uB85C \uC0DD\uAE30\uC9C0\uB294 \uC54A\uC544\uC694.`}),o.length===0?t("p",{className:"empty",text:"\uD568\uAED8\uD560 \uB2E4\uB978 \uC8FC\uBBFC\uC774 \uC544\uC9C1 \uC5C6\uC5B4\uC694. \uC8FC\uBBFC \uBD88\uB7EC\uC624\uAE30\uC5D0\uC11C \uBA3C\uC800 \uB4F1\uB85D\uD574 \uC8FC\uC138\uC694."}):t("ul",{className:"candidate-list"},o.map(s=>{let l=n.has(s.residentId),d=et(e.residentId,s.residentId);return t("li",{},[t("button",{className:"candidate",attrs:{type:"button"},disabled:l||!!a.busy[d],on:{click:()=>{i.addPair(e.residentId,s.residentId)}}},[O(s),t("span",{className:"candidate-name",text:s.displayName}),U(s),t("span",{className:"candidate-state",text:l?n.get(s.residentId)?"\uBCF4\uAD00\uD568\uC5D0 \uC788\uC5B4\uC694":"\uC774\uBBF8 \uD398\uC5B4":a.busy[d]?"\uB9CC\uB4DC\uB294 \uC911\u2026":"\uACE0\uB974\uAE30"})])])})),w("\uB2EB\uAE30",()=>i.closeSheet(),{variant:"secondary",attrs:{"data-wide":""}})])])}function Fr(e,r){let a=e.world?.state==="ready"?e.world.value:null,i=a?a.state.residents[e.focusResidentId??""]??null:null,n={top:{kind:"sub",title:"\uAD00\uACC4",subtitle:"\uAC19\uC740 \uC138\uACC4\uC5D0\uC11C \uC774\uC5B4\uC9C0\uB294 \uAD00\uACC4",back:{route:"residents",label:"\uC8FC\uBBFC"},resources:!1},backdrop:"forest",nav:!0};if(!a||!i)return P(e,r,{...n,body:[M(a?"\uC8FC\uBBFC\uC744 \uACE0\uB978 \uB4A4 \uAD00\uACC4\uB97C \uC5F4\uC5B4 \uC8FC\uC138\uC694.":"\uC138\uACC4\uB97C \uBD88\uB7EC\uC624\uB294 \uC911\u2026")]});let o=Object.values(a.state.pairs).filter(l=>l.residentIds.includes(i.residentId)).sort((l,d)=>l.createdAt.localeCompare(d.createdAt)),s=o.filter(l=>!l.archived);return P(e,r,{...n,body:[Si(i,s),t("ul",{className:"pair-list"},s.map((l,d)=>$i(l,d,i,a,e,r))),t("p",{className:"notice-strip"},[t("span",{className:"bang",text:"!"}),"\uD398\uC5B4 \uC9C0\uC815\uC740 \uC5F0\uC778 \uC120\uC5B8\uC774 \uC544\uB2C8\uC5D0\uC694."]),t("div",{className:"rule-actions"},[t("button",{className:"button wide-main",attrs:{type:"button"},on:{click:()=>r.openSheet({kind:"pair-add",residentId:i.residentId})}},[p.people("icon"),t("span",{text:"\uD398\uC5B4 \uCD94\uAC00"})]),t("button",{className:`button secondary${e.relationsEditing?" pressed":""}`,attrs:{type:"button","aria-pressed":e.relationsEditing?"true":"false"},on:{click:()=>r.toggleRelationsEditing()}},[p.archive("icon"),t("span",{text:e.relationsEditing?"\uBCC0\uACBD \uB05D\uB0B4\uAE30":"\uBCC0\uACBD \xB7 \uBCF4\uAD00"})])]),e.relationsEditing?Ii(o.filter(l=>l.archived),i,a,e,r):null],sheet:e.sheet?.kind==="pair-add"?Ci(i,a,e,r):null})}function Gr(e){return`${Math.max(1,Math.round(e/1024)).toLocaleString("ko-KR")} KB`}function gt(e,r,a,i,n,o,s){let l=`fw-placement-${e}`,d=t("span",{className:"slider-value",text:s(i)}),c=t("input",{className:"slider",attrs:{id:l,type:"range",min:String(n.min),max:String(n.max),step:"1",value:String(i),"aria-valuetext":s(i)},on:{input:()=>d.textContent=s(Number(c.value)),change:()=>o.setPlacementDraft({[e]:Number(c.value)})}});return t("div",{className:"setting-row slider-row"},[r("icon"),t("label",{className:"setting-label",text:a,attrs:{for:l}}),c,d])}function Ri(e,r,a){let i=!!r.busy[`image-restore:${e.residentId}`],n=o=>t("li",{className:"history-item"},[t("span",{className:"history-thumb checker"},[t("img",{attrs:{src:o.url,alt:""}})]),t("span",{className:"menu-text"},[t("span",{className:"menu-title",text:o.fileName||"\uC774\uC804 \uADF8\uB9BC"}),t("span",{className:"menu-detail",text:`${o.width} \xD7 ${o.height} \xB7 ${Gr(o.bytes)}`})]),w(i?"\uB418\uB3CC\uB9AC\uB294 \uC911\u2026":"\uC774 \uADF8\uB9BC\uC73C\uB85C",()=>{a.restoreResidentImage(e.residentId,o.reference)},{disabled:i})]);return t("div",{className:"sheet-backdrop"},[t("section",{className:"sheet card",attrs:{role:"dialog","aria-modal":"true","aria-labelledby":"fw-image-history"}},[t("h2",{className:"section-title",text:"\uC774\uC804 \uADF8\uB9BC",attrs:{id:"fw-image-history"}}),e.image.history.length?t("ul",{className:"history-list"},e.image.history.map(n)):t("p",{className:"empty",text:"\uB418\uB3CC\uB9B4 \uC774\uC804 \uADF8\uB9BC\uC774 \uC5C6\uC5B4\uC694."}),t("p",{className:"hint",text:"\uCD5C\uADFC 3\uC7A5\uAE4C\uC9C0 \uBCF4\uAD00\uD574\uC694. \uC9C0\uB09C \uC774\uC57C\uAE30 \uB2E4\uC2DC\uBCF4\uAE30\uC5D0\uB3C4 \uC9C0\uAE08 \uADF8\uB9BC\uC774 \uC4F0\uC5EC\uC694."}),w("\uB2EB\uAE30",()=>a.closeSheet(),{variant:"secondary",attrs:{"data-wide":""}})])])}function Ai(e,r,a){let i=r.content?.residents.placement,n=r.placementDraft??e.image.placement,o=e.image.current,s=!!r.busy[`image-upload:${e.residentId}`],l=!!r.busy[`placement:${e.residentId}`],d=JSON.stringify(n)!==JSON.stringify(e.image.placement),c=t("input",{className:"visually-hidden",attrs:{id:"fw-image-file",type:"file",accept:"image/png,image/webp"},disabled:s,on:{change:()=>{let g=c.files?.[0];c.value="",g&&a.uploadResidentImage(e.residentId,g)}}}),m=g=>g>0?`+${g}`:String(g);return[t("section",{className:"card image-card"},[t("p",{className:"target-ribbon"},[t("span",{className:"muted",text:"\uB300\uC0C1"}),p.leaf("icon"),t("strong",{text:e.displayName})]),t("div",{className:"image-stage checker"},[J(e,{placement:n,marker:!0})]),t("div",{className:"file-facts"},o?[t("strong",{text:o.fileName||"resident.webp"}),t("span",{text:`${o.width} \xD7 ${o.height} / ${Gr(o.bytes)}`})]:[t("strong",{text:"\uC544\uC9C1 \uADF8\uB9BC\uC774 \uC5C6\uC5B4\uC694"}),t("span",{className:"muted",text:"\uADF8\uB9BC\uC774 \uC5C6\uC5B4\uB3C4 \uBAA8\uB4E0 \uAE30\uB2A5\uC744 \uC4F8 \uC218 \uC788\uC5B4\uC694"})]),c,t("label",{className:`button big-action file-button${s?" busy":""}`,attrs:{for:"fw-image-file","data-wide":"","aria-disabled":s?"true":"false"}},[t("span",{text:s?"WebP\uB85C \uC800\uC7A5\uD558\uB294 \uC911\u2026":o?"\uD30C\uC77C \uC120\uD0DD \xB7 \uAD50\uCCB4":"\uD30C\uC77C \uC120\uD0DD"})]),t("ul",{className:"rules"},[t("li",{text:"PNG \xB7 \uC815\uC801 WebP \uC5C5\uB85C\uB4DC (20MiB \xB7 4096px\uAE4C\uC9C0)"}),t("li",{text:"\uD22C\uBA85\uB3C4 \uC720\uC9C0 \xB7 WebP \uD488\uC9C8 95 \uC800\uC7A5"}),t("li",{text:"PNG \uC6D0\uBCF8\uC740 \uB530\uB85C \uBCF4\uAD00\uD558\uC9C0 \uC54A\uC544\uC694."})]),i?t("div",{className:"setting-block sliders"},[gt("scale",p.zoom,"\uADF8\uB9BC \uD06C\uAE30",n.scale,i.scale,a,g=>`${g}%`),gt("offsetX",p.arrows,"\uC88C\uC6B0 \uC704\uCE58",n.offsetX,i.offsetX,a,m),gt("markerHeight",p.updown,"\uAC10\uC815 \uD45C\uC2DC \uB192\uC774",n.markerHeight,i.markerHeight,a,m)]):null,t("button",{className:"button big-action",attrs:{type:"button","data-wide":""},disabled:l||!d,on:{click:()=>{a.applyPlacement(e.residentId)}}},[t("span",{text:l?"\uC801\uC6A9\uD558\uB294 \uC911\u2026":d?"\uC801\uC6A9":"\uC801\uC6A9\uB428"})]),t("div",{className:"rule-actions even"},[t("button",{className:"button secondary",attrs:{type:"button"},on:{click:()=>a.resetPlacementDraft()}},[p.restore("icon"),t("span",{text:"\uAE30\uBCF8 \uBC30\uCE58"})]),t("button",{className:"button secondary",attrs:{type:"button"},disabled:e.image.history.length===0,on:{click:()=>a.openSheet({kind:"image-history",residentId:e.residentId})}},[p.image("icon"),t("span",{text:`\uC774\uC804 \uADF8\uB9BC${e.image.history.length?` ${e.image.history.length}`:""}`})])])])]}function _r(e,r){let a=e.world?.state==="ready"?e.world.value:null,i=a?a.state.residents[e.focusResidentId??""]??null:null;return P(e,r,{top:{kind:"sub",title:"\uC8FC\uBBFC \uADF8\uB9BC",back:{route:"residents",label:"\uC8FC\uBBFC"},resources:!1},backdrop:"wood",body:i?Ai(i,e,r):[M(a?"\uC8FC\uBBFC\uC744 \uACE0\uB978 \uB4A4 \uC8FC\uBBFC \uADF8\uB9BC\uC744 \uC5F4\uC5B4 \uC8FC\uC138\uC694.":"\uC138\uACC4\uB97C \uBD88\uB7EC\uC624\uB294 \uC911\u2026")],nav:!0,sheet:i&&e.sheet?.kind==="image-history"?Ri(i,e,r):null})}function qr(e,r,a,i){let n=r.state.residents[i],o=e.content;if(!n||!o)return null;let s=oe(o,n.talentId),l=o.facilities.find(d=>d.field===n.field);return L("fw-field",`${n.displayName}\uC758 \uC804\uBB38 \uBD84\uC57C \xB7 \uD2B9\uAE30`,[t("div",{className:"talent-card"},[t("p",{className:"talent-field"},[fe[n.field]("icon"),t("strong",{text:`${re[n.field]} \uBD84\uC57C`}),t("span",{className:"muted",text:` \xB7 ${l?.name??""}`})]),t("p",{className:"muted",text:`${l?.name??"\uAC19\uC740 \uBD84\uC57C \uC2DC\uC124"}\uC5D0 \uBC30\uCE58\uD558\uBA74 \uCC98\uB9AC \uC18D\uB3C4\uAC00 \uBE68\uB77C\uC838\uC694: \uAE30\uBCF8 ${q(ie(o,0))} \u2192 \uC9C0\uAE08 ${q(ie(o,n.breakthrough))} (\uB3CC\uD30C ${n.breakthrough}/${o.crew.maxBreakthrough}).`}),s?t("p",{className:"talent-name"},[t("strong",{text:`\uD2B9\uAE30 \xB7 ${s.name}`}),t("span",{text:s.description})]):null]),t("p",{className:"hint",text:"\uC804\uBB38 \uBD84\uC57C\uC640 \uD2B9\uAE30\uB294 \uC8FC\uBBFC\uC744 \uB9DE\uC774\uD560 \uB54C \uC6D0\uB798 \uC124\uC815\uC744 \uBC14\uD0D5\uC73C\uB85C \uC815\uD574\uC84C\uC5B4\uC694. \uC6D0\uBCF8 \uCE74\uB4DC\uB294 \uBC14\uB00C\uC9C0 \uC54A\uC544\uC694."}),w("\uB2EB\uAE30",()=>a.closeSheet(),{variant:"secondary",attrs:{"data-wide":""}})])}var Hr={registered:"\uB4F1\uB85D",setting:"\uC138\uACC4 \uC124\uC815 \uC218\uC815",name:"\uC774\uB984 \uC218\uC815",recruited:"\uC601\uC785",image:"\uADF8\uB9BC \uB4F1\uB85D",image_restored:"\uC774\uC804 \uADF8\uB9BC\uC73C\uB85C",image_history_cleared:"\uADF8\uB9BC \uC774\uB825 \uC815\uB9AC",placement:"\uBC30\uCE58 \uBCC0\uACBD"};function Kr(e){let r=new Date(e);return Number.isNaN(r.getTime())?e:new Intl.DateTimeFormat("ko-KR",{dateStyle:"medium",timeStyle:"short"}).format(r)}function ft(e,r){return r?t("div",{className:"source-field"},[t("strong",{text:e}),t("p",{text:r})]):null}function Mi(e){return t("li",{className:"change-row"},[t("span",{className:"change-kind",text:Hr[e.kind]??e.kind}),t("span",{className:"change-detail",text:e.detail}),t("time",{className:"change-time",text:Kr(e.at),attrs:{datetime:e.at}})])}function Ur(e,r,a,i){let n=e.state.residents[i];if(!n)return null;let o=r.content?.residents.worldSettingMax??200,s=!!r.busy[`resident-setting:${i}`],l=r.sheet?.kind==="profile"&&r.sheet.residentId===i?r.sheet:null,d=l?.draft??n.worldSetting,c=t("span",{className:"counter-text",text:`${d.length} / ${o}`}),m=t("textarea",{className:"textarea",attrs:{id:"fw-profile-setting",maxlength:String(o),rows:"4","aria-describedby":"fw-profile-count"},on:{input:()=>{c.textContent=`${m.value.length} / ${o}`,a.rememberProfile({draft:m.value})}}});m.value=d,c.id="fw-profile-count";let{source:g}=n,f=t("div",{className:"compare-box source"},[t("h3",{className:"compare-title"},[p.document("icon"),"\uC6D0\uB798 \uC124\uC815"]),t("p",{className:"muted",text:`${g.name} \xB7 ${Kr(g.takenAt)}\uC5D0 \uC77D\uC74C \xB7 \uC6D0\uBCF8\uC740 \uBC14\uB00C\uC9C0 \uC54A\uC544\uC694`}),ft("\uC124\uBA85",g.description),ft("\uC131\uACA9",g.personality),ft("\uC0C1\uD669",g.scenario),!g.description&&!g.personality&&!g.scenario?t("p",{className:"muted",text:"\uC6D0\uBCF8\uC5D0 \uC801\uD78C \uC124\uBA85\uC774 \uC5C6\uC5B4\uC694."}):null]),b=t("div",{className:"profile-panel"},[t("form",{className:"compare-box world",on:{submit:v=>{v.preventDefault(),m.value.trim()&&m.value!==n.worldSetting&&a.updateWorldSetting(i,m.value)}}},[t("label",{className:"compare-title",attrs:{for:"fw-profile-setting"}},[p.leaf("icon"),"\uACF5\uBC29 \uC138\uACC4 \uC124\uC815"]),m,c,t("button",{className:"button small",text:s?"\uC800\uC7A5 \uC911\u2026":"\uC218\uC815 \uC800\uC7A5",attrs:{type:"submit"},disabled:s})])]),y=t("div",{className:"profile-panel"},[f]),u=t("ol",{className:"change-list"}),x=Math.max(1,Math.ceil(n.changes.length/2)),S=Math.min(l?.historyPage??0,x-1);function $(v){S=Math.max(0,Math.min(x-1,v)),a.rememberProfile({historyPage:S}),u.replaceChildren(...n.changes.slice(S*2,S*2+2).map(Mi))}$(S);let V=t("div",{className:"profile-panel"},[t("h3",{className:"subhead",text:"\uBCC0\uACBD \uC774\uB825"}),n.changes.length?u:t("p",{className:"muted",text:"\uC544\uC9C1 \uBCC0\uACBD \uC774\uB825\uC774 \uC5C6\uC5B4\uC694."}),_("\uBCC0\uACBD \uC774\uB825 \uACE0\uB974\uAE30",S,Array.from({length:x},(v,N)=>`${N+1} \xB7 ${n.changes.slice(N*2,N*2+2).map(R=>Hr[R.kind]??R.kind).join(" \xB7 ")}`),$)]),H=[b,y,V],A=["\uACF5\uBC29 \uC124\uC815","\uC6D0\uB798 \uC124\uC815","\uBCC0\uACBD \uC774\uB825"].map((v,N)=>t("button",{className:"profile-tab",text:v,attrs:{type:"button","aria-pressed":N===0?"true":"false"},on:{click:()=>{a.rememberProfile({panel:N}),h(N)}}}));function h(v){H.forEach((N,R)=>N.hidden=R!==v),A.forEach((N,R)=>N.setAttribute("aria-pressed",R===v?"true":"false"))}return h(l?.panel??0),t("div",{className:"sheet-backdrop"},[t("section",{className:"sheet card",attrs:{role:"dialog","aria-modal":"true","aria-labelledby":"fw-profile"}},[t("div",{className:"sheet-head"},[t("h2",{className:"section-title",text:`${n.displayName} \uD504\uB85C\uD544`,attrs:{id:"fw-profile"}}),U(n),w("\uB2EB\uAE30",()=>a.closeSheet(),{variant:"secondary"})]),t("div",{className:"profile-identity"},[O(n,"large"),t("div",{className:"profile-identity-text"},[t("strong",{text:n.displayName}),t("span",{text:n.recruited?"\uACF5\uBC29 \uC8FC\uBBFC":"\uCD08\uB300 \uB300\uAE30"}),t("button",{className:"outline-button",text:"\uAD00\uACC4 \uBCF4\uAE30",attrs:{type:"button"},on:{click:()=>{if(m.value!==n.worldSetting){a.notify("\uC218\uC815\uD55C \uACF5\uBC29 \uC124\uC815\uC744 \uC800\uC7A5\uD55C \uB4A4 \uAD00\uACC4\uB97C \uBCFC \uC218 \uC788\uC5B4\uC694.");return}a.openRelations(i)}}})])]),t("div",{className:"profile-tabs",attrs:{"aria-label":"\uD504\uB85C\uD544 \uB0B4\uC6A9 \uC120\uD0DD"}},A),...H])])}var Pi=[{id:"all",label:"\uC804\uCCB4"},{id:"character",label:"\uCE90\uB9AD\uD130"},{id:"persona",label:"\uD398\uB974\uC18C\uB098"}],Ge=[{id:"all",label:"\uBAA8\uB450"},{id:"recruited",label:"\uC601\uC785\uD55C \uC8FC\uBBFC"},{id:"waiting",label:"\uCD08\uB300 \uB300\uAE30"}];function Ei(e,r){let a=Ge[(Ge.findIndex(n=>n.id===e.filter)+1)%Ge.length],i=Ge.find(n=>n.id===e.filter);return t("div",{className:"search-bar"},[Fe({id:"fw-resident-search",value:e.query,placeholder:"\uC774\uB984\uC73C\uB85C \uCC3E\uAE30",onSearch:n=>r.setResidentsQuery(n)}),t("button",{className:`icon-button filter${e.filter==="all"?"":" active"}`,attrs:{type:"button","aria-label":`\uBCF4\uAE30: ${i.label} (\uB204\uB974\uBA74 ${a.label})`},on:{click:()=>r.setResidentsFilter(a.id)}},[p.filter()]),e.filter==="all"?null:t("span",{className:"filter-chip",text:i.label})])}function Ti(e,r){return t("div",{className:"pill-tabs",attrs:{role:"tablist","aria-label":"\uC8FC\uBBFC \uC885\uB958"}},Pi.map(a=>t("button",{className:`pill-tab${e.tab===a.id?" current":""}`,text:a.label,attrs:{type:"button",role:"tab","aria-selected":e.tab===a.id?"true":"false"},on:{click:()=>r.setResidentsTab(a.id)}})))}function Wi(e,r){let a=re[e.field];return t("button",{className:"tag field",attrs:{type:"button","aria-label":`${e.displayName} \uC804\uBB38 \uBD84\uC57C ${a} \u2014 \uD2B9\uAE30 \uBCF4\uAE30`},on:{click:()=>r.openSheet({kind:"field",residentId:e.residentId})}},[fe[e.field]("icon tiny"),t("span",{text:a})])}function zi(e,r,a){return t("li",{className:`resident-card${a?" selected":""}`},[t("button",{className:"resident-card-main",attrs:{type:"button","aria-label":`${e.displayName} \uC790\uC138\uD788 \uBCF4\uAE30`,"aria-pressed":String(a)},on:{click:()=>r.selectResident(e.residentId)}},[t("span",{className:"card-stage"},[J(e)]),t("strong",{className:"resident-name",text:e.displayName}),t("span",{className:"tag-row"},[U(e),t("span",{className:"resident-field-label",text:re[e.field]})]),t("span",{className:`status-pill ${e.recruited?"done":"waiting"}`,text:e.recruited?"\uC601\uC785 \uC644\uB8CC":"\uCD08\uB300 \uB300\uAE30"})])])}function ht(e,r,a){return t("button",{className:"detail-action",attrs:{type:"button"},on:{click:a}},[e("icon"),t("span",{text:r})])}function Li(e,r,a){let i=a?.crew.maxBreakthrough??5,n=a?ie(a,0):0,o=a?ie(a,e.breakthrough):0,s=oe(a,e.talentId),l=Object.entries(r.state.production.facilities).find(([,m])=>m.residentId===e.residentId)?.[0],d=a?.facilities.find(m=>m.id===l),c=e.recruited?d?d.field===e.field?`${d.name}\uC5D0\uC11C \uCC98\uB9AC \uC18D\uB3C4 +${q(o)}`:`${d.name}\uC5D0 \uC788\uC9C0\uB9CC \uBD84\uC57C\uAC00 \uB2EC\uB77C \uD6A8\uACFC\uAC00 \uC5C6\uC5B4\uC694.`:"\uC544\uC9C1 \uBC30\uCE58\uD558\uC9C0 \uC54A\uC558\uC5B4\uC694. \uACF5\uBC29 \uC791\uC5C5 \u2192 \uBC30\uCE58 \uBCC0\uACBD.":"\uCD08\uB300\uD558\uBA74 \uC2DC\uC124\uC5D0 \uBC30\uCE58\uD560 \uC218 \uC788\uC5B4\uC694.";return t("div",{className:"passive-block"},[t("p",{className:"passive"},[p.leaf("icon tiny"),t("strong",{text:"\uD328\uC2DC\uBE0C"}),` ${re[e.field]} \uC2DC\uC124 \uCC98\uB9AC \uC18D\uB3C4`]),s?t("p",{className:"talent-line"},[p.sparkle("icon tiny"),t("strong",{text:`\uD2B9\uAE30 ${s.name}`}),` ${s.description}`]):null,t("p",{className:"muted",text:`\uAE30\uBCF8 \uD6A8\uACFC ${q(n)} \u2192 \uD604\uC7AC ${q(o)} \xB7 ${c}`}),t("p",{className:"breakthrough"},[t("span",{text:`\uB3CC\uD30C ${e.breakthrough}/${i}`}),t("span",{className:"leaf-pips",attrs:{"aria-hidden":"true"}},Array.from({length:i},(m,g)=>t("span",{className:`pip${g<e.breakthrough?" on":""}`})))])])}function ji(e,r,a,i){return C(null,[t("div",{className:"resident-detail"},[t("span",{className:"detail-stage"},[J(e)]),t("div",{className:"detail-info"},[t("strong",{className:"detail-name",text:e.displayName}),t("span",{className:"tag-row"},[U(e),Wi(e,i)]),Li(e,r,a)])]),t("div",{className:"detail-actions"},[ht(p.image,"\uC8FC\uBBFC \uADF8\uB9BC",()=>i.openResidentImage(e.residentId)),ht(p.document,"\uD504\uB85C\uD544",()=>i.openSheet({kind:"profile",residentId:e.residentId})),ht(p.heart,"\uAD00\uACC4",()=>i.openRelations(e.residentId))]),e.recruited?null:t("button",{className:"button",text:"\uCD08\uB300\uD558\uB7EC \uAC00\uAE30",attrs:{type:"button"},on:{click:()=>i.navigate("invite")}})],{className:"detail-card"})}function Oi(e,r,a){let i=r.residentsView,n=Object.values(e.state.residents),o=Ze(e.state,i),s=2,l=Math.max(1,Math.ceil(o.length/s)),d=Math.min(i.page??0,l-1),c=o.slice(d*s,(d+1)*s),m=c.find(f=>f.residentId===i.selectedId)??c[0]??null,g=n.length===0?t("div",{className:"empty-state"},[t("p",{text:"\uC544\uC9C1 \uC8FC\uBBFC\uC774 \uC5C6\uC5B4\uC694."}),t("p",{className:"muted",text:"\uCE90\uB9AD\uD130\uB098 \uD398\uB974\uC18C\uB098\uB97C \uBD88\uB7EC\uC640 \uC774 \uC138\uACC4\uC758 \uC8FC\uBBFC\uC73C\uB85C \uB9DE\uC774\uD574 \uBCF4\uC138\uC694."})]):o.length===0?t("p",{className:"empty",text:"\uC870\uAC74\uC5D0 \uB9DE\uB294 \uC8FC\uBBFC\uC774 \uC5C6\uC5B4\uC694."}):t("ul",{className:"resident-grid"},c.map(f=>zi(f,a,f.residentId===m?.residentId)));return[Ei(i,a),t("section",{className:"card resident-board",attrs:{"aria-label":"\uC8FC\uBBFC \uBAA9\uB85D"}},[Ti(i,a),g,_("\uC8FC\uBBFC \uBAA9\uB85D \uACE0\uB974\uAE30",d,Array.from({length:l},(f,b)=>`${b+1} \xB7 ${o.slice(b*s,(b+1)*s).map(y=>y.displayName).join(" \xB7 ")}`),f=>a.setResidentsPage(f))]),m?ji(m,e,r.content,a):null,t("button",{className:"button big-action",attrs:{type:"button","data-wide":""},on:{click:()=>a.openRegister(1)}},[p.people("icon"),t("span",{text:"\uC8FC\uBBFC \uBD88\uB7EC\uC624\uAE30"})])]}function Qr(e,r){let a=e.world?.state==="ready"?e.world.value:null,i=e.sheet?.kind==="profile"&&a?Ur(a,e,r,e.sheet.residentId):e.sheet?.kind==="field"&&a?qr(e,a,r,e.sheet.residentId):null;return P(e,r,{top:{kind:"sub",title:"\uC8FC\uBBFC",resources:!1},backdrop:"forest",body:a?Oi(a,e,r):[M("\uC138\uACC4\uB97C \uBD88\uB7EC\uC624\uB294 \uC911\u2026")],nav:!0,sheet:i})}function bt(e,r,a){return t("div",{className:"preview-row"},[e("icon"),t("span",{text:r}),t("strong",{text:a})])}function _e(e,r,a){let i=!!e.busy.restore,n=t("input",{className:"visually-hidden",attrs:{type:"file",accept:"application/json,.json",id:a},disabled:i,on:{change:()=>{let l=n.files?.[0];l&&r.selectRestoreFile(l),n.value=""}}}),o=e.restore,s=o?.summary;return t("div",{className:"restore"},[n,t("label",{className:"menu-row",attrs:{for:a}},[t("span",{className:"menu-icon"},[p.download()]),t("span",{className:"menu-text"},[t("span",{className:"menu-title",text:"\uBC31\uC5C5 \uBD88\uB7EC\uC624\uAE30"}),t("span",{className:"menu-detail",text:o?o.fileName:"\uC0C8 \uC138\uACC4\uB85C \uBCF5\uC6D0"})]),t("span",{className:"menu-chevron"},[p.chevron()])]),t("div",{className:"preview-box",attrs:{"aria-live":"polite"}},[t("p",{className:"preview-head"},[p.eye("icon"),t("strong",{text:"\uBCF5\uC6D0 \uBBF8\uB9AC\uBCF4\uAE30"})]),s?t("div",{className:"preview-rows"},[bt(p.residents,"\uC8FC\uBBFC",`${s.residents}\uBA85`),bt(p.pair,"\uD398\uC5B4",`${s.pairs}\uAC1C`),bt(p.image,"\uADF8\uB9BC",`${s.pictures}\uAC1C`)]):t("p",{className:"muted",text:"\uBC31\uC5C5 \uD30C\uC77C\uC744 \uACE0\uB974\uBA74 \uB2F4\uAE34 \uB0B4\uC6A9\uC744 \uBA3C\uC800 \uBCF4\uC5EC \uB4DC\uB824\uC694."})]),t("button",{className:"button big-action",attrs:{type:"button","data-wide":""},disabled:!s||i,on:{click:()=>{r.confirmRestore()}}},[p.restore("icon"),t("span",{text:i?"\uBCF5\uC6D0\uD558\uB294 \uC911\u2026":"\uC0C8 \uC138\uACC4\uB85C \uBCF5\uC6D0"})]),t("p",{className:"hint center"},[p.info("icon"),"\uD604\uC7AC \uC138\uACC4\uB294 \uB36E\uC5B4\uC4F0\uC9C0 \uC54A\uC544\uC694."])])}function Vi(e){let r=new Date(e);if(Number.isNaN(r.getTime()))return"\uC54C \uC218 \uC5C6\uC74C";let a=new Intl.DateTimeFormat("ko-KR",{hour:"2-digit",minute:"2-digit",hour12:!1}).format(r);return r.toDateString()===new Date().toDateString()?`\uC624\uB298 ${a}`:`${new Intl.DateTimeFormat("ko-KR",{month:"long",day:"numeric"}).format(r)} ${a}`}function Jr(e){return e>=1024*1024?`${(e/(1024*1024)).toFixed(1)} MB`:e>=1024?`${(e/1024).toFixed(1)} KB`:`${e} B`}function Bi(e){let r=e.storage,a;if(!r||r.state==="loading")a=M("\uD655\uC778\uD558\uB294 \uC911\u2026");else if(r.state==="error")a=Y(r.message);else{let i=[[p.image,"\uC8FC\uBBFC \uADF8\uB9BC","residentImagesBytes"],[p.landscape,"\uBC30\uACBD","backgroundsBytes"],[p.document,"\uAE30\uB85D","recordsBytes"]],n=Math.max(1,...i.map(([,,o])=>r.value[o]));a=t("div",{className:"usage-rows"},i.map(([o,s,l])=>{let d=r.value[l],c=t("span",{className:"usage-fill"});return c.style.width=d>0?`max(0.9em, ${Math.round(d/n*100)}%)`:"0",t("div",{className:"usage-row"},[o("icon"),t("span",{className:"usage-label",text:s}),t("span",{className:"usage-bar",attrs:{role:"presentation"}},[c]),t("span",{className:"usage-size",text:Jr(d)})])}))}return C("\uC800\uC7A5 \uACF5\uAC04 \uC0AC\uC6A9\uB7C9",[a,t("p",{className:"hint center"},[p.info("icon"),"\uADF8\uB9BC\uC740 WebP\uB85C \uBCF4\uAD00\uD574\uC694."])],{id:"fw-usage"})}function Di(e,r){let a=!!e.busy.backup;return t("button",{className:"menu-row",attrs:{type:"button"},disabled:a,on:{click:()=>{r.downloadBackup()}}},[t("span",{className:"menu-icon"},[p.upload()]),t("span",{className:"menu-text"},[t("span",{className:"menu-title",text:a?"\uBC31\uC5C5 \uB9CC\uB4DC\uB294 \uC911\u2026":"\uBC31\uC5C5 \uB0B4\uBCF4\uB0B4\uAE30"}),t("span",{className:"menu-detail",text:"\uC138\uACC4 \xB7 \uC7AC\uD654 \xB7 \uCC3D\uACE0 \uD3EC\uD568 \xB7 \uBE44\uBC00\uD0A4 \uC81C\uC678"})]),t("span",{className:"menu-chevron"},[p.chevron()])])}function Yr(e,r,a,i,n){return t("button",{className:"menu-row quiet",attrs:{type:"button"},on:{click:()=>e.navigate(r)}},[t("span",{className:"menu-icon quiet"},[a()]),t("span",{className:"menu-text"},[t("span",{className:"menu-title",text:i}),t("span",{className:"menu-detail",text:n})]),t("span",{className:"menu-chevron"},[p.chevron()])])}function Xr(e,r){let a=e.world?.state==="ready"?e.world.value:null,i=a?[t("section",{className:"card saved",attrs:{"aria-label":"\uC800\uC7A5 \uC0C1\uD0DC"}},[t("p",{className:"saved-title"},[t("span",{className:"check"},[p.check()]),"\uC800\uC7A5 \uC644\uB8CC"]),t("p",{className:"saved-time",text:`\uB9C8\uC9C0\uB9C9 \uC800\uC7A5 ${Vi(a.updatedAt)}`})]),Bi(e),C(null,[Di(e,r),_e(e,r,"fw-backup-restore")],{className:"menu"}),C(null,[t("button",{className:"menu-row",attrs:{type:"button"},on:{click:()=>r.openSheet({kind:"history-cleanup"})}},[t("span",{className:"menu-icon light"},[p.image()]),t("span",{className:"menu-text"},[t("span",{className:"menu-title",text:"\uADF8\uB9BC \uC774\uB825 \uC815\uB9AC"}),t("span",{className:"menu-detail",text:"\uB2E4\uB978 \uACF3\uC5D0\uC11C \uC4F0\uB294 \uADF8\uB9BC\uC740 \uC720\uC9C0"})]),t("span",{className:"menu-chevron"},[p.chevron()])]),Yr(r,"worlds",p.house,"\uB2E4\uB978 \uC138\uACC4","\uC138\uACC4 \uACE0\uB974\uAE30 \xB7 \uC0C8\uB85C \uB9CC\uB4E4\uAE30"),Yr(r,"diagnostics",p.info,"\uC5F0\uACB0 \uC810\uAC80","\uC5D4\uC9C4 \uC5F0\uACB0\uACFC \uADF8\uB9BC \uC800\uC7A5 \uACBD\uB85C \uD655\uC778")],{className:"menu"})]:[M("\uC138\uACC4\uB97C \uBD88\uB7EC\uC624\uB294 \uC911\u2026")];return P(e,r,{top:{kind:"sub",title:"\uC800\uC7A5\xB7\uBC31\uC5C5",back:{route:"settings",label:"\uC124\uC815"},resources:!1},backdrop:"wood",body:i,nav:!0,sheet:a&&e.sheet?.kind==="history-cleanup"?Fi(a.state,e,r):null})}function Fi(e,r,a){let i=Object.values(e.residents).reduce((s,l)=>s+l.image.history.length,0),n=Object.values(e.residents).flatMap(s=>s.image.history).reduce((s,l)=>s+l.bytes,0),o=!!r.busy["image-history-clear"];return t("div",{className:"sheet-backdrop"},[t("section",{className:"sheet card",attrs:{role:"dialog","aria-modal":"true","aria-labelledby":"fw-history-cleanup"}},[t("h2",{className:"section-title",text:"\uADF8\uB9BC \uC774\uB825 \uC815\uB9AC",attrs:{id:"fw-history-cleanup"}}),i?t("p",{text:`\uC8FC\uBBFC\uB4E4\uC758 \uC774\uC804 \uADF8\uB9BC ${i}\uC7A5(${Jr(n)})\uC744 \uC815\uB9AC\uD574\uC694. \uC9C0\uAE08 \uC4F0\uB294 \uADF8\uB9BC\uC740 \uADF8\uB300\uB85C\uC774\uACE0, \uC815\uB9AC\uD55C \uADF8\uB9BC\uC740 '\uC774\uC804 \uADF8\uB9BC'\uC5D0\uC11C \uB418\uB3CC\uB9B4 \uC218 \uC5C6\uC5B4\uC694.`}):t("p",{className:"empty",text:"\uC815\uB9AC\uD560 \uC774\uC804 \uADF8\uB9BC\uC774 \uC5C6\uC5B4\uC694."}),t("p",{className:"hint",text:"\uB2E4\uB978 \uACF3\uC5D0\uC11C \uC4F0\uB294 \uADF8\uB9BC \uD30C\uC77C\uC740 \uAC24\uB7EC\uB9AC\uC5D0 \uADF8\uB300\uB85C \uB0A8\uC544\uC694."}),i?w(o?"\uC815\uB9AC\uD558\uB294 \uC911\u2026":`${i}\uC7A5 \uC815\uB9AC\uD558\uAE30`,()=>{a.clearImageHistory()},{disabled:o,attrs:{"data-wide":""}}):null,w("\uB2EB\uAE30",()=>a.closeSheet(),{variant:"secondary",attrs:{"data-wide":""}})])])}function Gi(e,r,a){let i=!!r.busy["rename-nickname"],n=e.state.settings.playerNickname,o=t("input",{className:"input",attrs:{id:"fw-set-nick",maxlength:"24",autocomplete:"off",value:r.settingsNicknameDraft?.worldId===e.worldId?r.settingsNicknameDraft.value:n},on:{input:()=>a.rememberSettingsNickname(e.worldId,o.value)}});return t("form",{className:"setting-row",on:{submit:s=>{s.preventDefault();let l=o.value.trim();l&&l!==n&&a.saveSettingsNickname(e.worldId,o.value)}}},[p.leaf("icon row-leaf"),t("label",{className:"setting-label",text:"\uB2C9\uB124\uC784",attrs:{for:"fw-set-nick"}}),t("span",{className:"setting-field"},[o,t("button",{className:"button small",text:i?"\uC800\uC7A5 \uC911\u2026":"\uC218\uC815",attrs:{type:"submit"},disabled:i})])])}function _i(e,r,a){return t("div",{className:"setting-row"},[t("span",{className:"setting-label",text:"\uC9C0\uBA74 \uC124\uC815"}),t("button",{className:"button small",text:"\uD648\uC5D0\uC11C \uC601\uC5ED \uD3B8\uC9D1",attrs:{type:"button"},on:{click:()=>a.openGroundEditor()}})])}function qi(e){return t("div",{className:"setting-row"},[p.leaf("icon row-leaf"),t("span",{className:"setting-label",text:"\uD604\uC2E4 \uB0A0\uC528"}),t("span",{className:"setting-field"},[t("span",{className:"input readonly"},[p.weather("icon"),t("span",{text:"\uB3C4\uC2DC \uBBF8\uC124\uC815"})]),mr(e,"weather",{className:"button small",label:"\uD604\uC2E4 \uB0A0\uC528 \uBCC0\uACBD",children:[t("span",{text:"\uBCC0\uACBD"})]})])])}function Hi(e,r){let a=t("input",{className:"slider",attrs:{id:"fw-font-size",type:"range",min:String(ae.min),max:String(ae.max),step:String(ae.step),value:String(e.fontSize),"aria-valuetext":`${e.fontSize}px`},on:{change:()=>r.setFontSize(Number(a.value))}});return t("div",{className:"setting-block"},[t("div",{className:"setting-row slider-row"},[p.leaf("icon row-leaf"),t("label",{className:"setting-label",text:"\uAE00\uC790 \uD06C\uAE30",attrs:{for:"fw-font-size"}}),a,t("span",{className:"slider-value",text:`${e.fontSize}px`})]),t("p",{className:"font-preview",text:"\uC774\uB807\uAC8C \uD45C\uC2DC\uB3FC\uC694."})])}function Ki(e,r){let a=[{id:"auto",label:`\uC790\uB3D9 (${xe[Ke(new Date)]})`},{id:"spring",label:"\uBD04"},{id:"summer",label:"\uC5EC\uB984"},{id:"autumn",label:"\uAC00\uC744"},{id:"winter",label:"\uACA8\uC6B8"}];return t("div",{className:"setting-block"},[t("div",{className:"setting-row"},[p.leaf("icon row-leaf"),t("span",{className:"setting-label",text:"\uACC4\uC808",attrs:{id:"fw-season-label"}})]),t("div",{className:"chip-row season-chips",attrs:{role:"group","aria-labelledby":"fw-season-label"}},a.map(i=>t("button",{className:`pill-tab${e.seasonChoice===i.id?" current":""}`,text:i.label,attrs:{type:"button","aria-pressed":e.seasonChoice===i.id?"true":"false"},on:{click:()=>r.setSeasonChoice(i.id)}}))),t("p",{className:"hint",text:"\uC790\uB3D9\uC740 \uC624\uB298 \uB0A0\uC9DC(\uBD81\uBC18\uAD6C)\uB97C \uB530\uB77C\uC694. \uB3C4\uC2DC\uB97C \uC120\uD0DD\uD558\uB294 \uD604\uC2E4 \uB0A0\uC528\uB294 \uC900\uBE44 \uC911\uC774\uC5D0\uC694. \uACC4\uC808\uC740 \uADF8\uB9BC\uB9CC \uBC14\uAFB8\uACE0 \uC0DD\uC0B0 \xB7 \uD310\uB9E4 \xB7 \uC120\uBB3C\uC5D0\uB294 \uC601\uD5A5\uC774 \uC5C6\uC5B4\uC694."})])}function Ui(e,r){let a=e.autoReading??{enabled:!1,seconds:4},i=t("select",{className:"input",attrs:{"aria-label":"\uC774\uC57C\uAE30 \uC790\uB3D9 \uB118\uAE30\uAE30 \uAC04\uACA9"},on:{change:()=>r.setAutoReading({...a,seconds:Number(i.value)})}},Array.from({length:9},(n,o)=>t("option",{text:`${o+2}\uCD08`,attrs:{value:String(o+2)}})));return i.value=String(a.seconds),t("div",{className:"setting-block"},[t("button",{className:"toggle-row",attrs:{type:"button",role:"switch","aria-checked":String(a.enabled),"aria-label":"\uC774\uC57C\uAE30 \uC790\uB3D9 \uB118\uAE30\uAE30"},on:{click:()=>r.setAutoReading({...a,enabled:!a.enabled})}},[t("span",{className:"toggle-text"},[t("strong",{text:"\uC774\uC57C\uAE30 \uC790\uB3D9 \uB118\uAE30\uAE30"}),t("span",{text:a.enabled?"\uC0C8 \uC774\uC57C\uAE30\uB97C \uC790\uB3D9\uC73C\uB85C \uB118\uACA8\uC694":"\uC9C1\uC811 \uB20C\uB7EC \uB118\uACA8\uC694"})]),t("span",{className:`switch ${a.enabled?"on":"off"}`},[t("span",{className:"knob"})])]),i,t("p",{className:"muted",text:"\uC9C8\uBB38\xB7\uAE30\uB85D\xB7\uD654\uBA74\uC744 \uBC97\uC5B4\uB0A0 \uB54C \uBA48\uCDB0\uC694. \uB2E4\uC2DC \uC2DC\uC791\uD558\uB824\uBA74 \uC774\uC57C\uAE30\uC758 \uC790\uB3D9 \uBC84\uD2BC\uC744 \uB20C\uB7EC \uC8FC\uC138\uC694. \uBCF4\uAD00\uC740 \uC9C1\uC811 \uB20C\uB7EC\uC694."})])}function Qi(e,r){let a=Z(e.weatherEffects);return t("div",{className:"setting-block weather-settings"},[t("button",{className:"toggle-row",attrs:{type:"button",role:"switch","aria-label":"\uB0A0\uC528 \uD6A8\uACFC","aria-checked":String(a.enabled)},on:{click:()=>r.setWeatherEffects({...a,enabled:!a.enabled})}},[t("span",{className:"toggle-text"},[t("strong",{text:"\uB0A0\uC528 \uD6A8\uACFC"}),t("span",{text:a.enabled?"\uACF5\uBC29 \uBC30\uACBD\uC5D0 \uC740\uC740\uD558\uAC8C \uD45C\uC2DC\uD574\uC694":"\uBC30\uACBD \uD6A8\uACFC\uB97C \uC26C\uC5B4\uC694"})]),t("span",{className:`switch ${a.enabled?"on":"off"}`,attrs:{"aria-hidden":"true"}},[t("span",{className:"knob"})])]),t("div",{className:"weather-choices",attrs:{role:"group","aria-label":"\uB0A0\uC528 \uC5F0\uCD9C \uC120\uD0DD"}},He.map(i=>t("button",{className:`weather-choice${a.kind===i?" current":""}`,attrs:{type:"button","aria-pressed":String(a.kind===i)},on:{click:()=>r.setWeatherEffects({...a,kind:i})}},[E(Te[i==="clear"?"sun":i==="cloudy"?"cloud":i],{className:"weather-choice-art",fallback:()=>p.weather("icon")}),t("span",{text:ve[i]})]))),t("p",{className:"muted",text:"\uC9C1\uC811 \uACE0\uB974\uB294 \uBC30\uACBD \uC5F0\uCD9C\uC774\uC5D0\uC694. \uD604\uC2E4 \uB0A0\uC528\xB7\uC0DD\uC0B0\uC5D0\uB294 \uC601\uD5A5\uC744 \uC8FC\uC9C0 \uC54A\uC544\uC694. \uB3D9\uC791 \uC904\uC774\uAE30 \uC124\uC815\uC5D0\uC11C\uB294 \uC6C0\uC9C1\uC774\uC9C0 \uC54A\uC544\uC694."})])}function qe(e,r,a){return t("button",{className:"manage-row",attrs:{type:"button"},on:{click:a}},[E(le[e],{className:"manage-art",fallback:()=>p.document("icon")}),t("span",{className:"manage-title",text:r}),t("span",{className:"menu-chevron"},[p.chevron()])])}function Zr(e,r){let a=e.world?.state==="ready"?e.world.value:null,i=e.settingsSection??"workshop",o=a?[t("div",{className:"pill-tabs",attrs:{role:"group","aria-label":"\uC124\uC815 \uD56D\uBAA9"}},[["workshop","\uB0B4 \uACF5\uBC29"],["display","\uD45C\uC2DC"],["manage","\uAD00\uB9AC"]].map(([s,l])=>t("button",{className:`pill-tab${i===s?" current":""}`,text:l,attrs:{type:"button","aria-pressed":i===s?"true":"false"},on:{click:()=>r.setSettingsSection(s)}}))),i==="workshop"?C("\uB0B4 \uACF5\uBC29",[Gi(a,e,r),_i(a,e,r),qi(r)],{id:"fw-mine"}):null,i==="display"?C("\uD45C\uC2DC",[Hi(e,r),Ki(e,r),Qi(e,r),Ui(e,r)],{id:"fw-display"}):null,i==="manage"?C("\uAD00\uB9AC",[qe("portrait","\uC8FC\uBBFC \uADF8\uB9BC \uAD00\uB9AC",()=>r.navigate("residents")),qe("guidelines","AI \uC9C0\uCE68 \uAD00\uB9AC",()=>r.openGuidelines()),qe("memory","\uAE30\uC5B5 \uAD00\uB9AC",()=>r.openMemory()),qe("backup","\uC800\uC7A5 \xB7 \uBC31\uC5C5",()=>r.navigate("backup")),t("div",{className:"note-box"},[p.clock("icon"),t("span",{},[t("strong",{text:"\uBBF8\uC811\uC18D \uB204\uC801 \uC0C1\uD55C 72\uC2DC\uAC04"}),t("span",{text:"72\uC2DC\uAC04\uC774 \uC9C0\uB098\uBA74 \uC77C\uBD80 \uC790\uB3D9 \uC9C4\uD589\uC774 \uBA48\uCDB0\uC694."})])])],{id:"fw-manage"}):null,i==="manage"?t("p",{className:"footnote",text:"\uC790\uB3D9\uD654 \uADDC\uCE59\uC740 \uC791\uC5C5 \uD654\uBA74\uC5D0\uC11C \uBC14\uAFC0 \uC218 \uC788\uC5B4\uC694."}):null]:[M("\uC138\uACC4\uB97C \uBD88\uB7EC\uC624\uB294 \uC911\u2026")];return P(e,r,{top:{kind:"sub",title:"\uC124\uC815",back:{route:"home",label:"\uD648"},resources:!1},backdrop:"wood",body:o,nav:!0})}function Yi(e,r,a,i,n){let o=0;for(let s of Object.values(e.state.production.facilities))if(!(!s.unlocked||s.mode!=="auto"))for(let l of s.rules){let d=r.recipes.find(c=>c.id===l.recipeId);l.enabled&&d&&Object.keys(d.outputs)[0]===a&&(o=Math.max(o,l.targetStock))}return{floor:Math.max(i,n?0:o,e.state.production.protectedStock[a]??0),target:o}}function ea(e,r,a,i){let n=new Date().toISOString().slice(0,10),o=r.state.production.sales,l=a.items.filter(d=>(r.state.inventory[d.id]??0)>0||r.state.production.autoSell[d.id]?.enabled).map(d=>{let c=r.state.production.autoSell[d.id]??{enabled:!1,keep:0,dailyMax:10},m=se(`fw-keep-${d.id}`,c.keep,0,999,{label:`${d.name} \uB0A8\uAE38 \uC218\uB7C9`}),g=se(`fw-daily-${d.id}`,c.dailyMax,1,999,{label:`${d.name} \uD558\uB8E8 \uCD5C\uB300`}),f=t("input",{attrs:{type:"checkbox",id:`fw-continuous-${d.id}`}});f.checked=!!c.continuous;let{floor:b,target:y}=Yi(r,a,d.id,c.keep,!!(c.continuous&&c.enabled)),u=o.day===n?o.sold[d.id]??0:0,x=!!e.busy[`auto-sell:${d.id}`],S=$=>{i.setAutoSell(d.id,{enabled:$,keep:m.read(),dailyMax:g.read(),continuous:f.checked})};return t("li",{className:`auto-sell-row${c.enabled?" on":""}`},[t("div",{className:"auto-sell-head"},[j(d.id),t("span",{className:"protect-name"},[t("strong",{text:d.name}),t("small",{className:"muted",text:`\uBCF4\uC720 ${r.state.inventory[d.id]??0} \xB7 1\uAC1C ${d.sellPrice} G \xB7 \uC624\uB298 \uD310\uB9E4 ${u}`})]),t("span",{className:`switch ${c.enabled?"on":"off"}`},[t("span",{className:"knob"}),t("span",{className:"switch-label",text:c.enabled?"\uCF1C\uC9D0":"\uAEBC\uC9D0"})])]),t("div",{className:"auto-sell-fields"},[t("label",{className:"field-label",text:"\uD310\uB9E4 \uD6C4 \uB0A8\uAE38 \uC218\uB7C9",attrs:{for:`fw-keep-${d.id}`}}),m.node,t("label",{className:"field-label",text:"\uD558\uB8E8 \uCD5C\uB300 \uD310\uB9E4\uB7C9",attrs:{for:`fw-daily-${d.id}`}}),g.node]),t("label",{attrs:{for:`fw-continuous-${d.id}`}},[f," \uD310\uB9E4\uD560 \uB9CC\uD07C \uACC4\uC18D \uC0DD\uC0B0\uD558\uAE30"]),t("p",{className:"hint",text:c.enabled&&c.continuous?`\uD604\uC7AC \uD310\uB9E4 \uC2DC ${b}\uAC1C \uC774\uC0C1 \uB0A8\uACA8\uC694. \uD310\uB9E4 \uD55C\uB3C4\uC5D0 \uB3C4\uB2EC\uD558\uBA74 \uC77C\uBC18 \uC0DD\uC0B0 \uBAA9\uD45C ${y}\uAC1C\uB97C \uB530\uB985\uB2C8\uB2E4.`:`\uD604\uC7AC ${b}\uAC1C \uC774\uC0C1 \uB0A8\uACA8\uC694 (\uBCF4\uAD00\uB7C9 \xB7 \uC0DD\uC0B0 \uBAA9\uD45C ${y} \xB7 \uBCF4\uD638 \uC7AC\uACE0 \uC911 \uAC00\uC7A5 \uD070 \uAC12).`}),t("div",{className:"row-actions"},[w(x?"\uC800\uC7A5 \uC911\u2026":c.enabled?"\uC124\uC815 \uC800\uC7A5":"\uCF1C\uAE30",()=>S(!0),{disabled:x}),c.enabled?w("\uB044\uAE30",()=>S(!1),{variant:"secondary",disabled:x}):null])])});return L("fw-auto-sell","\uC790\uB3D9 \uD310\uB9E4",[t("p",{className:"muted",text:"\uCF20 \uD488\uBAA9\uC744 \uD558\uB8E8(UTC \uAE30\uC900) \uD310\uB9E4 \uD55C\uB3C4\uAE4C\uC9C0 \uD314\uC544\uC694. \uACC4\uC18D \uC0DD\uC0B0\uC744 \uC120\uD0DD\uD558\uBA74 \uB0A8\uAE38 \uC218\uB7C9\uACFC \uBCF4\uD638 \uC7AC\uACE0\uB97C \uC9C0\uD0A4\uBA70 \uD310\uB9E4\uD560 \uB9CC\uD07C \uB9CC\uB4E4\uC5B4\uC694."}),l.length?t("ul",{className:"protect-list"},l):t("p",{className:"empty",text:"\uCC3D\uACE0\uAC00 \uBE44\uC5B4 \uC788\uC5B4\uC694."}),w("\uB2EB\uAE30",()=>i.closeSheet(),{variant:"secondary",attrs:{"data-wide":""}})])}function ta(e,r){let a=new Map(r?.items.map((i,n)=>[i.id,n]));return Object.entries(e.state.inventory).filter(([,i])=>i>0).sort(([i],[n])=>(a.get(i)??999)-(a.get(n)??999)).map(([i,n])=>({itemId:i,amount:n,name:B(r,i)}))}function Ji(e,r){let a=(i,n,o)=>t("button",{className:`big-tab${(e.facilitiesTab==="protection"?"facilities":e.facilitiesTab)===i?" current":""}`,attrs:{type:"button",role:"tab","aria-selected":(e.facilitiesTab==="protection"?"facilities":e.facilitiesTab)===i?"true":"false"},on:{click:()=>r.setFacilitiesTab(i)}},[o,t("span",{text:n})]);return t("div",{className:"big-tabs",attrs:{role:"tablist","aria-label":"\uC2DC\uC124\uACFC \uCC3D\uACE0"}},[a("facilities","\uC2DC\uC124",p.house("icon big")),a("storage","\uCC3D\uACE0",p.box("icon big"))])}function Xi(e,r,a,i){let n=e.work.facilityId,o=a.state.production.facilities[n],s=te(r,n),l=r.production.maxLevel,d=o.level>=l,c=d?null:r.production.upgradeCosts[o.level-1],m=!!e.busy[`upgrade:${n}:${o.level}`],g=c!==null&&a.state.wallet.gold<c,f=!o.unlocked,b=ne(r,a.state,n);return C(null,[t("div",{className:"chip-row",attrs:{role:"group","aria-label":"\uC2DC\uC124 \uACE0\uB974\uAE30"}},r.facilities.map(y=>t("button",{className:`pill-tab${y.id===n?" current":""}`,attrs:{type:"button","aria-pressed":y.id===n?"true":"false","aria-label":a.state.production.facilities[y.id]?.unlocked?y.name:`${y.name} (\uD574\uAE08 \uC804)`},on:{click:()=>i.selectFacility(y.id)}},[t("span",{text:y.name}),a.state.production.facilities[y.id]?.unlocked?null:p.lock("icon tiny")]))),t("div",{className:"facility"},[t("span",{className:`facility-picture${f?" closed":""}`},[Ne(n,"huge")]),t("div",{className:"facility-info"},[t("strong",{className:"facility-name",text:s?.name??n}),t("span",{className:"facility-level"},[`Lv. ${o.level}`,d?null:t("span",{className:"level-next",text:` \u2192 Lv. ${o.level+1}`})]),t("div",{className:"effect-row"},[t("span",{text:"\uCC98\uB9AC \uC18D\uB3C4"}),t("span",{},[`+${ot(r,o.level)}%`,d?null:t("span",{className:"level-next",text:` \u2192 +${ot(r,o.level+1)}%`})])]),t("div",{className:"effect-row"},[t("span",{text:"\uC791\uC5C5 \uBC29\uC2DD"}),t("span",{text:f?"\uD574\uAE08 \uC804":o.mode==="auto"?"\uC790\uB3D9 \uC6B4\uC601":"\uC9C0\uC815 \uD69F\uC218"})]),t("div",{className:"effect-row"},[t("span",{text:"\uC8FC\uBBFC \uD6A8\uACFC"}),t("span",{text:`+${q(b.total)}${b.resident?` (${b.resident.displayName})`:""}`})]),t("p",{className:"muted",text:s?.description??""}),f?t("p",{className:"hint",text:"\uACF5\uBC29 \uC791\uC5C5\uC5D0\uC11C \uD574\uAE08 \uC870\uAC74\uC744 \uCC44\uC6B0\uACE0 \uC2DC\uC124\uC744 \uC5F4\uBA74 \uAC15\uD654\uD560 \uC218 \uC788\uC5B4\uC694."}):null,t("button",{className:"gold-button",attrs:{type:"button"},disabled:f||d||m||g,on:{click:()=>{i.upgradeFacility(n,o.level)}}},d?[t("span",{text:"\uCD5C\uACE0 \uB2E8\uACC4"})]:[t("span",{className:"coin"}),t("span",{text:m?"\uAC15\uD654\uD558\uB294 \uC911\u2026":`${c.toLocaleString("ko-KR")} G \xB7 \uAC15\uD654`})]),g?t("p",{className:"hint",text:`\uACE8\uB4DC\uAC00 ${(c-a.state.wallet.gold).toLocaleString("ko-KR")} G \uBD80\uC871\uD574\uC694.`}):null])])],{className:"facility-card"})}function Zi(e,r){let a=Object.values(e.state.production.autoSell).filter(i=>i.enabled).length;return t("button",{className:"toggle-row",attrs:{type:"button","aria-label":`\uC790\uB3D9 \uD310\uB9E4 ${a?`\uCF1C\uC9D0 (${a}\uAC1C \uD488\uBAA9)`:"\uAEBC\uC9D0"} \u2014 \uC124\uC815 \uC5F4\uAE30`},on:{click:()=>r.openSheet({kind:"auto-sell"})}},[t("span",{className:"toggle-icon"},[p.gear("icon")]),t("span",{className:"toggle-text"},[t("strong",{text:a?`\uC790\uB3D9 \uD310\uB9E4 \xB7 ${a}\uAC1C \uD488\uBAA9`:"\uC790\uB3D9 \uD310\uB9E4"}),t("span",{text:"\uBCF4\uD638 \xB7 \uC608\uC57D \uC7AC\uACE0\uB294 \uC0AC\uC6A9\uD558\uC9C0 \uC54A\uC544\uC694."})]),t("span",{className:`switch ${a?"on":"off"}`},[t("span",{className:"knob"}),t("span",{className:"switch-label",text:a?"\uCF1C\uC9D0":"\uAEBC\uC9D0"})])])}function ra(e,r,a){let i=Array.from({length:Math.ceil(r.length/3)},(n,o)=>{let s=r.slice(o*3,o*3+3);return`${o+1} \xB7 ${s.map(l=>l.name).join(" \xB7 ")}`});return _("\uC7AC\uACE0 \uBAA9\uB85D \uACE0\uB974\uAE30",e,i,n=>a.setInventoryPage(n))}function en(e,r,a,i){let n=ta(r,a),o=Math.min(e.work.inventoryPage??0,Math.max(0,Math.ceil(n.length/3)-1)),s=r.state.production.protectedStock;return C(null,[t("div",{className:"card-head"},[t("div",{},[t("h2",{className:"section-title",text:"\uC7AC\uACE0 \uBCF4\uD638",attrs:{id:"fw-protect"}}),t("p",{className:"muted",text:"\uC9C0\uC815\uD55C \uC218\uB7C9\uC740 \uC81C\uC791\uACFC \uD310\uB9E4\uC5D0 \uC0AC\uC6A9\uD558\uC9C0 \uC54A\uC544\uC694."})]),t("button",{className:"outline-button",attrs:{type:"button"},on:{click:()=>i.openSheet({kind:"protect-edit"})}},[p.pencil("icon"),t("span",{text:"\uD3B8\uC9D1\uD558\uAE30"})])]),n.length===0?t("p",{className:"empty",text:"\uCC3D\uACE0\uAC00 \uBE44\uC5B4 \uC788\uC5B4\uC694."}):t("table",{className:"stock"},[t("thead",{},[t("tr",{},["\uC544\uC774\uD15C","\uBCF4\uC720 \uC218\uB7C9","\uBCF4\uD638 \uC7AC\uACE0","\uC608\uC57D \uC7AC\uACE0","\uC0AC\uC6A9 \uAC00\uB2A5"].map(l=>t("th",{text:l,attrs:{scope:"col"}})))]),t("tbody",{},n.slice(o*3,o*3+3).map(l=>{let d=s[l.itemId]??0;return t("tr",{},[t("th",{attrs:{scope:"row"}},[j(l.itemId),l.name]),t("td",{className:"num",text:l.amount.toLocaleString("ko-KR")}),t("td",{className:`num${d?" protected":""}`,text:d?String(d):"\u2013"}),t("td",{className:"num",text:"\u2013"}),t("td",{className:"num available",text:Math.max(0,l.amount-d).toLocaleString("ko-KR")})])}))]),ra(o,n,i),Zi(r,i)],{id:"fw-protect"})}function tn(e,r,a,i){let n=ta(r,a),o=Math.min(e.work.inventoryPage??0,Math.max(0,Math.ceil(n.length/3)-1));return C("\uCC3D\uACE0",[n.length===0?t("p",{className:"empty",text:"\uCC3D\uACE0\uAC00 \uBE44\uC5B4 \uC788\uC5B4\uC694."}):t("ul",{className:"storage-grid"},n.slice(o*3,o*3+3).map(s=>t("li",{className:"storage-item"},[j(s.itemId),t("span",{className:"storage-name",text:s.name}),t("strong",{text:s.amount.toLocaleString("ko-KR")}),t("button",{className:"outline-button small",attrs:{type:"button","aria-label":`${s.name} \uD314\uAE30`},on:{click:()=>i.openSheet({kind:"sell",itemId:s.itemId})}},[t("span",{text:"\uD314\uAE30"})])]))),ra(o,n,i)],{id:"fw-storage"})}function rn(e,r,a,i){let n=a.production.protectedStock,o=e.sheet?.kind==="protect-edit"?e.sheet:null,s=a.items.map(m=>{let g=se(`fw-protect-${m.id}`,o?.drafts?.[m.id]??r.state.production.protectedStock[m.id]??0,n.min,n.max,{onChange:b=>i.rememberProtection({itemId:m.id,amount:b})}),f=!!e.busy[`protect:${m.id}`];return t("li",{className:"protect-row"},[j(m.id),t("span",{className:"protect-name"},[t("strong",{text:m.name}),t("small",{className:"muted",text:`\uBCF4\uC720 ${r.state.inventory[m.id]??0}`})]),g.node,w(f?"\uC800\uC7A5 \uC911\u2026":"\uC800\uC7A5",()=>{i.setProtected(m.id,g.read())},{disabled:f,attrs:{"aria-label":`${m.name} \uBCF4\uD638 \uC218\uB7C9 \uC800\uC7A5`}})])}),l=Math.max(0,Math.min(s.length-1,o?.page??0)),d=t("select",{className:"input",attrs:{"aria-label":"\uBCF4\uD638\uD560 \uC544\uC774\uD15C"},on:{change:()=>c(Number(d.value))}},a.items.map((m,g)=>t("option",{text:m.name,attrs:{value:String(g)}})));function c(m){l=Math.max(0,Math.min(s.length-1,m)),s.forEach((g,f)=>g.hidden=f!==l),d.value=String(l),i.rememberProtection({page:l})}return c(l),t("div",{className:"sheet-backdrop"},[t("section",{className:"sheet card",attrs:{role:"dialog","aria-modal":"true","aria-labelledby":"fw-protect-edit"}},[t("h2",{className:"section-title",text:"\uC7AC\uACE0 \uBCF4\uD638 \uD3B8\uC9D1",attrs:{id:"fw-protect-edit"}}),t("p",{className:"muted",text:"\uBCF4\uD638\uD55C \uC218\uB7C9\uC740 \uC790\uB3D9 \uC81C\uC791\uACFC \uD310\uB9E4\uC5D0 \uC4F0\uC9C0 \uC54A\uC544\uC694. 0\uC774\uBA74 \uBCF4\uD638\uD558\uC9C0 \uC54A\uC544\uC694."}),d,t("ul",{className:"protect-list"},s),w("\uB2EB\uAE30",()=>i.closeSheet(),{variant:"secondary",attrs:{"data-wide":""}})])])}function an(e,r,a,i,n){let o=a.items.find(m=>m.id===n),s=r.state.inventory[n]??0,l=Math.max(0,s-(r.state.production.protectedStock[n]??0)),d=se("fw-sell-amount",Math.min(l,1),l?1:0,l),c=!!e.busy[`sell:${n}`];return t("div",{className:"sheet-backdrop"},[t("section",{className:"sheet card",attrs:{role:"dialog","aria-modal":"true","aria-labelledby":"fw-sell"}},[t("h2",{className:"section-title",text:`${o?.name??n} \uD314\uAE30`,attrs:{id:"fw-sell"}}),t("p",{className:"muted",text:`1\uAC1C ${o?.sellPrice??0} G \xB7 \uD314 \uC218 \uC788\uB294 \uC591 ${l}\uAC1C (\uBCF4\uC720 ${s}\uAC1C, \uBCF4\uD638\uBD84 \uC81C\uC678)`}),l?d.node:t("p",{className:"empty",text:"\uBCF4\uD638\uBD84\uC744 \uBE7C\uBA74 \uD314 \uC218 \uC788\uB294 \uC591\uC774 \uC5C6\uC5B4\uC694."}),l?w(c?"\uD30C\uB294 \uC911\u2026":"\uD314\uAE30",()=>{i.sell(n,d.read())},{disabled:c,attrs:{"data-wide":""}}):null,w("\uB2EB\uAE30",()=>i.closeSheet(),{variant:"secondary",attrs:{"data-wide":""}})])])}function aa(e,r){let a=e.world?.state==="ready"?e.world.value:null,i=e.content,n=a&&i,o=n&&e.sheet?.kind==="protect-edit"?rn(e,a,i,r):n&&e.sheet?.kind==="sell"?an(e,a,i,r,e.sheet.itemId):n&&e.sheet?.kind==="auto-sell"?ea(e,a,i,r):null;return P(e,r,{top:{kind:"sub",title:"\uC2DC\uC124\uACFC \uCC3D\uACE0",back:{route:"work",label:"\uACF5\uBC29 \uC791\uC5C5"},resources:!0},backdrop:"forest",body:n?[Ji(e,r),...e.facilitiesTab!=="storage"?[a.state.production.facilities[e.work.facilityId]&&i.facilities?Xi(e,i,a,r):null,en(e,a,i,r)]:[tn(e,a,i,r)]]:[M("\uC138\uACC4\uB97C \uBD88\uB7EC\uC624\uB294 \uC911\u2026")],nav:!0,sheet:o})}function ia(e,r,a,i,n){let o=te(a,n),s=r.state.production.facilities[n]?.residentId??null,l=!!e.busy[`assign:${n}`],d=g=>Object.entries(r.state.production.facilities).find(([,f])=>f.residentId===g)?.[0]??null,c=Object.values(r.state.residents).filter(g=>g.recruited).sort((g,f)=>+(f.field===o?.field)-+(g.field===o?.field)||g.displayName.localeCompare(f.displayName,"ko")),m=ne(a,r.state,n);return L("fw-assign",`${o?.name??"\uC2DC\uC124"} \uBC30\uCE58 \uBCC0\uACBD`,[t("p",{className:"muted",text:`${o?re[o.field]:""} \uBD84\uC57C \uC8FC\uBBFC\uC744 \uB450\uBA74 \uCC98\uB9AC \uC18D\uB3C4\uAC00 \uBE68\uB77C\uC838\uC694. \uC9C0\uAE08 \uC791\uC5C5\uC740 \uC2DC\uC791\uD55C \uC18D\uB3C4 \uADF8\uB300\uB85C \uB05D\uB098\uACE0, \uB2E4\uC74C \uD68C\uCC28\uBD80\uD130 \uC801\uC6A9\uB3FC\uC694. \uD398\uC5B4 \uB450 \uC0AC\uB78C\uC774 \uBAA8\uB450 \uBC30\uCE58\uB418\uBA74 \uBAA8\uB4E0 \uC2DC\uC124 +${q(a.crew.setBonusPerPair)}(\uCD5C\uB300 ${q(a.crew.setBonusMax)}).`}),t("p",{className:"assign-now"},[t("strong",{text:"\uC9C0\uAE08 "}),m.resident?m.resident.displayName:"\uBC30\uCE58\uD55C \uC8FC\uBBFC \uC5C6\uC74C",` \xB7 \uC8FC\uBBFC \uD6A8\uACFC +${q(m.total)}`]),c.length===0?t("div",{className:"assign-empty"},[t("p",{className:"empty",text:"\uC544\uC9C1 \uACF5\uBC29\uC5D0 \uC628 \uC8FC\uBBFC\uC774 \uC5C6\uC5B4\uC694. \uC8FC\uBBFC\uC774 \uC5C6\uC5B4\uB3C4 \uC2DC\uC124\uC740 \uACC4\uC18D \uC77C\uD574\uC694."}),r.state.progress.starterResidentId===null?w(Object.keys(r.state.residents).length?"\uC2DC\uC791 \uC8FC\uBBFC \uACE0\uB974\uAE30":"\uCCAB \uC8FC\uBBFC \uB9DE\uC774\uD558\uAE30",()=>i.openRegister(Object.keys(r.state.residents).length?3:1)):w("\uC8FC\uBBFC \uCD08\uB300\uD558\uAE30",()=>i.navigate("invite"))]):t("ul",{className:"pick-list"},c.map(g=>{let f=g.field===o?.field,b=d(g.residentId),y=oe(a,g.talentId),u=[f?`+${q(ie(a,g.breakthrough))}${y?` \xB7 \uD2B9\uAE30 ${y.name}: ${y.description}`:""}`:`${re[g.field]} \uBD84\uC57C\uB77C \uD6A8\uACFC \uC5C6\uC74C`,b&&b!==n?`${te(a,b)?.name??""}\uC5D0\uC11C \uC62E\uACA8 \uC640\uC694`:""].filter(Boolean).join(" \xB7 ");return t("li",{},[t("button",{className:`pick-row${g.residentId===s?" selected":""}`,attrs:{type:"button","aria-pressed":g.residentId===s?"true":"false"},disabled:l||g.residentId===s,on:{click:()=>{i.assignResident(n,g.residentId)}}},[O(g),t("strong",{text:g.displayName}),U(g),t("small",{className:f?"good":"muted",text:u})])])})),s?w("\uBC30\uCE58 \uD574\uC81C",()=>{i.assignResident(n,null)},{variant:"secondary",disabled:l}):null,w("\uB2EB\uAE30",()=>i.closeSheet(),{variant:"secondary",attrs:{"data-wide":""}})])}function na(e,r,a,i,n){let o=a.state.production.facilities[i],s=r.recipes.filter(A=>A.facilityId===i),l=lr(r,o.level),d=o.queue.length>=l,c=e.work.queueRecipe[i]??s[0]?.id??"",m=X(r,c),g=t("p",{className:"hint"}),f=ne(r,a.state,i),b=A=>{let h=m?Object.entries(Le(m,f).inputs):[];g.textContent=h.length?`\uC608\uC0C1 \uC7AC\uB8CC ${h.map(([v,N])=>`${B(r,v)} ${N*A}`).join(" \xB7 ")} \u2014 \uD55C \uD68C\uCC28\uC529 \uC2DC\uC791\uD560 \uB54C \uAEBC\uB0B4\uC694. \uC7AC\uB8CC \uD655\uBCF4\uB97C \uBBF8\uB9AC \uBCF4\uC7A5\uD558\uC9C0 \uC54A\uC544\uC694.`:"\uC7AC\uB8CC \uC5C6\uC774 \uC232\uC5D0\uC11C \uBC14\uB85C \uBAA8\uC544\uC694."},y=r.production.queueCount,u=e.work.queueCounts?.[i]??1,x=se(`fw-queue-count-${i}`,u,y.min,y.max,{label:"\uD69F\uC218",onChange:A=>{b(A),n.rememberQueueCount(i,A)}});b(u);let S=!!e.busy[`queue:${i}`],$=e.work.queueView??(o.queue.length?"list":"add"),V=t("select",{className:"input",attrs:{"aria-label":"\uB300\uAE30 \uC911\uC778 \uC791\uC5C5"}},o.queue.map((A,h)=>t("option",{text:`${h+1}. ${X(r,A.recipeId)?.name??A.recipeId} \xB7 ${A.started}/${A.total}\uD68C`,attrs:{value:A.entryId}}))),H=t("select",{className:"input",attrs:{"aria-label":"\uC81C\uC791\uBC95 \uACE0\uB974\uAE30"},on:{change:()=>n.selectQueueRecipe(i,H.value)}},s.map(A=>t("option",{text:A.name,attrs:{value:A.id}})));return H.value=c,t("div",{className:"plan-block queue"},[t("span",{className:"plan-label"},["\uC9C0\uC815 \uD69F\uC218 \uB300\uAE30\uC5F4 ",t("small",{text:`(${o.queue.length}/${l}\uCE78 \xB7 \uC704\uC5D0\uC11C\uBD80\uD130 \uCC28\uB840\uB85C \uB9CC\uB4E4\uC5B4\uC694)`})]),t("div",{className:"pill-tabs two",attrs:{role:"group","aria-label":"\uB300\uAE30\uC5F4 \uD654\uBA74"}},[t("button",{className:`pill-tab${$==="list"?" current":""}`,text:"\uB300\uAE30\uC5F4 \uBCF4\uAE30",attrs:{type:"button","aria-pressed":$==="list"?"true":"false"},on:{click:()=>n.setQueueView("list")}}),t("button",{className:`pill-tab${$==="add"?" current":""}`,text:"\uC791\uC5C5 \uCD94\uAC00",attrs:{type:"button","aria-pressed":$==="add"?"true":"false"},on:{click:()=>n.setQueueView("add")}})]),$==="list"?o.queue.length===0?t("p",{className:"empty",text:"\uB300\uAE30\uC5F4\uC774 \uBE44\uC5B4 \uC788\uC5B4\uC694."}):t("div",{className:"queue-add"},[V,t("button",{className:"outline-button",text:"\uC120\uD0DD\uD55C \uC791\uC5C5 \uBE7C\uAE30",attrs:{type:"button"},disabled:Object.keys(e.busy).some(A=>A.startsWith("queue-remove:")&&e.busy[A]),on:{click:()=>{n.removeQueue(i,V.value)}}})]):null,$==="add"?t("div",{className:"queue-add"},[H,x.node,g,t("button",{className:"button",attrs:{type:"button","data-wide":""},disabled:S||d||!m,on:{click:()=>{n.addQueue(i,c,x.read())}}},[p.plus("icon"),t("span",{text:d?"\uB300\uAE30\uC5F4\uC774 \uAC00\uB4DD \uCC3C\uC5B4\uC694":S?"\uCD94\uAC00\uD558\uB294 \uC911\u2026":"\uB300\uAE30\uC5F4\uC5D0 \uCD94\uAC00"})])]):null])}var nn=[{field:"gather",label:"\uCC44\uC9D1",icon:p.leaf},{field:"grow",label:"\uC7AC\uBC30",icon:p.sprout},{field:"survey",label:"\uC870\uC0AC",icon:p.search},{field:"process",label:"\uAC00\uACF5",icon:p.jar},{field:"craft",label:"\uC81C\uC791",icon:p.hammer}];function oa(e,r,a,i){return t("div",{className:"field-tabs work-fields",attrs:{role:"tablist","aria-label":"\uC791\uC5C5 \uBD84\uC57C"}},nn.map(n=>{let o=e.facilities.find(d=>d.field===n.field);if(!o)return null;let s=o.id===a,l=r.state.production.facilities[o.id]?.unlocked??!1;return t("button",{className:`field-tab${s?" current":""}${l?"":" closed"}`,attrs:{type:"button",role:"tab","aria-selected":s?"true":"false","aria-label":l?n.label:`${n.label} (\uD574\uAE08 \uC804)`},on:{click:()=>i.selectFacility(o.id)}},[E({gather:"items/herb.webp",grow:"items/wheat.webp",survey:"ui/nav-explore.webp",process:"items/berry-jam.webp",craft:"ui/nav-work.webp"}[n.field]??null,{className:"field-art",fallback:()=>n.icon("icon field-glyph")}),t("span",{text:n.label}),l?null:t("span",{className:"lock-tag"},[p.lock("icon tiny")])])}))}function on(e,r,a,i){let n=!!e.busy[`mode:${r}`],o=(s,l)=>t("button",{className:`segment${a.mode===s?" selected":""}`,text:l,attrs:{type:"button","aria-pressed":a.mode===s?"true":"false"},disabled:n,on:{click:()=>a.mode===s?void 0:void i.setMode(r,s)}});return t("div",{className:"segmented",attrs:{role:"group","aria-label":"\uC791\uC5C5 \uBC29\uC2DD"}},[o("auto","\uC790\uB3D9 \uC6B4\uC601"),o("count","\uC9C0\uC815 \uD69F\uC218")])}function sn(e,r,a,i,n){let o=te(r,i),s=sr(r,a.state,i),l=s.every(c=>c.met),d=!!e.busy[`unlock:${i}`];return C(null,[t("div",{className:"facility-entry"},[t("span",{className:"facility-open closed"},[t("span",{className:"facility-art closed"},[Ne(i),t("span",{className:"facility-lock"},[p.lock("icon")])]),t("span",{className:"facility-text"},[t("strong",{text:`${o?.name??i} \xB7 \uD574\uAE08 \uC804`}),t("span",{text:o?.description??""})])])]),t("div",{className:"plan-block"},[t("span",{className:"plan-label",text:"\uD574\uAE08 \uC870\uAC74"}),t("ul",{className:"unlock-list"},s.map(c=>t("li",{className:c.met?"met":""},[(c.met?p.check:p.hourglass)("icon"),t("span",{text:c.text}),t("strong",{text:`${Math.min(c.have,c.need)} / ${c.need}`})])))]),t("button",{className:"button",attrs:{type:"button","data-wide":""},disabled:!l||d,on:{click:()=>{n.unlockFacility(i)}}},[t("span",{text:d?"\uC5EC\uB294 \uC911\u2026":l?"\uC2DC\uC124 \uC5F4\uAE30":"\uC870\uAC74\uC744 \uCC44\uC6B0\uBA74 \uC5F4 \uC218 \uC788\uC5B4\uC694"})])],{className:"work-card"})}function ln(e,r,a,i,n,o){let s=te(r,i),l=ne(r,a.state,i),d=n.level<r.production.maxLevel?r.production.upgradeCosts[n.level-1]:void 0;return t("div",{className:"facility-entry"},[t("button",{className:"facility-open",attrs:{type:"button","aria-label":`${s?.name??"\uC2DC\uC124"} \u2014 \uC2DC\uC124\uACFC \uCC3D\uACE0 \uC5F4\uAE30`},on:{click:()=>{o.setFacilitiesTab("facilities"),o.navigate("facilities")}}},[t("span",{className:"facility-art"},[Ne(i)]),t("span",{className:"facility-text"},[t("strong",{text:`${s?.name??i} Lv. ${n.level}`}),t("span",{className:"crew-line"},[l.resident?O(l.resident):null,l.resident?`${l.resident.displayName} \xB7 ${l.matches?`+${q(l.passive)}${l.talent?` \xB7 \uD2B9\uAE30 ${l.talent.name}`:""}`:"\uBD84\uC57C\uAC00 \uB2EC\uB77C \uD6A8\uACFC \uC5C6\uC74C"}`:"\uBC30\uCE58\uD55C \uC8FC\uBBFC \uC5C6\uC74C",l.set?` \xB7 \uC138\uD2B8 +${q(l.set)}`:""])])]),d!==void 0?t("button",{className:"outline-button",text:`${d.toLocaleString("ko-KR")} G \xB7 \uAC15\uD654`,attrs:{type:"button","aria-label":`${s?.name??"\uC2DC\uC124"} \uAC15\uD654 ${d} \uACE8\uB4DC`},disabled:a.state.wallet.gold<d||!!e.busy[`upgrade:${i}:${n.level}`],on:{click:()=>{o.upgradeFacility(i,n.level)}}}):null,t("button",{className:"outline-button",attrs:{type:"button","aria-label":`${s?.name??"\uC2DC\uC124"} \uBC30\uCE58 \uBCC0\uACBD`},on:{click:()=>o.openSheet({kind:"assign",facilityId:i})}},[p.swap("icon"),t("span",{text:"\uBC30\uCE58 \uBCC0\uACBD"})])])}function dn(e,r,a,i){let n=r?X(e,r.recipeId):null;if(!n)return t("div",{className:"recipe"},[t("span",{className:"recipe-art"},[p.jar("icon big")]),t("span",{className:"recipe-text"},[t("strong",{text:"\uC81C\uC791\uBC95"}),t("span",{text:"\uC544\uB798 \uC6B0\uC120\uC21C\uC704\uC5D0\uC11C \uC81C\uC791\uBC95\uC744 \uCD94\uAC00\uD574 \uC8FC\uC138\uC694."})])]);let o=Object.keys(n.outputs)[0],s=Le(n,i),l=or(e,n,a,s.extraBonus),d=Object.entries(s.inputs).map(([c,m])=>`${B(e,c)} ${m}`);return t("div",{className:"recipe"},[t("span",{className:"recipe-art"},[j(o,"big")]),t("span",{className:"recipe-text"},[t("strong",{text:n.name}),t("span",{text:n.description}),t("span",{className:"recipe-flow",text:`${d.length?`${d.join(" \xB7 ")} \u2192 `:""}${Object.entries(n.outputs).map(([c,m])=>`${B(e,c)} ${m}`).join(" \xB7 ")} \xB7 1\uD68C ${de(l)}`}),s.talentApplies&&i.talent?t("span",{className:"talent-note"},[p.sparkle("icon tiny"),` \uD2B9\uAE30 ${i.talent.name}: ${i.talent.description}`]):null])])}function cn(e,r,a,i,n){let o=X(e,i.recipeId),s=o?Object.keys(o.outputs)[0]:"",l=r.state.production,d=r.state.inventory[s]??0,c=Object.values(l.facilities).reduce((f,b)=>f+(b.job?.outputs[s]??0),0),m=t("span",{className:"bar-fill red"});m.style.width=`${Math.min(100,Math.round((d+c)/Math.max(1,i.targetStock)*100))}%`;let g=(f,b,y,u=!1)=>t("button",{className:`step${u?" plus":""}`,attrs:{type:"button","aria-label":y},on:{click:()=>n.changeTarget(a,i.policyId,f)}},[b("icon")]);return t("div",{className:"plan-row"},[t("span",{className:"plan-label",text:"\uBAA9\uD45C \uC7AC\uACE0"}),t("span",{className:"stepper"},[g(-1,p.minus,"\uBAA9\uD45C 1 \uC904\uC774\uAE30"),t("span",{className:"step-value",text:String(i.targetStock),attrs:{"aria-live":"polite"}}),g(1,p.plus,"\uBAA9\uD45C 1 \uB298\uB9AC\uAE30",!0)]),t("span",{className:"plan-progress"},[t("span",{className:"muted"},[`\uD604\uC7AC ${B(e,s)} `,t("strong",{text:String(d)}),c?` (+${c} \uC9C4\uD589 \uC911)`:""," / \uBAA9\uD45C ",t("strong",{text:String(i.targetStock)})]),t("span",{className:"bar"},[m])])])}function mn(e,r,a){let i=a?X(e,a.recipeId):null,n=i?Object.entries(i.inputs):[],o=r.state.production;return t("div",{className:"plan-block"},[t("span",{className:"plan-label",text:"\uC7AC\uB8CC \uC0AC\uC6A9 \uC124\uC815"}),n.length===0?t("p",{className:"muted",text:"\uC774 \uC81C\uC791\uBC95\uC740 \uC7AC\uB8CC \uC5C6\uC774 \uC232\uC5D0\uC11C \uBC14\uB85C \uBAA8\uC544\uC694."}):t("div",{className:"usage-list"},n.map(([s])=>{let l=r.state.inventory[s]??0,d=o.protectedStock[s]??0;return t("div",{className:"usage"},[t("span",{className:"usage-item"},[j(s),t("span",{text:B(e,s)})]),t("span",{className:"usage-cell"},[t("small",{text:"\uBCF4\uC720"}),t("strong",{text:String(l)})]),t("span",{className:"usage-cell"},[t("small",{text:"\uBCF4\uD638"}),t("strong",{text:String(d)})]),t("span",{className:"usage-cell available"},[t("small",{text:"\uC0AC\uC6A9 \uAC00\uB2A5"}),t("strong",{text:String(Math.max(0,l-d))})])])}))])}function pn(e,r,a,i,n){let o=new Set(a.map(m=>m.recipeId)),s=e.recipes.filter(m=>m.facilityId===r&&!o.has(m.id)),l=a.find(m=>m.policyId===i)??a[0],d=t("select",{className:"input",attrs:{"aria-label":"\uC21C\uC11C\uC640 \uCF1C\uC9D0\uC744 \uBC14\uAFC0 \uC0DD\uC0B0 \uBB3C\uD488"},on:{change:()=>n.selectRule(r,d.value)}},a.map((m,g)=>t("option",{text:`${g+1}. ${X(e,m.recipeId)?.name??m.recipeId}${m.enabled?"":" (\uAEBC\uC9D0)"}`,attrs:{value:m.policyId}})));d.value=l?.policyId??"";let c=t("select",{className:"input",attrs:{"aria-label":"\uCD94\uAC00\uD560 \uC81C\uC791\uBC95"}},s.map(m=>t("option",{text:m.name,attrs:{value:m.id}})));return t("div",{className:"plan-block"},[t("span",{className:"plan-label"},["\uC81C\uC791 \uC6B0\uC120\uC21C\uC704 ",t("small",{text:"(\uC704\uC758 \uC544\uC774\uD15C\uBD80\uD130 \uC21C\uC11C\uB300\uB85C \uC81C\uC791\uD574\uC694)"})]),a.length?d:null,...a.filter(m=>m===l).map(m=>{let g=a.indexOf(m),f=X(e,m.recipeId),b=f?Object.keys(f.outputs)[0]:"";return t("div",{className:`priority-row${m.policyId===i?" selected":""}${m.enabled?"":" off"}`},[t("span",{className:"rank",text:String(g+1)}),t("button",{className:"priority-main",attrs:{type:"button","aria-pressed":m.policyId===i?"true":"false"},on:{click:()=>{n.selectRule(r,m.policyId),n.setWorkSection("recipe")}}},[j(b),t("span",{className:"priority-name",text:f?.name??m.recipeId}),t("small",{className:"muted",text:`\uBAA9\uD45C ${m.targetStock}`})]),t("button",{className:`chip-toggle${m.enabled?" on":""}`,text:m.enabled?"\uCF1C\uC9D0":"\uAEBC\uC9D0",attrs:{type:"button","aria-pressed":m.enabled?"true":"false","aria-label":`${f?.name??""} ${m.enabled?"\uB044\uAE30":"\uCF1C\uAE30"}`},on:{click:()=>n.toggleRule(r,m.policyId)}}),t("span",{className:"order-buttons"},[t("button",{className:"mini",attrs:{type:"button","aria-label":"\uC704\uB85C"},disabled:g===0,on:{click:()=>n.moveRule(r,m.policyId,-1)}},[p.up("icon")]),t("button",{className:"mini",attrs:{type:"button","aria-label":"\uC544\uB798\uB85C"},disabled:g===a.length-1,on:{click:()=>n.moveRule(r,m.policyId,1)}},[p.down("icon")])])])}),s.length?t("div",{className:"add-rules"},[c,t("button",{className:"outline-button",text:"\uC81C\uC791\uBC95 \uCD94\uAC00",attrs:{type:"button"},on:{click:()=>n.addRule(r,c.value)}})]):null])}function un(e,r,a,i){if(!i.job)return t("div",{className:"plan-row"},[t("span",{className:"plan-label",text:"\uD604\uC7AC \uC791\uC5C5"}),t("span",{className:"plan-progress wide"},[t("span",{className:"muted",text:"\uC26C\uB294 \uC911"}),t("span",{className:"bar"})])]);let n=X(r,i.job.recipeId),o=Object.keys(i.job.outputs)[0],s=he(e,a,i.job);return t("div",{className:"plan-row current-work"},[t("span",{className:"plan-label",text:"\uD604\uC7AC \uC791\uC5C5"}),j(o),t("span",{className:"plan-progress"},[t("span",{className:"muted",text:`${n?.name??""} \uB9CC\uB4DC\uB294 \uC911\u2026`}),s.bar]),s.countdown])}function gn(e,r,a,i){let n=r.state.production.facilities[a]?.waiting;if(!n)return null;let o=[];if(n.reason==="no_rules")o.push(t("button",{className:"outline-button",text:"\uC0DD\uC0B0 \uC21C\uC11C \uC124\uC815\uD558\uAE30",attrs:{type:"button"},on:{click:()=>i.setWorkSection("priority")}}));else if(n.reason==="queue_empty")o.push(t("button",{className:"outline-button",text:"\uC791\uC5C5 \uCD94\uAC00\uD558\uAE30",attrs:{type:"button"},on:{click:()=>{i.setQueueView("add"),i.setWorkSection("recipe")}}}));else if(n.reason==="materials"&&n.itemId){let s=n.itemId,l=[...new Set(e.recipes.filter(d=>(d.outputs[s]??0)>0).map(d=>d.facilityId))].filter(d=>d!==a&&r.state.production.facilities[d]);for(let d of l){let c=e.facilities.find(g=>g.id===d);if(!c)continue;let m=r.state.production.facilities[d]?.unlocked;o.push(t("button",{className:"outline-button",text:`${B(e,s)} \uC5BB\uB294 \uACF3 \xB7 ${c.name}${m?"":" (\uC5F4\uAE30 \uD544\uC694)"}`,attrs:{type:"button"},on:{click:()=>i.selectFacility(d)}}))}}return t("div",{className:"waiting-guide"},[t("p",{className:"hint",text:dr(e,n)}),...o])}function fn(e,r,a,i){let n=e.work.facilityId,o=a.state.production.facilities[n];if(!o)return[M("\uC2DC\uC124\uC744 \uBD88\uB7EC\uC624\uB294 \uC911\u2026")];if(!o.unlocked)return[oa(r,a,n,i),sn(e,r,a,n,i)];let s=Xe(e,a.state.production,n),l=s.find(b=>b.policyId===e.work.selected[n])??s[0],d=Ht(e,a.state.production,n),c=!!e.busy[`rules:${n}`],m=o.mode==="auto",g=ne(r,a.state,n),f=_("\uC0DD\uC0B0 \uBB3C\uD488 \uACE0\uB974\uAE30",Math.max(0,s.findIndex(b=>b.policyId===l?.policyId)),s.map(b=>`${X(r,b.recipeId)?.name??b.recipeId}${b.enabled?"":" (\uAEBC\uC9D0)"}`),b=>{let y=s[b];y&&i.selectRule(n,y.policyId)});return[oa(r,a,n,i),C(null,[on(e,n,o,i),ln(e,r,a,n,o,i),un(e,r,a,o),gn(r,a,n,i),...m?[t("h2",{className:"section-title",text:"\uC0DD\uC0B0 \uC124\uC815"}),f,dn(r,l,o.level,g),l?cn(r,a,n,l,i):null,mn(r,a,l),t("h2",{className:"section-title",text:"\uC81C\uC791 \uC6B0\uC120\uC21C\uC704"}),pn(r,n,s,l?.policyId,i)]:[na(e,r,a,n,i)],m&&o.queue.length?t("p",{className:"hint",text:`\uC9C0\uC815 \uD69F\uC218 \uB300\uAE30\uC5F4 ${o.queue.length}\uAC1C\uB294 \uBA48\uCD98 \uCC44 \uADF8\uB300\uB85C \uB0A8\uC544 \uC788\uC5B4\uC694.`}):null,m&&d?t("div",{className:"draft-note"},[t("span",{text:"\uBCC0\uACBD\uD55C \uC124\uC815\uC740 \uC801\uC6A9 \uD6C4 \uC0AC\uC6A9\uB3FC\uC694."}),t("button",{className:"link-button",text:"\uB418\uB3CC\uB9AC\uAE30",attrs:{type:"button"},on:{click:()=>i.discardDraft(n)}})]):null,m?t("div",{className:"rule-actions"},[t("button",{className:"button wide-main",attrs:{type:"button"},disabled:!d||c,on:{click:()=>{i.applyRules(n)}}},[p.check("icon"),t("span",{text:c?"\uC801\uC6A9\uD558\uB294 \uC911\u2026":d?"\uC6B4\uC601 \uADDC\uCE59 \uC801\uC6A9":"\uC801\uC6A9\uB428"})]),t("button",{className:"button secondary",attrs:{type:"button"},on:{click:()=>i.recommendRules(n)}},[p.gear("icon"),t("span",{text:"\uCD94\uCC9C \uC124\uC815"})])]):null],{className:"work-card"}),t("div",{className:"work-stock-actions",attrs:{role:"group","aria-label":"\uC7AC\uACE0 \uAD00\uB9AC"}},[t("button",{className:"button secondary",attrs:{type:"button"},on:{click:()=>{i.setFacilitiesTab("protection"),i.navigate("facilities")}}},[p.lock("icon"),"\uC7AC\uACE0 \uBCF4\uD638"]),t("button",{className:"button secondary",attrs:{type:"button"},on:{click:()=>{i.setFacilitiesTab("storage"),i.navigate("facilities")}}},[p.box("icon"),"\uCC3D\uACE0 \xB7 \uD310\uB9E4"])])]}function sa(e,r){let a=e.world?.state==="ready"?e.world.value:null,i=a&&e.content&&e.sheet?.kind==="assign"?ia(e,a,e.content,r,e.sheet.facilityId):null;return P(e,r,{top:{kind:"sub",title:"\uACF5\uBC29 \uC791\uC5C5",back:{route:"home",label:"\uD648"},resources:!0},backdrop:"forest",body:a&&e.content?fn(e,e.content,a,r):[M("\uC138\uACC4\uB97C \uBD88\uB7EC\uC624\uB294 \uC911\u2026")],nav:!0,sheet:i})}var la={world:40,nickname:24};function hn(e){let r=new Date(e);return Number.isNaN(r.getTime())?e:new Intl.DateTimeFormat("ko-KR",{dateStyle:"medium",timeStyle:"short"}).format(r)}function bn(e,r){let a=C("\uB0B4 \uC138\uACC4",[],{id:"fw-worlds"}),{worlds:i}=e;if(i.state==="loading")a.append(M("\uBD88\uB7EC\uC624\uB294 \uC911\u2026"));else if(i.state==="error")a.append(Y(i.message),w("\uB2E4\uC2DC \uC2DC\uB3C4",()=>{r.loadWorlds()},{variant:"secondary"}));else if(i.value.length===0)a.append(t("p",{className:"empty",text:"\uC544\uC9C1 \uC138\uACC4\uAC00 \uC5C6\uC2B5\uB2C8\uB2E4. \uC544\uB798\uC5D0\uC11C \uC0C8\uB85C \uB9CC\uB4E4\uC5B4 \uC8FC\uC138\uC694."}));else{let n=Math.ceil(i.value.length/2),o=Math.min(e.worldsPage??0,n-1);a.append(t("ul",{className:"menu-list"},i.value.slice(o*2,o*2+2).map(s=>t("li",{},[t("button",{className:"menu-row",attrs:{type:"button"},disabled:!s.readable,on:{click:()=>{r.openWorld(s.worldId)}}},[t("span",{className:"menu-icon"},[p.house()]),t("span",{className:"menu-text"},[t("span",{className:"menu-title",text:s.worldName}),t("span",{className:"menu-detail",text:s.readable?`\uB9C8\uC9C0\uB9C9 \uC800\uC7A5 ${hn(s.updatedAt)}`:"\uC774 \uBC84\uC804\uC5D0\uC11C \uC77D\uC744 \uC218 \uC5C6\uB294 \uC138\uACC4"})]),t("span",{className:"menu-chevron"},[p.chevron()])])])))),n>1&&a.append(t("div",{className:"resident-pages"},[w("\uC774\uC804",()=>r.setWorldsPage(o-1),{variant:"secondary",disabled:o===0}),t("span",{text:`${o+1} / ${n}`,attrs:{"aria-live":"polite"}}),w("\uB2E4\uC74C",()=>r.setWorldsPage(o+1),{variant:"secondary",disabled:o+1>=n})]))}return a}function da(e,r){let a=!!e.busy["create-world"],i=t("input",{className:"input",attrs:{id:"fw-world-name",name:"worldName",maxlength:String(la.world),autocomplete:"off",required:"",value:e.worldDraft?.worldName??""},on:{input:()=>r.rememberWorldDraft({worldName:i.value,nickname:n.value})}}),n=t("input",{className:"input",attrs:{id:"fw-nickname",name:"playerNickname",maxlength:String(la.nickname),autocomplete:"off",required:"",value:e.worldDraft?.nickname??""},on:{input:()=>r.rememberWorldDraft({worldName:i.value,nickname:n.value})}});return t("form",{className:"card form",attrs:{"aria-labelledby":"fw-create"},on:{submit:s=>{s.preventDefault(),!(!i.value.trim()||!n.value.trim())&&r.createWorld(i.value,n.value)}}},[t("h2",{className:"section-title",text:"\uC0C8 \uC138\uACC4 \uB9CC\uB4E4\uAE30",attrs:{id:"fw-create"}}),t("p",{className:"muted",text:"\uD50C\uB808\uC774\uC5B4\uB294 \uC678\uD615 \uC5C6\uC774 \uB2C9\uB124\uC784\uC73C\uB85C\uB9CC \uB4F1\uC7A5\uD569\uB2C8\uB2E4. \uB458 \uB2E4 \uB098\uC911\uC5D0 \uC124\uC815\uC5D0\uC11C \uBC14\uAFC0 \uC218 \uC788\uC2B5\uB2C8\uB2E4."}),t("label",{className:"field-label",text:"\uC138\uACC4 \uC774\uB984",attrs:{for:"fw-world-name"}}),i,t("label",{className:"field-label",text:"\uB0B4 \uB2C9\uB124\uC784",attrs:{for:"fw-nickname"}}),n,t("button",{className:"button",text:a?"\uB9CC\uB4DC\uB294 \uC911\u2026":"\uB9CC\uB4E4\uAE30",attrs:{type:"submit"},disabled:a})])}function ca(e,r){let a=e.world?.state==="ready",i=e.worlds.state==="ready"&&e.worlds.value.length===0,n=i?null:t("details",{className:"card restore-details",attrs:{open:e.worldCreateOpen?"":void 0},on:{toggle:()=>r.rememberWorldCreateOpen(!!n?.open)}},[t("summary",{className:"section-title",text:"\uC0C8 \uC138\uACC4 \uB9CC\uB4E4\uAE30"}),da(e,r)]),o=i?da(e,r):n,s=t("details",{className:"card restore-details",attrs:{open:e.restore?"":void 0}},[t("summary",{className:"section-title",text:"\uBC31\uC5C5\uC5D0\uC11C \uBCF5\uC6D0"}),_e(e,r,"fw-worlds-restore")]);return P(e,r,{top:a?{kind:"sub",title:"\uC138\uACC4 \uACE0\uB974\uAE30",back:{route:"backup",label:"\uC800\uC7A5\xB7\uBC31\uC5C5"},resources:!1}:{kind:"sub",title:"\uC232\uACB0 \uACF5\uBC29",resources:!1},backdrop:"wood",body:[i?null:bn(e,r),o,s],nav:!1})}var ma=`url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 120 48'%3E%3Cpath d='M0 0h120v26c-8 0-10 12-20 12S88 22 78 22 66 36 56 36 44 20 34 20 22 34 12 34 4 26 0 26z' fill='%2394bf74' stroke='%235f8f45' stroke-width='3'/%3E%3C/svg%3E")`,pa=`
.ground-preview { position: relative; height: 110px; background: #dcebc4; border: 2px solid var(--ink); border-radius: 12px; }
.ground-area { position: absolute; border: 2px dashed var(--fw-accent); background: #8fbf6e; }
.ground-editor { display: grid; gap: 0.5em; }
.ground-row { display: grid; grid-template-columns: 3em minmax(0,1fr) 2em; gap: 0.5em; align-items: center; min-height: 44px; }
.ground-row input { width: 100%; min-height: 44px; }

:host {
  --fs: var(--fw-font-size, 16px);
  --ink: #4b2e1a;
  --line: 3px;
  --line-in: 2.5px;
  --drop: 0 0.22em 0 var(--ink);
  --fw-page: #f1e4c3;
  --fw-surface: #fbf1da;
  --fw-surface-2: #f2e2bd;
  --fw-surface-3: #fff8e8;
  --fw-text: #3f2717;
  --fw-muted: #7a5a3d;
  --fw-accent: #2e7f72;
  --fw-on-accent: #fffaf0;
  --fw-wood: #c58a52;
  --fw-wood-dark: #8a5a33;
  --fw-leaf: #5a9a44;
  --fw-leaf-soft: #dcebc4;
  --fw-gold: #f3c34a;
  --fw-pass: #3f8a3d;
  --fw-fail: #c0433a;
  --fw-blue: #3a6fc0;
  --fw-unavailable: #8a6a12;
  --fw-track: #e4d6b6;
  display: block;
  height: 100%;
  overflow: hidden;
  color: var(--fw-text);
  color-scheme: light;
  font: 500 var(--fs)/1.5 system-ui, -apple-system, "Apple SD Gothic Neo", "Noto Sans KR", sans-serif;
  -webkit-text-size-adjust: 100%;
  word-break: keep-all;
  overflow-wrap: anywhere;
}
:host(:fullscreen) { width: 100%; height: 100%; padding: env(safe-area-inset-top) env(safe-area-inset-right) env(safe-area-inset-bottom) env(safe-area-inset-left); background: var(--fw-page); }
* { box-sizing: border-box; }
p { margin: 0; }
.icon { width: 1.35em; height: 1.35em; flex: none; fill: none; stroke: currentColor; stroke-width: 2.4; stroke-linecap: round; stroke-linejoin: round; }
.icon .fill { fill: currentColor; stroke: none; }
.icon.tiny { width: 0.95em; height: 0.95em; }
.icon.big { width: 2.2em; height: 2.2em; }
.icon.huge { width: 4.5em; height: 4.5em; stroke-width: 2; }
.muted-icon { color: var(--fw-muted); }
.visually-hidden { position: absolute; width: 1px; height: 1px; padding: 0; margin: -1px; overflow: hidden; clip: rect(0 0 0 0); white-space: nowrap; border: 0; }

/* \u2500\u2500 Frame \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 */
.shell { position: relative; height: 100%; display: flex; flex-direction: column; overflow: hidden; }
.scroll { flex: 1 1 auto; min-height: 0; overflow-y: auto; overflow-x: hidden; overscroll-behavior: contain; }
.column { width: 100%; max-width: 520px; margin: 0 auto; min-height: 100%; display: flex; flex-direction: column; }
.backdrop-forest { background: var(--fw-page); }
.backdrop-forest .scroll {
  background-color: var(--fw-page);
  background-image: ${ma}, linear-gradient(#94bf74, #94bf74);
  background-repeat: repeat-x, no-repeat;
  background-size: 7.5em 3em, 100% 5.2em;
  background-position: 0 5.1em, 0 0;
}
.backdrop-wood { background: #a8703f; }
.backdrop-wood .scroll {
  background-color: #a8703f;
  background-image: ${ma}, linear-gradient(#94bf74, #94bf74),
    repeating-linear-gradient(90deg, #b07a46 0 2.4em, var(--ink) 2.4em calc(2.4em + 3px), #a8703f calc(2.4em + 3px) 4.8em, var(--ink) 4.8em calc(4.8em + 3px));
  background-repeat: repeat-x, no-repeat, repeat;
  background-size: 7.5em 3em, 100% 5.2em, auto;
  background-position: 0 5.1em, 0 0, 0 0;
}
.backdrop-wood .page { padding-left: 0.75em; padding-right: 0.75em; }
.page {
  flex: 1 0 auto;
  display: grid;
  gap: 0.85em;
  align-content: start;
  padding: 0.6em 0.9em 1.25em;
}
.page > * { min-width: 0; }
.muted { color: var(--fw-muted); font-size: calc(var(--fs) * 0.875); }
.empty { color: var(--fw-muted); }
.error { color: var(--fw-fail); font-weight: 800; overflow-wrap: anywhere; }
.hint { display: flex; align-items: center; gap: 0.4em; color: var(--fw-muted); font-size: calc(var(--fs) * 0.85); }
.hint.center { justify-content: center; text-align: center; }

/* Toast: the answer to a tap (locked feature, saved, errors), just above the bottom bar. */
.notice {
  position: absolute;
  z-index: 5;
  left: 50%;
  bottom: calc(1em + env(safe-area-inset-bottom, 0px));
  transform: translateX(-50%);
  width: min(calc(100% - 1.5em), 480px);
  display: flex;
  align-items: center;
  gap: 0.75em;
  padding: 0.6em 0.6em 0.6em 1em;
  border-radius: 1em;
  border: var(--line) solid var(--ink);
  background: var(--fw-surface-3);
  box-shadow: var(--drop);
}
.has-nav .notice { bottom: calc(5.8em + env(safe-area-inset-bottom, 0px)); }
/* While a toast shows, the page can scroll its last controls above it. */
.has-notice .page { padding-bottom: 6em; }
.notice p { flex: 1; min-width: 0; overflow-wrap: anywhere; font-weight: 700; }
.notice.error { color: var(--fw-fail); background: #fde9e2; }
.notice-close { flex: none; min-height: 2.75em; padding: 0 0.6em; border: 0; background: none; color: inherit; font: inherit; font-weight: 800; text-decoration: underline; text-decoration-thickness: 2px; cursor: pointer; }

/* \u2500\u2500 Top bar \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 */
.top { display: grid; gap: 0.45em; padding: 0.75em 0.75em 0.4em; }
.top-row { display: flex; align-items: center; gap: 0.45em; min-width: 0; }
.top-row.second { justify-content: space-between; }
.sign {
  position: relative;
  margin: 0;
  min-width: 0;
  padding: 0.28em 1em;
  border-radius: 0.6em;
  border: var(--line) solid var(--ink);
  background: var(--fw-wood);
  color: var(--ink);
  font-size: calc(var(--fs) * 1.4);
  font-weight: 900;
  line-height: 1.2;
  letter-spacing: 0.02em;
  text-align: center;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  box-shadow: var(--drop), inset 0 -0.3em 0 #b07a46;
}
.sign::before, .sign::after {
  content: "";
  position: absolute;
  top: 50%;
  width: 0.38em;
  height: 0.38em;
  margin-top: -0.19em;
  border-radius: 50%;
  background: var(--ink);
}
.sign::before { left: 0.38em; }
.sign::after { right: 0.38em; }
.sign-home { flex: 0 1 auto; font-size: calc(var(--fs) * 1.6); padding: 0.22em 0.95em; }
.top-sub .sign { flex: 1 1 auto; }
.top-sub.with-resources .sign { flex: 0 1 auto; font-size: calc(var(--fs) * 1.05); padding: 0.32em 0.95em; }
.top-sub:not(.with-resources) .sign { margin-right: 3.2em; }
.back-button, .back-spacer { flex: none; width: 2.75em; height: 2.75em; }
.back-button {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  border-radius: 0.75em;
  border: var(--line) solid var(--ink);
  background: var(--fw-surface-3);
  color: var(--ink);
  box-shadow: var(--drop);
  cursor: pointer;
}
.back-button .icon { stroke-width: 3; }
.resources { display: flex; align-items: center; gap: 0.3em; margin-left: auto; min-width: 0; }
.counter {
  position: relative;
  display: inline-flex;
  align-items: center;
  gap: 0.3em;
  min-width: 0;
  min-height: 2.2em;
  padding: 0 0.65em 0 0.15em;
  border-radius: 999px;
  border: var(--line-in) solid var(--ink);
  background: var(--fw-surface-3);
  color: var(--fw-text);
  font: inherit;
  font-weight: 900;
  font-variant-numeric: tabular-nums;
}
.counter-value { font-size: calc(var(--fs) * 0.9); white-space: nowrap; }
button.counter { cursor: pointer; }
.coin {
  flex: none;
  display: inline-block;
  width: 1.65em;
  height: 1.65em;
  border-radius: 50%;
  background: var(--fw-gold);
  border: var(--line-in) solid var(--ink);
  box-shadow: inset 0 0 0 0.22em var(--fw-gold), inset 0 0 0 0.36em #d9a22c;
}
.ticket-mark { display: inline-flex; color: var(--fw-leaf); padding-left: 0.2em; }
.icon-button {
  position: relative;
  flex: none;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 2.6em;
  height: 2.6em;
  border-radius: 0.75em;
  border: var(--line) solid var(--ink);
  background: var(--fw-surface-3);
  color: var(--ink);
  box-shadow: var(--drop);
  cursor: pointer;
}
.icon-button.gear { border: 0; background: none; box-shadow: none; }
.icon-button.gear .icon { width: 1.9em; height: 1.9em; stroke-width: 2.6; }
.chip-button {
  position: relative;
  display: inline-flex;
  align-items: center;
  gap: 0.4em;
  min-height: 2.4em;
  padding: 0.2em 0.9em;
  border-radius: 0.8em;
  border: var(--line) solid var(--ink);
  background: var(--fw-surface-3);
  color: var(--fw-text);
  font: inherit;
  font-weight: 800;
  box-shadow: var(--drop);
  cursor: pointer;
}

/* \u2500\u2500 Cards \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 */
.card {
  position: relative;
  display: grid;
  gap: 0.75em;
  align-content: start;
  padding: 1em;
  border-radius: 1.1em;
  border: var(--line) solid var(--ink);
  background: var(--fw-surface);
  box-shadow: var(--drop);
}
.card > * { min-width: 0; }
.section-title {
  display: flex;
  align-items: center;
  gap: 0.5em;
  margin: 0;
  font-size: calc(var(--fs) * 1.25);
  font-weight: 900;
}
/* A flat leaf with the same ink outline as everything else. */
.section-title::before {
  content: "";
  flex: none;
  width: 0.9em;
  height: 0.9em;
  border-radius: 0 75% 0 75%;
  border: var(--line-in) solid var(--ink);
  background: var(--fw-leaf);
}
.card-head { display: flex; align-items: flex-start; justify-content: space-between; gap: 0.75em; }
.card-head > div { display: grid; gap: 0.2em; min-width: 0; }

/* \u2500\u2500 Buttons \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 */
.button {
  position: relative;
  justify-self: start;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 0.45em;
  min-height: 2.8em;
  padding: 0.45em 1.2em;
  border-radius: 0.85em;
  border: var(--line) solid var(--ink);
  background: var(--fw-accent);
  color: var(--fw-on-accent);
  font: inherit;
  font-weight: 900;
  box-shadow: var(--drop);
  cursor: pointer;
}
.button:active:not(:disabled) { transform: translateY(0.15em); box-shadow: 0 0.07em 0 var(--ink); }
.button[data-wide] { justify-self: stretch; width: 100%; font-size: calc(var(--fs) * 1.1); }
.button.small { min-height: 2.5em; padding: 0.3em 0.9em; font-size: calc(var(--fs) * 0.95); }
.button.secondary { background: var(--fw-surface-3); color: var(--fw-text); }
.button.big-action { min-height: 3.2em; border-radius: 1em; font-size: calc(var(--fs) * 1.2); }
.button:disabled { opacity: 0.55; cursor: not-allowed; }
.outline-button {
  position: relative;
  flex: none;
  display: inline-flex;
  align-items: center;
  gap: 0.35em;
  min-height: 2.75em;
  padding: 0.3em 0.9em;
  border-radius: 0.85em;
  border: var(--line) solid var(--ink);
  background: var(--fw-surface-3);
  color: var(--fw-text);
  font: inherit;
  font-weight: 900;
  box-shadow: var(--drop);
  cursor: pointer;
}

/* \u2500\u2500 Locked (\uC900\uBE44 \uC911) \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 */
.lock-tag {
  display: inline-flex;
  align-items: center;
  gap: 0.15em;
  padding: 0.05em 0.45em;
  border-radius: 999px;
  border: 2px solid var(--fw-surface-3);
  background: var(--ink);
  color: #fff4dc;
  font-size: calc(var(--fs) * 0.68);
  font-weight: 900;
  line-height: 1.45;
  white-space: nowrap;
}
.is-locked { position: relative; cursor: pointer; }
.is-locked > .lock-tag { position: absolute; top: -0.55em; right: -0.35em; z-index: 1; }
.is-locked > :not(.lock-tag) { opacity: 0.6; }
.is-locked.button { background: #8fb3ab; }
.locked-block { position: relative; display: grid; gap: 0.75em; border-radius: 0.8em; cursor: pointer; }
/* A block that opens its card puts the tag on the card's top edge, clear of the block's title. */
.card > .locked-block:first-child > .locked-veil { top: -1.8em; }
.locked-block > :not(.locked-veil) { opacity: 0.55; }
/* Sits on the block's top edge so it never covers the block's own title. */
.locked-veil {
  position: absolute;
  top: -0.8em;
  right: 0.3em;
  z-index: 1;
  display: inline-flex;
  align-items: center;
  gap: 0.35em;
  padding: 0.12em 0.65em 0.12em 0.2em;
  border-radius: 999px;
  background: var(--fw-surface-3);
  border: var(--line-in) solid var(--ink);
  color: var(--fw-text);
  font-size: calc(var(--fs) * 0.8);
  font-weight: 900;
}

/* \u2500\u2500 Bottom bar \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 */
.tabbar {
  position: relative;
  z-index: 3;
  flex: none;
  display: grid;
  grid-template-columns: repeat(5, minmax(0, 1fr));
  width: 100%;
  max-width: 520px;
  margin: 0 auto;
  padding: 0.4em 0.4em calc(0.4em + env(safe-area-inset-bottom, 0px));
  border-radius: 1.3em 1.3em 0 0;
  border: var(--line) solid var(--ink);
  border-bottom: 0;
  background: var(--fw-surface);
}
.tab {
  position: relative;
  display: grid;
  justify-items: center;
  gap: 0.1em;
  min-width: 0;
  min-height: 3.6em;
  padding: 0.25em 0.1em;
  border: 0;
  border-radius: 0.8em;
  background: none;
  color: var(--fw-text);
  font: inherit;
  cursor: pointer;
}
.tab + .tab::before { content: ""; position: absolute; left: -1px; top: 18%; bottom: 18%; border-left: var(--line-in) solid #d8bf93; }
.tab-icon { position: relative; display: inline-flex; color: var(--ink); }
.tab-glyph { width: 1.95em; height: 1.95em; stroke-width: 2.4; }
.tab-art { display: block; width: 2.3em; height: 2.3em; object-fit: contain; }
.tab-icon .lock-tag { position: absolute; top: -0.3em; right: -1.2em; }
.tab-label { font-size: calc(var(--fs) * 0.85); font-weight: 900; }
.tab.current .tab-label { padding: 0 0.9em; border-radius: 0.55em; border: var(--line-in) solid var(--ink); background: #5f9a4a; color: #fff; }
.tab.current .tab-icon { color: var(--fw-accent); }
.tab.is-locked .tab-glyph { opacity: 0.5; }

/* Home fits the available host viewport; detail sheets keep the full existing content. */
.home-layout .scroll { overflow: hidden; }
.home-layout .column { height: 100%; min-height: 0; position: relative; }
.home-layout .top-home { position: absolute; inset: 0 0 auto; z-index: 3; }
.home-layout .scene { flex: 1 1 auto; min-height: 0; aspect-ratio: auto; margin: 0; }
.home-layout .scene-stage { bottom: 0.65em; }
.home-layout .scene-caption { bottom: 0.2em; }
.home-layout .page { flex: none; display: grid; grid-template-columns: minmax(0, 1fr) minmax(0, 1fr); gap: 0.4em; padding: 0.4em 0.6em 0.55em; }
.home-summary, .home-layout .strip.story, .home-layout .strip.offline {
  min-width: 0; min-height: 3.2em; padding: 0.4em 0.6em; border: var(--line-in) solid var(--ink);
  border-radius: 0.8em; background: var(--fw-surface); color: var(--fw-text); font: inherit; cursor: pointer;
}
.home-summary { display: flex; align-items: center; justify-content: space-between; gap: 0.3em; text-align: left; }
.home-summary-copy { display: grid; min-width: 0; line-height: 1.25; }
.home-summary-copy strong, .home-layout .story-text strong { font-size: calc(var(--fs) * 0.86); }
.home-summary-copy span, .home-layout .story-text span { color: var(--fw-muted); font-size: calc(var(--fs) * 0.75); }
.home-layout .strip.story { justify-content: space-between; text-align: left; gap: 0.25em; }
.home-layout .story-art { display: none; }
.home-layout .round-arrow { width: 1.5em; height: 1.5em; border: 0; background: none; color: var(--ink); }
.home-layout .strip.offline { grid-column: 1 / -1; min-height: 2.75em; font-size: calc(var(--fs) * 0.8); }
@media (max-height: 480px) { .home-layout .scroll { overflow-y: auto; } .home-layout .column { height: auto; min-height: 100%; } .home-layout .scene { flex: none; min-height: 12em; } }

.page-picker { width: 100%; }
.page-picker-summary { display: flex; align-items: center; justify-content: space-between; gap: 0.6em; min-height: 44px; padding: 0.3em 0.8em; border: var(--line-in) solid var(--ink); border-radius: 0.7em; background: var(--fw-surface-3); font-weight: 800; cursor: pointer; list-style: none; }
.page-picker-summary::-webkit-details-marker { display: none; }
.page-picker-summary > span:first-child { overflow-wrap: anywhere; }
.page-picker-options { display: grid; gap: 0.3em; max-height: 14em; overflow-y: auto; margin-top: 0.3em; padding: 0.4em; border: var(--line-in) solid var(--ink); border-radius: 0.7em; background: var(--fw-surface-3); }
.page-picker-option { min-height: 44px; padding: 0.5em 0.7em; border: 2px solid transparent; border-radius: 0.5em; background: transparent; color: var(--fw-text); font: inherit; text-align: left; cursor: pointer; }
.page-picker-option[aria-pressed="true"] { border-color: var(--fw-accent); background: var(--fw-leaf-soft); font-weight: 800; }
.page-picker-arrow { flex: none; }
button:focus-visible, select:focus-visible, input:focus-visible, textarea:focus-visible { outline: 3px solid #315eac; outline-offset: 2px; }
/* \u2500\u2500 \uD648 (01-1) \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 */
.top-home { padding-bottom: 0; }
.chip-button.weather { color: var(--fw-text); }
.scene { position: relative; margin: 0 0 -1.6em; min-height: 17em; aspect-ratio: 390 / 300; }
.scene-art { position: absolute; inset: 0; width: 100%; height: 100%; display: block; }
.scene-stage { position: absolute; left: 0; right: 0; bottom: 2.6em; display: flex; justify-content: space-around; padding: 0 1em; }
.resident-spot {
  position: relative;
  display: grid;
  justify-items: center;
  align-content: end;
  width: 6.5em;
  height: 8.5em;
  border: var(--line) dashed var(--ink);
  border-radius: 3em 3em 1em 1em;
  background: rgba(255, 248, 232, 0.55);
  color: var(--ink);
  font: inherit;
  cursor: pointer;
}
.spot-shadow { width: 4.5em; height: 0.8em; margin-bottom: 0.35em; border-radius: 50%; background: rgba(75, 46, 26, 0.25); }
.spot-text { margin-bottom: 0.5em; font-weight: 900; font-size: calc(var(--fs) * 0.85); }
.scene-caption {
  position: absolute;
  left: 50%;
  bottom: 2em;
  transform: translateX(-50%);
  display: inline-flex;
  align-items: center;
  gap: 0.3em;
  padding: 0.1em 0.8em;
  border-radius: 999px;
  border: var(--line-in) solid var(--ink);
  background: var(--fw-surface-3);
  color: var(--fw-text);
  font-size: calc(var(--fs) * 0.78);
  font-weight: 800;
  white-space: nowrap;
}
.report-card { z-index: 1; }
.report-title { margin: 0; text-align: center; font-size: calc(var(--fs) * 1.45); font-weight: 900; }
.report-body { display: grid; grid-template-columns: minmax(0, 1fr) minmax(0, 1fr); gap: 0.6em; align-items: center; }
.report-items { display: grid; grid-template-columns: 1fr 1fr; gap: 0.4em; padding-right: 0.6em; border-right: var(--line-in) solid #d8bf93; }
.report-slot { display: grid; justify-items: center; gap: 0.1em; padding: 0.5em 0.2em; border-radius: 0.8em; border: var(--line-in) solid var(--ink); background: var(--fw-surface-2); }
.slot-art { width: 2.6em; height: 2.6em; border-radius: 0.6em; border: var(--line-in) solid var(--ink); background: var(--fw-surface-3); }
.slot-name { font-size: calc(var(--fs) * 0.85); font-weight: 800; }
.report-slot strong { font-size: calc(var(--fs) * 1.2); }
.report-actions { display: grid; justify-items: center; gap: 0.4em; }
.report-button { justify-self: stretch; white-space: nowrap; padding-left: 0.6em; padding-right: 0.6em; font-size: calc(var(--fs) * 1.15); }
.report-caption { display: inline-flex; align-items: center; gap: 0.25em; color: var(--fw-muted); font-size: calc(var(--fs) * 0.85); }
.strip {
  position: relative;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 0.5em;
  width: 100%;
  min-height: 2.9em;
  padding: 0.5em 1em;
  border-radius: 1em;
  border: var(--line) solid var(--ink);
  background: var(--fw-surface);
  color: var(--fw-text);
  font: inherit;
  font-weight: 800;
  text-align: left;
  box-shadow: var(--drop);
  cursor: pointer;
}
.strip.story { justify-content: flex-start; gap: 0.8em; padding: 0.6em; min-height: 5em; }
.story-art { flex: none; display: inline-flex; align-items: center; justify-content: center; width: 6em; height: 3.8em; border-radius: 0.75em; border: var(--line-in) solid var(--ink); background: #e9c995; color: var(--ink); }
.story-text { flex: 1; display: grid; min-width: 0; }
.story-text strong { font-size: calc(var(--fs) * 1.1); font-weight: 900; }
.story-text span { color: var(--fw-muted); font-size: calc(var(--fs) * 0.85); }
.round-arrow { flex: none; display: inline-flex; align-items: center; justify-content: center; width: 2.6em; height: 2.6em; border-radius: 50%; border: var(--line) solid var(--ink); background: var(--fw-wood-dark); color: #fff4dc; }
.round-arrow .icon { stroke-width: 3; }

/* \u2500\u2500 \uACF5\uBC29 \uC791\uC5C5 (01-2) \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 */
.field-tabs { display: grid; grid-template-columns: repeat(5, minmax(0, 1fr)); gap: 0.3em; margin-bottom: -0.95em; padding: 0 0.15em; }
.field-tab {
  display: grid;
  justify-items: center;
  gap: 0.1em;
  min-width: 0;
  min-height: 4.5em;
  padding: 0.45em 0.1em 1em;
  border-radius: 0.9em 0.9em 0 0;
  border: var(--line) solid var(--ink);
  border-bottom: 0;
  background: var(--fw-surface);
  color: var(--fw-text);
  font: inherit;
  font-weight: 900;
  cursor: pointer;
}
.field-glyph { width: 1.8em; height: 1.8em; color: var(--fw-leaf); }
.work-card { gap: 0.85em; }
.segmented { display: grid; grid-template-columns: 1fr 1fr; padding: 0.22em; border-radius: 999px; border: var(--line) solid var(--ink); background: var(--fw-surface-3); }
.segment { display: flex; align-items: center; justify-content: center; min-height: 2.6em; border-radius: 999px; font-size: calc(var(--fs) * 1.1); font-weight: 900; }
.segment.selected { border: var(--line-in) solid var(--ink); background: var(--fw-accent); color: var(--fw-on-accent); }
.facility-entry { display: flex; align-items: center; gap: 0.5em; padding: 0.5em; border-radius: 1em; border: var(--line-in) solid var(--ink); background: var(--fw-surface-3); }
.facility-entry .outline-button { padding: 0.3em 0.6em; }
.facility-open { flex: 1; min-width: 0; display: flex; align-items: center; gap: 0.7em; padding: 0.2em; border: 0; border-radius: 0.7em; background: none; color: inherit; font: inherit; text-align: left; cursor: pointer; }
.facility-art, .recipe-art { flex: none; display: inline-flex; align-items: center; justify-content: center; width: 3.4em; height: 3.6em; border-radius: 0.7em; border: var(--line-in) solid var(--ink); background: var(--fw-surface-2); color: var(--ink); }
.facility-text, .recipe-text { display: grid; min-width: 0; }
.facility-text strong, .recipe-text strong { font-size: calc(var(--fs) * 1.15); font-weight: 900; }
.facility-text span, .recipe-text span { color: var(--fw-muted); font-size: calc(var(--fs) * 0.85); }
.recipe { display: flex; align-items: center; gap: 0.8em; padding: 0.6em; border-radius: 1em; border: var(--line-in) solid var(--ink); background: var(--fw-surface-3); }
.recipe-art { width: 5.5em; height: 5em; }
.plan-row, .plan-block { display: grid; gap: 0.5em; padding: 0.6em 0.75em; border-radius: 0.9em; border: var(--line-in) solid var(--ink); background: var(--fw-surface-2); }
.plan-row { grid-template-columns: auto auto minmax(0, 1fr); align-items: center; }
.plan-label { font-weight: 900; }
.plan-label small { color: var(--fw-muted); font-weight: 600; font-size: calc(var(--fs) * 0.75); }
.stepper { display: inline-flex; align-items: center; border-radius: 0.7em; border: var(--line-in) solid var(--ink); background: var(--fw-surface-3); overflow: hidden; }
.step { display: inline-flex; align-items: center; justify-content: center; width: 2.2em; height: 2.2em; }
.step.plus { background: var(--fw-accent); color: var(--fw-on-accent); border-left: var(--line-in) solid var(--ink); }
.step-value { min-width: 2.2em; text-align: center; font-weight: 900; }
.plan-progress { display: grid; gap: 0.25em; min-width: 0; font-size: calc(var(--fs) * 0.85); }
.plan-progress.wide { grid-column: 2 / -1; }
.bar { display: block; height: 0.85em; border-radius: 999px; border: var(--line-in) solid var(--ink); background: var(--fw-track); }
.usage { display: grid; grid-template-columns: minmax(0, 1.3fr) repeat(3, minmax(0, 1fr)); align-items: center; padding: 0.4em; border-radius: 0.7em; border: var(--line-in) solid var(--ink); background: var(--fw-surface-3); }
.usage-item { font-weight: 900; padding-left: 0.4em; }
.usage-cell { display: grid; justify-items: center; border-left: var(--line-in) solid #d8bf93; }
.usage-cell small { color: var(--fw-muted); font-size: calc(var(--fs) * 0.75); }
.priority-row { display: flex; align-items: center; gap: 0.6em; padding: 0.45em 0.6em; border-radius: 0.7em; border: var(--line-in) solid var(--ink); background: var(--fw-surface-3); }
.rank { display: inline-flex; align-items: center; justify-content: center; width: 1.8em; height: 1.8em; border-radius: 0.45em; border: var(--line-in) solid var(--ink); background: var(--fw-surface-2); font-weight: 900; }
.priority-name { flex: 1; font-weight: 900; }
.rule-actions { display: grid; grid-template-columns: minmax(0, 1.8fr) minmax(0, 1fr); gap: 0.6em; }
.rule-actions .button { justify-self: stretch; min-height: 3.1em; }
.button.wide-main { font-size: calc(var(--fs) * 1.15); }

/* \u2500\u2500 \uC2DC\uC124\uACFC \uCC3D\uACE0 (01-3) \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 */
.big-tabs { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 0.3em; margin-bottom: -0.95em; }
.big-tab {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 0.5em;
  min-height: 3.7em;
  padding-bottom: 0.7em;
  border-radius: 1.1em 1.1em 0 0;
  border: var(--line) solid var(--ink);
  border-bottom: 0;
  background: var(--fw-surface);
  color: var(--fw-text);
  font: inherit;
  font-size: calc(var(--fs) * 1.25);
  font-weight: 900;
  cursor: pointer;
}
.big-tab.current { background: var(--fw-accent); color: var(--fw-on-accent); }
.facility { display: grid; grid-template-columns: minmax(0, 0.9fr) minmax(0, 1.1fr); gap: 0.8em; align-items: start; }
.facility-picture { display: flex; align-items: center; justify-content: center; aspect-ratio: 1; border-radius: 1em; border: var(--line-in) solid var(--ink); background: var(--fw-surface-2); color: var(--ink); }
.facility-info { display: grid; gap: 0.45em; min-width: 0; }
.facility-name { font-size: calc(var(--fs) * 1.3); font-weight: 900; }
.facility-level { font-size: calc(var(--fs) * 1.3); font-weight: 900; }
.level-next { color: var(--fw-accent); }
.effect-row { display: grid; grid-template-columns: 1fr 1fr; padding: 0.35em 0.6em; border-radius: 0.6em; border: var(--line-in) solid var(--ink); background: var(--fw-surface-2); font-weight: 800; }
.gold-button { display: flex; align-items: center; justify-content: center; gap: 0.4em; min-height: 3em; border-radius: 1em; border: var(--line) solid var(--ink); background: var(--fw-gold); box-shadow: var(--drop); font-size: calc(var(--fs) * 1.1); font-weight: 900; }
.stock { width: 100%; border-collapse: separate; border-spacing: 0 0.35em; table-layout: fixed; }
.stock th, .stock td { padding: 0.5em 0.25em; text-align: center; overflow-wrap: anywhere; }
.stock thead th { padding: 0.4em 0.2em; background: var(--fw-surface-2); color: var(--fw-muted); font-size: calc(var(--fs) * 0.78); font-weight: 800; border-top: var(--line-in) solid var(--ink); border-bottom: var(--line-in) solid var(--ink); }
.stock thead th:first-child { border-left: var(--line-in) solid var(--ink); border-radius: 0.6em 0 0 0.6em; width: 28%; }
.stock thead th:last-child { border-right: var(--line-in) solid var(--ink); border-radius: 0 0.6em 0.6em 0; }
.stock tbody th, .stock tbody td { background: var(--fw-surface-3); border-top: var(--line-in) solid var(--ink); border-bottom: var(--line-in) solid var(--ink); }
.stock tbody th { display: table-cell; text-align: left; font-weight: 900; border-left: var(--line-in) solid var(--ink); border-radius: 0.7em 0 0 0.7em; }
.stock tbody td:last-child { border-right: var(--line-in) solid var(--ink); border-radius: 0 0.7em 0.7em 0; }
.num { font-variant-numeric: tabular-nums; font-weight: 900; font-size: calc(var(--fs) * 1.05); }
.num.protected { color: var(--fw-fail); }
.num.reserved { color: var(--fw-blue); }
.num.available { color: var(--fw-pass); }
.item-dot { display: inline-block; width: 1.1em; height: 1.1em; margin-right: 0.35em; vertical-align: -0.15em; border-radius: 50%; border: 2px solid var(--ink); background: var(--fw-wood); }
.item-dot.big { width: 2.2em; height: 2.2em; margin: 0; border-width: var(--line-in); }
.storage-grid { list-style: none; margin: 0; padding: 0; display: grid; gap: 0.35em; }
.storage-item { display: flex; align-items: center; gap: 0.5em; min-height: 3em; padding: 0.3em 0.5em; border-radius: 0.9em; border: var(--line-in) solid var(--ink); background: var(--fw-surface-3); text-align: left; }
.storage-name { flex: 1; min-width: 0; font-weight: 800; overflow-wrap: anywhere; }
.storage-item strong { font-size: calc(var(--fs) * 1.2); font-variant-numeric: tabular-nums; }
.toggle-row {
  position: relative;
  display: flex;
  align-items: center;
  gap: 0.7em;
  width: 100%;
  min-height: 3.6em;
  padding: 0.55em 0.75em;
  border-radius: 0.9em;
  border: var(--line-in) solid var(--ink);
  background: var(--fw-surface-3);
  color: var(--fw-text);
  font: inherit;
  text-align: left;
  cursor: pointer;
}
.toggle-icon { flex: none; display: inline-flex; color: var(--fw-leaf); }
.toggle-text { flex: 1; display: grid; min-width: 0; }
.toggle-text strong { font-size: calc(var(--fs) * 1.05); font-weight: 900; }
.toggle-text span { color: var(--fw-muted); font-size: calc(var(--fs) * 0.82); }
.switch { flex: none; position: relative; display: inline-flex; align-items: center; justify-content: flex-end; width: 3.5em; height: 2em; padding: 0 0.5em; border-radius: 999px; border: var(--line-in) solid var(--ink); background: #9b8f80; }
.switch.on { background: var(--fw-leaf); justify-content: flex-start; }
.switch .knob { position: absolute; top: 0.12em; left: 0.12em; width: 1.45em; height: 1.45em; border-radius: 50%; border: var(--line-in) solid var(--ink); background: #fff; }
.switch.on .knob { left: auto; right: 0.12em; }
.switch:has(.switch-label) { width: 4.9em; }
.switch-label { color: #fff; font-size: calc(var(--fs) * 0.75); font-weight: 900; }

/* \u2500\u2500 \uC124\uC815 (04-1) \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 */
/* Flex with wrap: at large text sizes or on narrow phones the field drops to its own line instead of shrinking. */
.setting-row {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 0.5em;
  padding: 0.55em 0.65em;
  border-radius: 0.9em;
  border: var(--line-in) solid var(--ink);
  background: var(--fw-surface-3);
}
.row-leaf { color: var(--fw-leaf); }
.setting-label { font-weight: 900; white-space: nowrap; }
.input {
  width: 100%;
  min-width: 0;
  min-height: 2.6em;
  padding: 0.35em 0.7em;
  border: var(--line-in) solid var(--ink);
  border-radius: 0.7em;
  background: #fffdf6;
  color: var(--fw-text);
  font: inherit;
}
.input.readonly { display: inline-flex; align-items: center; gap: 0.4em; color: var(--fw-muted); overflow: hidden; white-space: nowrap; }
.setting-block { display: grid; gap: 0.5em; padding: 0.55em 0.65em 0.75em; border-radius: 0.9em; border: var(--line-in) solid var(--ink); background: var(--fw-surface-3); }
.setting-block .setting-row { padding: 0; border: 0; background: none; }
/* The field and its button wrap together. */
.setting-field { flex: 1 1 12em; min-width: 0; display: flex; align-items: center; gap: 0.5em; }
.setting-field > .input { flex: 1 1 auto; }
.setting-field > .button { flex: none; white-space: nowrap; }
.setting-row > .slider { flex: 1 1 6em; width: auto; }
.setting-row > .button, .setting-row > .icon, .setting-label, .slider-value { flex: none; }
/* Range: a flat track with an ink outline and a round ink-outlined thumb. */
.slider { -webkit-appearance: none; appearance: none; width: 100%; min-width: 0; height: 2.6em; background: none; cursor: pointer; }
.slider::-webkit-slider-runnable-track { height: 0.85em; border-radius: 999px; border: var(--line-in) solid var(--ink); background: var(--fw-leaf); }
.slider::-moz-range-track { height: 0.85em; border-radius: 999px; border: var(--line-in) solid var(--ink); background: var(--fw-track); }
.slider::-moz-range-progress { height: 0.85em; border-radius: 999px; background: var(--fw-leaf); }
.slider::-webkit-slider-thumb { -webkit-appearance: none; width: 1.5em; height: 1.5em; margin-top: -0.5em; border-radius: 50%; border: var(--line) solid var(--ink); background: var(--fw-surface-3); }
.slider::-moz-range-thumb { width: 1.2em; height: 1.2em; border-radius: 50%; border: var(--line) solid var(--ink); background: var(--fw-surface-3); }
.slider-value { min-width: 3em; text-align: right; font-weight: 800; font-variant-numeric: tabular-nums; }
.font-preview { margin: 0 0.5em; padding: 0.6em; border-radius: 0.7em; border: var(--line-in) dashed var(--ink); background: var(--fw-surface-2); text-align: center; font-size: var(--fs); }
.manage-row {
  position: relative;
  display: flex;
  align-items: center;
  gap: 0.75em;
  width: 100%;
  min-height: 3.1em;
  padding: 0.4em 0.75em;
  border: var(--line-in) solid var(--ink);
  border-radius: 0.85em;
  background: var(--fw-surface-3);
  color: var(--fw-text);
  font: inherit;
  text-align: left;
  cursor: pointer;
}
.manage-icon { flex: none; display: inline-flex; color: var(--fw-wood-dark); }
.manage-title { flex: 1; font-weight: 900; }
.menu-chevron { flex: none; display: inline-flex; color: var(--ink); }
.menu-chevron .icon { stroke-width: 3; }
.note-box { display: flex; align-items: center; gap: 0.75em; padding: 0.65em 0.9em; border-radius: 0.9em; border: var(--line-in) solid var(--ink); background: var(--fw-leaf-soft); color: #33502a; }
.note-box .icon { width: 1.8em; height: 1.8em; }
.note-box > span { display: grid; }
.note-box strong { font-weight: 900; }
.note-box span span { font-size: calc(var(--fs) * 0.85); }
.footnote { justify-self: center; max-width: 100%; padding: 0.3em 1.1em; border-radius: 999px; border: var(--line-in) solid var(--ink); background: var(--fw-surface); color: var(--fw-text); font-size: calc(var(--fs) * 0.85); font-weight: 700; text-align: center; }

/* \u2500\u2500 \uC800\uC7A5\xB7\uBC31\uC5C5 (05-2) \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 */
.card.saved { justify-items: center; gap: 0.3em; padding: 1.2em 1em; }
.saved-title { display: flex; align-items: center; gap: 0.5em; font-size: calc(var(--fs) * 1.7); font-weight: 900; }
.check { display: inline-flex; width: 1.75em; height: 1.75em; align-items: center; justify-content: center; border-radius: 50%; border: var(--line) solid var(--ink); background: var(--fw-pass); color: #fff; }
.check .icon { width: 1.1em; height: 1.1em; stroke-width: 3.4; }
.saved-time { color: var(--fw-muted); font-size: calc(var(--fs) * 1.05); }
.usage-rows { display: grid; padding: 0.3em 0.75em; border-radius: 0.9em; border: var(--line-in) solid var(--ink); background: var(--fw-surface-3); }
.usage-row { display: grid; grid-template-columns: auto 4.6em minmax(0, 1fr) 4.6em; align-items: center; gap: 0.6em; padding: 0.55em 0; }
.usage-row + .usage-row { border-top: var(--line-in) solid #e3cfa6; }
.usage-row .icon { color: var(--ink); }
.usage-label { font-weight: 800; }
.usage-bar { display: block; height: 1em; border-radius: 999px; border: var(--line-in) solid var(--ink); background: var(--fw-track); overflow: hidden; }
.usage-fill { display: block; height: 100%; border-right: var(--line-in) solid var(--ink); border-radius: 999px; background: #3a9a80; }
.usage-size { text-align: right; font-weight: 800; font-variant-numeric: tabular-nums; }
.menu { gap: 0.6em; }
.menu-row {
  position: relative;
  display: flex;
  align-items: center;
  gap: 0.8em;
  width: 100%;
  min-height: 3.8em;
  padding: 0.6em 0.75em;
  border-radius: 0.95em;
  border: var(--line-in) solid var(--ink);
  background: var(--fw-surface-3);
  color: var(--fw-text);
  font: inherit;
  text-align: left;
  cursor: pointer;
}
.menu-row:disabled { opacity: 0.55; cursor: not-allowed; }
.menu-icon { flex: none; display: inline-flex; align-items: center; justify-content: center; width: 2.9em; height: 2.9em; border-radius: 0.75em; border: var(--line-in) solid var(--ink); background: var(--fw-accent); color: var(--fw-on-accent); box-shadow: 0 0.15em 0 var(--ink); }
.menu-icon.light, .menu-icon.quiet { background: var(--fw-surface-2); color: var(--ink); }
.menu-text { display: grid; flex: 1; min-width: 0; }
.menu-title { font-size: calc(var(--fs) * 1.1); font-weight: 900; overflow-wrap: anywhere; }
.menu-row.quiet .menu-title { font-size: var(--fs); }
.menu-detail { color: var(--fw-muted); font-size: calc(var(--fs) * 0.85); overflow-wrap: anywhere; }
.menu-list { list-style: none; margin: 0; padding: 0; display: grid; gap: 0.5em; }
label.menu-row:focus-within { outline: 3px solid var(--fw-accent); outline-offset: 2px; }
.restore { display: grid; gap: 0.6em; }
.preview-box { display: grid; gap: 0.45em; padding: 0.75em; border-radius: 0.9em; border: var(--line-in) dashed var(--ink); background: var(--fw-surface); }
.preview-head { display: flex; align-items: center; gap: 0.45em; font-size: calc(var(--fs) * 1.05); }
.preview-head .icon { color: var(--fw-accent); }
.preview-rows { display: grid; padding: 0.2em 0.75em; border-radius: 0.75em; border: var(--line-in) solid var(--ink); background: var(--fw-surface-3); }
.preview-row { display: grid; grid-template-columns: auto minmax(0, 1fr) auto; align-items: center; gap: 0.75em; padding: 0.4em 0; }
.preview-row + .preview-row { border-top: var(--line-in) solid #e3cfa6; }
.preview-row .icon { color: var(--fw-wood-dark); }
.preview-row strong { font-variant-numeric: tabular-nums; }

/* \u2500\u2500 \uC138\uACC4 \uACE0\uB974\uAE30 \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 */
.form { gap: 0.55em; }
.form .button { margin-top: 0.4em; }
.field-label { font-weight: 900; }
.restore-details > summary { cursor: pointer; min-height: 2.75em; }
.restore-details[open] > .restore { margin-top: 0.75em; }
.invite-empty { display: grid; gap: 0.65em; justify-items: start; }

/* \u2500\u2500 Sheets (\uC2DC\uC791 \uAFB8\uB7EC\uBBF8 and the resident sheets) \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 */
.sheet-backdrop { position: absolute; inset: 0; z-index: 10; display: flex; align-items: flex-end; justify-content: center; padding: 0.75em; background: rgba(48, 29, 16, 0.5); }
.sheet { width: min(100%, 480px); max-height: 100%; overflow-y: auto; gap: 0.75em; padding: 1.25em; }
.kit-heading { display: flex; align-items: center; gap: 0.55em; }
.kit-heading .section-title { margin: 0; }
.kit-gift { width: 2.5em; height: 2.5em; flex: none; object-fit: contain; }
.kit { list-style: none; margin: 0; padding: 0; display: grid; gap: 0.45em; }
.kit-item { display: grid; grid-template-columns: auto minmax(0, 1fr) auto; align-items: center; gap: 0.6em; padding: 0.55em 0.8em; border-radius: 0.8em; border: var(--line-in) solid var(--ink); background: var(--fw-surface-2); font-weight: 800; }
.kit-item .icon { color: var(--fw-leaf); }
.kit-item strong { font-variant-numeric: tabular-nums; }

/* \u2500\u2500 \uC5F0\uACB0 \uC810\uAC80 \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 */
.diagnostics { display: grid; gap: 0.85em; min-width: 0; }
.list { list-style: none; margin: 0; padding: 0; display: grid; gap: 0.5em; }
.row { display: flex; justify-content: space-between; align-items: center; gap: 0.75em; min-width: 0; }
.row.stacked { display: grid; gap: 0.25em; padding-bottom: 0.5em; border-bottom: var(--line-in) solid #e3cfa6; }
.row.stacked:last-child { border-bottom: 0; padding-bottom: 0; }
.row-head { display: flex; justify-content: space-between; align-items: center; gap: 0.75em; }
.name { min-width: 0; overflow-wrap: anywhere; }
.detail { color: var(--fw-muted); font-size: calc(var(--fs) * 0.85); overflow-wrap: anywhere; }
.badge { flex: none; font-size: calc(var(--fs) * 0.8); font-weight: 900; padding: 0.1em 0.6em; border-radius: 999px; border: var(--line-in) solid currentColor; background: var(--fw-surface-3); }
.badge.pass { color: var(--fw-pass); }
.badge.fail { color: var(--fw-fail); }
.badge.unavailable { color: var(--fw-unavailable); }
.file { width: 100%; max-width: 100%; font: inherit; min-height: 2.75em; }
.stage {
  display: flex;
  justify-content: center;
  align-items: flex-end;
  min-height: 12em;
  padding: 0.75em;
  border-radius: 0.8em;
  border: var(--line-in) solid var(--ink);
  background-color: #f4efe3;
  background-image: linear-gradient(45deg, #e2dccd 25%, transparent 25%, transparent 75%, #e2dccd 75%),
    linear-gradient(45deg, #e2dccd 25%, transparent 25%, transparent 75%, #e2dccd 75%);
  background-size: 16px 16px;
  background-position: 0 0, 8px 8px;
}
.preview { max-width: 100%; max-height: 22em; width: auto; height: auto; object-fit: contain; }
.facts { margin: 0; display: grid; grid-template-columns: max-content minmax(0, 1fr); gap: 0.25em 0.75em; font-size: calc(var(--fs) * 0.9); }
.facts dt { color: var(--fw-muted); }
.facts dd { margin: 0; overflow-wrap: anywhere; font-weight: 800; }

/* \u2500\u2500 Narrow phones \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 */
@media (max-width: 380px) {
  :host { --line: 2.5px; --line-in: 2px; }
  .top { padding-left: 0.5em; padding-right: 0.5em; }
  .sign-home { font-size: calc(var(--fs) * 1.3); }
  .top-sub.with-resources .sign { font-size: var(--fs); padding: 0.3em 0.5em; }
  .coin { width: 1.35em; height: 1.35em; }
  .counter { padding-right: 0.45em; }
  .icon-button.gear { width: 2.2em; }
  .field-tab { font-size: calc(var(--fs) * 0.85); }
  .report-body { grid-template-columns: 1fr; }
  .report-items { padding-right: 0; border-right: 0; }
  .facility { grid-template-columns: 1fr; }
  .facility-picture { aspect-ratio: auto; min-height: 6em; }
  .plan-row { grid-template-columns: auto minmax(0, 1fr); }
  .plan-row .plan-progress { grid-column: 1 / -1; }
  .usage-row { grid-template-columns: auto minmax(0, 1fr) auto; }
  .usage-row .usage-label { grid-column: 2; }
  .usage-row .usage-bar { grid-column: 1 / -1; grid-row: 2; }
}

/* \u2500\u2500 Focus \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 */
button:focus-visible, .locked-block:focus-visible, .input:focus-visible, .slider:focus-visible, .file:focus-visible {
  outline: 3px solid var(--fw-accent);
  outline-offset: 3px;
}
@media (prefers-reduced-motion: reduce) { * { scroll-behavior: auto; } .button:active:not(:disabled) { transform: none; } }
`;var ua=`
.work-card { gap: 0.35em; }
.work-stock-actions { display: flex; gap: 0.4em; }
.work-stock-actions .outline-button { flex: 1; min-width: 0; min-height: 44px; }
.work-sections { display: flex; gap: 0.4em; }
.work-sections .pill-tab { flex: 1; min-width: 0; padding: 0.25em; }
.work-sections .pill-tab[aria-pressed="true"] { background: #4f8f6e; color: #fff; }
/* Item tiles: the item's icon in a framed square until the illustrated item art (P5). */
.item-tile { flex: none; display: inline-grid; place-items: center; width: 1.9em; height: 1.9em; margin-right: 0.35em; vertical-align: middle; border-radius: 0.5em; border: 2px solid var(--ink); background: var(--fw-surface-3); color: var(--ink); }
.item-tile .icon { width: 1.25em; height: 1.25em; }
.item-tile.big { width: 3.2em; height: 3.2em; margin: 0; border-width: var(--line-in); border-radius: 0.75em; }
.item-tile.big .icon { width: 2em; height: 2em; }
.item-wild-berry { background: #fbd9d4; color: #a3262a; }
.item-herb { background: #dcebc4; color: #3f7a2d; }
.item-wood { background: #f1d6b2; color: #8a5a33; }
.item-berry-jam { background: #f9c6cf; color: #a3262a; }

/* \uACF5\uBC29 \uC791\uC5C5 */
.facility-entry { display: grid; grid-template-columns: 1fr 1fr; }
.facility-entry .facility-open { grid-column: 1 / -1; min-width: 0; }
.facility-entry .outline-button { min-width: 0; }

.field-tab.current { background: var(--fw-accent); color: var(--fw-on-accent); }
.field-tab.current .field-glyph { color: var(--fw-on-accent); }
.segmented > .segment { border: 0; background: none; color: var(--fw-text); font: inherit; font-weight: 900; cursor: pointer; }
.segmented > .segment.selected { border: var(--line-in) solid var(--ink); background: var(--fw-accent); color: var(--fw-on-accent); }
.recipe-flow { margin-top: 0.15em; color: var(--fw-text); font-weight: 800; font-size: calc(var(--fs) * 0.8); }
.bar { position: relative; overflow: hidden; }
.bar-fill { position: absolute; inset: 0 auto 0 0; display: block; width: 0; border-right: var(--line-in) solid var(--ink); background: var(--fw-accent); }
.bar-fill.red { background: #d9534f; }
.bar-fill[style*="width: 0%"] { border-right: 0; }
.usage-list { display: grid; gap: 0.4em; }
.usage-item { display: inline-flex; align-items: center; min-width: 0; }
.usage-cell.available strong { color: var(--fw-pass); }
.priority-row { flex-wrap: wrap; }
.priority-row.selected { background: #eef6e2; box-shadow: inset 0 0 0 var(--line-in) #4f8f6e; }
.priority-row.off .priority-main { opacity: 0.55; }
.priority-main { flex: 1 1 8em; min-width: 0; display: flex; align-items: center; gap: 0.3em; padding: 0; border: 0; background: none; color: inherit; font: inherit; font-weight: 900; text-align: left; cursor: pointer; }
.priority-main .muted { margin-left: auto; white-space: nowrap; }
.chip-toggle { flex: none; min-height: 2.2em; padding: 0 0.7em; border-radius: 999px; border: var(--line-in) solid var(--ink); background: #b9ad9c; color: #fff; font: inherit; font-size: calc(var(--fs) * 0.8); font-weight: 900; cursor: pointer; }
.chip-toggle.on { background: var(--fw-leaf); }
.order-buttons { flex: none; display: inline-flex; gap: 0.25em; }
.mini { min-width: 44px; min-height: 44px; display: inline-grid; place-items: center; width: 2.2em; height: 2.2em; border-radius: 0.55em; border: var(--line-in) solid var(--ink); background: var(--fw-surface-3); color: var(--ink); cursor: pointer; }
.mini:disabled { opacity: 0.35; cursor: default; }
.mini .icon { stroke-width: 3; }
.add-rules { display: flex; flex-wrap: wrap; gap: 0.4em; }
.outline-button.small { min-height: 44px; padding: 0.2em 0.7em; font-size: calc(var(--fs) * 0.85); box-shadow: 0 0.15em 0 var(--ink); }
.plan-row.current-work { grid-template-columns: auto auto minmax(0, 1fr) auto; }
.countdown { font-weight: 900; font-size: calc(var(--fs) * 1.2); font-variant-numeric: tabular-nums; }
.draft-note { display: flex; justify-content: center; align-items: center; gap: 0.3em; padding: 0.35em 0.8em; border-radius: 999px; border: var(--line-in) dashed var(--ink); background: #fff3c8; font-weight: 800; font-size: calc(var(--fs) * 0.85); }
.link-button { border: 0; background: none; padding: 0.2em; color: var(--fw-accent); font: inherit; font-weight: 900; text-decoration: underline; text-decoration-thickness: 2px; cursor: pointer; }

/* \uC2DC\uC124\uACFC \uCC3D\uACE0 */
.chip-row { display: flex; gap: 0.4em; flex-wrap: wrap; }
.chip-row .pill-tab { padding: 0 1em; }
.gold-button { width: 100%; color: var(--fw-text); font: inherit; font-weight: 900; cursor: pointer; }
.gold-button:disabled { opacity: 0.55; cursor: not-allowed; }
.gold-button .coin { width: 1.4em; height: 1.4em; }
.stock tbody th .item-tile { width: 1.7em; height: 1.7em; }
.storage-item .outline-button { margin-top: 0.2em; }
.stepper.wide { display: flex; justify-content: space-between; width: 100%; }
.stepper.wide .step { width: auto; flex: 1; min-height: 2.6em; border: 0; border-right: var(--line-in) solid var(--ink); background: var(--fw-surface-3); color: var(--fw-text); font: inherit; font-weight: 900; cursor: pointer; }
.stepper.wide .step:last-child { border-right: 0; border-left: var(--line-in) solid var(--ink); }
.stepper.wide .step:nth-child(4) { border-right: 0; border-left: var(--line-in) solid var(--ink); }
.step-value.big { flex: 1.4; display: grid; place-items: center; font-size: calc(var(--fs) * 1.25); }
.protect-list { list-style: none; margin: 0; padding: 0; display: grid; gap: 0.55em; }
.protect-row { display: grid; grid-template-columns: auto minmax(0, 1fr) auto; grid-template-areas: "tile name save" "picker picker picker"; align-items: center; gap: 0.45em 0.5em; padding: 0.55em; border-radius: 0.9em; border: var(--line-in) solid var(--ink); background: var(--fw-surface-3); }
.protect-row[hidden] { display: none; }
.protect-row > .item-tile { grid-area: tile; }
.protect-name { grid-area: name; display: grid; min-width: 0; }
.protect-row > .stepper { grid-area: picker; }
.protect-row > .button { grid-area: save; }

.waiting-guide { display: grid; gap: 0.4em; justify-items: start; }
.waiting-guide .hint { margin: 0; }
.waiting-guide .outline-button { text-align: left; white-space: normal; }

/* \uACF5\uBC29 \uC18C\uC2DD \xB7 \uC791\uC5C5 \uBCF4\uACE0 */
.report-slot.empty { opacity: 0.6; }
.report-slot .item-tile { margin-bottom: 0.1em; }
.count-badge { display: inline-grid; place-items: center; min-width: 1.5em; height: 1.5em; padding: 0 0.3em; border-radius: 999px; border: 2px solid var(--ink); background: #d9534f; color: #fff; font-size: calc(var(--fs) * 0.75); font-weight: 900; }
.strip.offline strong { margin: 0 0.15em; }
.report-total { display: grid; gap: 0.3em; padding: 0.7em 0.8em; border-radius: 0.9em; border: var(--line-in) solid var(--ink); background: var(--fw-leaf-soft); }
.report-items { display: inline-flex; flex-wrap: wrap; gap: 0.3em 0.6em; vertical-align: middle; }
.report-item { display: inline-flex; align-items: center; gap: 0.2em; }
.report-item .item-tile { width: 1.8em; height: 1.8em; }
.report-list { list-style: none; margin: 0; padding: 0; display: grid; gap: 0.4em; max-height: 16em; overflow-y: auto; }
.report-entry { display: grid; gap: 0.1em; padding: 0.5em 0.7em; border-radius: 0.75em; border: var(--line-in) solid var(--ink); background: var(--fw-surface-3); font-size: calc(var(--fs) * 0.9); }
.report-entry.new { background: #fff3c8; }
.report-time { color: var(--fw-muted); font-size: calc(var(--fs) * 0.78); font-weight: 800; }

@media (max-width: 380px) {
  .plan-row.current-work { grid-template-columns: auto minmax(0, 1fr) auto; }
  .plan-row.current-work .plan-label { grid-column: 1 / -1; }
}
`;var ga=`
.paged-rows { display: grid; gap: 0.5em; }
/* Top counters (\uCD08\uB300\uAD8C + \xB7 \uC885\uD45C) */
.invite-counters { gap: 0.35em; }
.counter-plus { display: inline-flex; align-items: center; justify-content: center; width: 1.45em; height: 1.45em; margin-left: 0.1em; border-radius: 50%; border: 2px solid var(--ink); background: var(--fw-accent); color: var(--fw-on-accent); }
.counter-plus .icon { stroke-width: 3; }
.token-mark, .token-coin { flex: none; display: inline-flex; align-items: center; justify-content: center; width: 1.65em; height: 1.65em; border-radius: 50%; border: var(--line-in) solid var(--ink); background: #b9cf7a; color: #2f4a26; }
.token-coin.big { width: 3.6em; height: 3.6em; border-width: var(--line); box-shadow: var(--drop); }
.token-coin.big .icon { width: 1.8em; height: 1.8em; }

/* Tabs and the envelope */
.invite-tabs .segment { gap: 0.45em; }
.invite-tabs .segment .icon { width: 1.2em; height: 1.2em; }
.invite-stage { display: grid; place-items: center; padding: 0.4em 0 0; }
.invite-envelope { width: min(76%, 300px); height: auto; filter: drop-shadow(0 0.25em 0 rgba(75, 46, 26, 0.35)); }

/* \uD76C\uB9DD \uC8FC\uBBFC \xB7 1\uD68C / 10\uD68C \uCD08\uB300 */
.wish-row .menu-detail { overflow-wrap: anywhere; }
.draw-row { display: grid; grid-template-columns: 1fr 1fr; gap: 0.6em; }
.draw-button {
  position: relative;
  display: grid;
  justify-items: center;
  gap: 0.2em;
  min-height: 6.4em;
  padding: 0.7em 0.5em 1.1em;
  border-radius: 1em;
  border: var(--line) solid var(--ink);
  background: var(--fw-accent);
  color: var(--fw-on-accent);
  box-shadow: var(--drop);
  font: inherit;
  cursor: pointer;
}
.draw-button:disabled { background: #a29a8b; color: #f7f1e6; cursor: not-allowed; }
.draw-title { font-size: calc(var(--fs) * 1.35); font-weight: 900; }
.draw-cost { display: inline-flex; align-items: center; gap: 0.3em; font-size: calc(var(--fs) * 1.1); font-weight: 900; }
.draw-short { position: absolute; left: 50%; bottom: -0.85em; transform: translateX(-50%); display: inline-flex; align-items: center; gap: 0.25em; padding: 0.1em 0.6em; border-radius: 999px; border: 2px solid var(--ink); background: var(--fw-surface-3); color: var(--fw-fail); font-size: calc(var(--fs) * 0.8); font-weight: 900; white-space: nowrap; }
.draw-row + .hint { margin-top: 0.6em; }
.link-row { display: flex; justify-content: space-between; gap: 0.5em; padding-top: 0.4em; border-top: var(--line-in) dashed var(--fw-track); }
.link-button.with-icon { display: inline-flex; align-items: center; gap: 0.35em; color: var(--fw-text); }

/* \uC885\uD45C \uAD50\uD658 card and list */
.exchange-card { display: grid; grid-template-columns: auto auto 1fr auto; align-items: center; gap: 0.7em; width: 100%; padding: 0.2em; border: 0; background: none; color: var(--fw-text); font: inherit; text-align: left; cursor: pointer; }
.exchange-count { display: grid; justify-items: center; gap: 0.25em; padding-right: 0.7em; border-right: var(--line-in) solid var(--fw-track); }
.exchange-count strong { font-size: calc(var(--fs) * 1.1); }
.count-pill { padding: 0.1em 0.8em; border-radius: 999px; border: 2px solid var(--ink); background: var(--fw-surface-2); font-weight: 900; font-size: calc(var(--fs) * 1.15); }
.exchange-text { display: grid; gap: 0.2em; min-width: 0; }
.exchange-text strong { display: inline-flex; align-items: center; gap: 0.3em; }
.exchange-summary { display: flex; align-items: center; flex-wrap: wrap; gap: 0.4em; margin: 0; }
.exchange-list, .pick-list, .result-list, .chance-list, .order-list, .queue-list, .unlock-list { list-style: none; margin: 0; padding: 0; display: grid; gap: 0.45em; }
.exchange-row, .chance-row, .result-row { display: flex; align-items: center; gap: 0.6em; padding: 0.45em 0.6em; border-radius: 0.85em; border: var(--line-in) solid var(--ink); background: var(--fw-surface-3); }
.exchange-name, .chance-name { display: grid; gap: 0.2em; flex: 1; min-width: 0; }
.chance-value { font-variant-numeric: tabular-nums; }
.tag.wish { background: var(--fw-gold); color: var(--ink); }

/* Pick rows (\uD76C\uB9DD \uC8FC\uBBFC, \uBC30\uCE58 \uBCC0\uACBD, \uC804\uBB38 \uBD84\uC57C) */
.pick-row { display: flex; align-items: center; flex-wrap: wrap; gap: 0.5em; width: 100%; min-height: 3.2em; padding: 0.45em 0.7em; border-radius: 0.85em; border: var(--line-in) solid var(--ink); background: var(--fw-surface-3); color: var(--fw-text); font: inherit; text-align: left; cursor: pointer; }
.pick-row > strong { flex: 1 1 6em; min-width: 0; overflow-wrap: anywhere; }
.pick-row.selected { background: var(--fw-leaf-soft); box-shadow: inset 0 0 0 2px var(--fw-leaf); }
.pick-row:disabled { cursor: default; }
.pick-row .good { color: var(--fw-pass); font-weight: 900; }
.pick-list.fields .pick-row .icon { width: 1.5em; height: 1.5em; color: var(--fw-accent); }
.assign-now { margin: 0; padding: 0.45em 0.7em; border-radius: 0.8em; border: 2px dashed var(--ink); background: var(--fw-surface); }

/* Results */
.result-hero { display: grid; justify-items: center; gap: 0.35em; text-align: center; }
.result-stage { position: relative; display: block; width: 9em; height: 11em; border-radius: 1em; border: var(--line) solid var(--ink); background: var(--fw-leaf-soft); overflow: hidden; }
.result-name { font-size: calc(var(--fs) * 1.4); }
.result-row > strong { flex: 1; min-width: 0; overflow-wrap: anywhere; }
.result-row > small { flex-basis: 100%; padding-left: 2.9em; }
.result-row { flex-wrap: wrap; }
.result-badge { padding: 0.05em 0.6em; border-radius: 999px; border: 2px solid var(--ink); font-weight: 900; font-size: calc(var(--fs) * 0.82); }
.result-badge.new { background: var(--fw-gold); color: var(--ink); }
.result-badge.breakthrough { background: var(--fw-leaf-soft); color: #2f4a26; }
.result-badge.token { background: #b9cf7a; color: #2f4a26; }

/* \uCD08\uB300\uAD8C \uBC1B\uAE30 \xB7 \uB0A9\uD488 */
.delivery-board { display: grid; gap: 0.5em; }
.delivery-choices { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 0.35em; }
.delivery-choice { display: grid; justify-items: center; gap: 0.15em; min-width: 0; min-height: 44px; padding: 0.35em 0.2em; border: 2px solid var(--ink); border-radius: 0.7em; background: var(--fw-surface-3); color: var(--fw-text); font: inherit; text-align: center; cursor: pointer; }
.delivery-choice span:not(.item-tile) { overflow-wrap: anywhere; font-weight: 800; font-size: calc(var(--fs) * 0.8); }
.delivery-choice small { font-size: calc(var(--fs) * 0.7); }
.delivery-choice.selected { background: var(--fw-leaf-soft); outline: 2px solid var(--fw-accent); }
.order { display: grid; gap: 0.45em; padding: 0.7em; border-radius: 0.9em; border: var(--line-in) solid var(--ink); background: var(--fw-surface-3); }
.order.done { background: var(--fw-surface-2); }
.order-title { font-size: calc(var(--fs) * 1.05); }
.order-items { list-style: none; margin: 0; padding: 0; display: grid; gap: 0.3em; }
.order-items li { display: flex; align-items: center; flex-wrap: wrap; gap: 0.45em; font-weight: 800; }
.order-items li.short > span { color: var(--fw-fail); }
.order-reward { display: flex; align-items: center; gap: 0.3em; margin: 0; font-weight: 900; color: var(--fw-accent); }
.order .status-pill { justify-self: start; }

/* \uC791\uC5C5: closed tabs, \uD574\uAE08, crew line, \uC9C0\uC815 \uD69F\uC218 */
.field-tab.closed { background: var(--fw-surface-2); color: var(--fw-muted); }
.field-tab .lock-tag { position: absolute; top: 0.2em; right: 0.2em; }
.facility-open.closed { cursor: default; }
.unlock-list li { display: flex; align-items: center; gap: 0.5em; padding: 0.45em 0.6em; border-radius: 0.8em; border: var(--line-in) solid var(--ink); background: var(--fw-surface-3); font-weight: 800; }
.unlock-list li > span { flex: 1; min-width: 0; }
.unlock-list li.met { background: var(--fw-leaf-soft); }
.unlock-list li.met .icon { color: var(--fw-pass); }
.crew-line { display: inline-flex; align-items: center; flex-wrap: wrap; gap: 0.35em; font-weight: 800; color: var(--fw-text); }
.crew-line .avatar { width: 1.8em; height: 1.8em; }
.queue-row { display: flex; align-items: center; gap: 0.5em; padding: 0.4em 0.55em; border-radius: 0.8em; border: var(--line-in) solid var(--ink); background: var(--fw-surface-3); }
.queue-name { display: grid; flex: 1; min-width: 0; }
.queue-add { display: grid; gap: 0.55em; padding-top: 0.5em; border-top: var(--line-in) dashed var(--fw-track); }
.queue-add .pill-tab { display: inline-flex; align-items: center; gap: 0.35em; }
.queue-add .pill-tab .item-tile { width: 1.6em; height: 1.6em; }

/* \uC790\uB3D9 \uD310\uB9E4 */
.auto-sell-row { display: grid; gap: 0.5em; padding: 0.7em; border-radius: 0.9em; border: var(--line-in) solid var(--ink); background: var(--fw-surface-3); }
.auto-sell-row.on { background: var(--fw-leaf-soft); }
.auto-sell-head { display: flex; align-items: center; gap: 0.55em; }
.auto-sell-head .protect-name { flex: 1; min-width: 0; display: grid; }
.auto-sell-fields { display: grid; gap: 0.3em; }
.row-actions { display: flex; flex-wrap: wrap; gap: 0.5em; }
.row-actions .button { flex: 1; }

/* \uC8FC\uBBFC: \uD2B9\uAE30 and lit \uB3CC\uD30C leaves */
.talent-card { display: grid; gap: 0.35em; padding: 0.65em 0.75em; border-radius: 0.9em; border: var(--line-in) solid var(--ink); background: var(--fw-leaf-soft); }
.talent-card p { margin: 0; }
.talent-field { display: flex; align-items: center; gap: 0.4em; font-size: calc(var(--fs) * 1.05); }
.talent-field .icon { color: var(--fw-accent); }
.talent-name { display: grid; gap: 0.15em; }
.talent-line, .talent-note { display: flex; align-items: center; flex-wrap: wrap; gap: 0.3em; margin: 0; color: #2f4a26; font-weight: 800; }
.pip.on { background: var(--fw-leaf); }
.passive-block { display: grid; gap: 0.25em; }
.passive-block p { margin: 0; }

@media (max-width: 360px) {
  .draw-title { font-size: calc(var(--fs) * 1.15); }
  .exchange-card { grid-template-columns: auto 1fr auto; }
  .exchange-count { justify-items: start; border-right: 0; }
  .exchange-text { grid-column: 1 / -1; order: 5; }
}
`;var fa=`
.activity-running,.activity-prepare,.activity-record { display: grid; gap: 0.5em; }
.activity-record { padding: 0.6em; border-radius: 0.7em; background: var(--fw-surface-3); }

/* \uD0D0\uC0AC */
.explore-tabs { grid-template-columns: 1fr 1fr 1.4fr; }
.explore-tabs .field-tab span { white-space: nowrap; }
.pair-chips { margin-top: 0.4em; }
.trail-card { position: relative; padding: 0; overflow: hidden; }
.trail-art { display: block; width: 100%; height: auto; }
.place-sign { position: absolute; left: 0.8em; top: 0.8em; padding: 0.3em 0.9em; border-radius: 0.6em; border: var(--line) solid var(--ink); background: #e2b57a; color: var(--ink); font-weight: 900; box-shadow: var(--drop); }
.arc-card > .section-title { justify-content: center; }
.episode-row { list-style: none; margin: 0; padding: 0; display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 0.4em; }
.episode-tile { width: 100%; min-height: 44px; font: inherit; color: var(--fw-text); cursor: pointer; display: grid; justify-items: center; gap: 0.25em; padding: 0.5em 0.35em; border-radius: 0.9em; border: var(--line-in) solid var(--ink); background: var(--fw-surface-3); text-align: center; }
.episode-tile.selected { background: var(--fw-accent); color: var(--fw-on-accent); box-shadow: var(--drop); }
.episode-tile.selected small { color: var(--fw-on-accent); }
.episode-tile.locked.selected { color: var(--fw-text); box-shadow: inset 0 0 0 0.2em var(--fw-accent), var(--drop); }
.episode-tile.locked.selected small { color: var(--fw-muted); }
.episode-tile.locked { background: var(--fw-surface-2); color: var(--fw-muted); }
.episode-icon { position: relative; display: inline-flex; }
.episode-check { position: absolute; right: -0.4em; bottom: -0.2em; display: inline-flex; border-radius: 50%; border: 2px solid var(--ink); background: var(--fw-leaf); color: #fff; }
.episode-text { display: grid; gap: 0.1em; min-width: 0; }
.episode-text strong { font-size: calc(var(--fs) * 1.05); }
.episode-text span { font-weight: 800; font-size: calc(var(--fs) * 0.88); overflow-wrap: anywhere; }
.episode-text small { color: var(--fw-muted); font-size: calc(var(--fs) * 0.75); overflow-wrap: anywhere; }
.expedition-details { display: grid; gap: 0.6em; }
.detail-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 0.4em; padding: 0.6em; border-radius: 0.9em; border: var(--line-in) solid var(--ink); background: var(--fw-surface); }
.detail-cell { display: flex; align-items: center; flex-wrap: wrap; gap: 0.45em; min-width: 0; }
.detail-cell.wide { grid-column: 1 / -1; }
.detail-cell > span { display: grid; min-width: 0; }
.detail-cell small { color: var(--fw-muted); font-size: calc(var(--fs) * 0.8); }
.detail-cell strong { font-size: calc(var(--fs) * 1.05); }
.detail-cell > .icon { color: var(--fw-wood-dark); }
.avatar-row { display: inline-flex !important; grid-auto-flow: column; gap: 0.2em; margin-left: auto; }
.prep-list { display: flex !important; flex-wrap: wrap; gap: 0.4em; }
.prep { display: inline-flex; align-items: center; gap: 0.3em; font-weight: 900; color: var(--fw-fail); }
.prep.ok { color: var(--fw-text); }
.prep.ok .icon { color: var(--fw-pass); }
.locked-reasons ul { margin: 0; padding-left: 1.2em; font-weight: 800; }
.expedition-running { display: grid; gap: 0.45em; }
.running-line { display: flex; align-items: center; gap: 0.45em; margin: 0; }
.running-line .countdown { margin-left: auto; }
.explore-strip { cursor: default; justify-content: flex-start; flex-wrap: wrap; }
.strip-progress { display: grid; flex: 1; gap: 0.25em; min-width: 10em; }
.completed-arc { display: flex; align-items: center; flex-wrap: wrap; gap: 0.5em; padding: 0.45em 0.6em; border-radius: 0.8em; border: var(--line-in) solid var(--ink); background: var(--fw-surface-3); }
.completed-arc strong { flex: 1; }

/* \uACF5\uBC29 \uC774\uC57C\uAE30 */
.story-layout .column { height: 100%; min-height: 0; }
.story-layout .page { display: flex; flex: 1 1 auto; min-height: 0; flex-direction: column; gap: 0.45em; }
.story-layout .story-stage { flex: 1 1 auto; height: auto; min-height: 3em; }
.story-layout .dialogue-box { flex: none; margin-top: 0; min-height: 0; padding: 0.85em 1em; border-radius: 0.7em; }
.story-layout .dialogue-box:not(.choice):not(.loading):not(.error):not(.end) { height: 9em; overflow-y: auto; align-content: start; }
.story-layout .speaker-tag { position: static; justify-self: start; padding: 0; border: 0; background: transparent; color: var(--fw-wood-dark); }
.story-layout .dialogue-box .line { font-size: var(--fs); font-weight: 600; line-height: 1.45; }
.story-layout .reader-foot { flex: none; display: flex; align-items: center; margin-top: 0; }
.story-layout .reader-foot .button { flex: 1; }
.reader-tools { gap: 0.35em; }
.reader-tools .chip-button { min-height: 44px; padding: 0.1em 0.7em; }
.chip-button.active { background: var(--fw-accent); color: var(--fw-on-accent); }
.story-stage { position: relative; height: clamp(15em, 52vh, 26em); border-radius: 1.1em; border: var(--line) solid var(--ink); background: #e9c995; overflow: hidden; box-shadow: var(--drop); }
.stage-shelf { position: absolute; left: 0; right: 0; top: 0; height: 58%; border-bottom: var(--line) solid var(--ink); background: #c58a52; }
.stage-shelf::before { content: ""; position: absolute; left: 8%; right: 8%; top: 35%; height: 0.6em; border: var(--line-in) solid var(--ink); border-radius: 0.3em; background: #8a5a33; }
.stage-cast { position: absolute; inset: 0; display: grid; grid-auto-flow: column; grid-auto-columns: 1fr; align-items: end; padding: 0 4%; }
.stage-spot { position: relative; display: block; height: 92%; }
.stage-spot .figure { position: absolute; inset: 0; }
.emotion-bubble { position: absolute; z-index: 2; bottom: var(--mark-bottom, 78%); left: var(--mark-left, 50%); transform: translateX(-50%); display: inline-grid; place-items: center; min-width: 2.2em; height: 2.2em; padding: 0 0.4em; border-radius: 999px; border: var(--line-in) solid var(--ink); background: #fff8e8; font-weight: 900; font-size: calc(var(--fs) * 1.2); }
.dialogue-box { position: relative; display: grid; gap: 0.5em; margin-top: -2.4em; padding: 1.4em 1.1em 1em; border-radius: 1.1em; border: var(--line) solid var(--ink); background: var(--fw-surface-3); box-shadow: var(--drop); min-height: 7.5em; }
.dialogue-box p { margin: 0; }
.speaker-tag { position: absolute; top: -1.1em; left: 0.9em; display: inline-flex; align-items: center; gap: 0.3em; padding: 0.25em 0.9em; border-radius: 0.6em; border: var(--line-in) solid var(--ink); background: #f2e2bd; font-weight: 900; }
.dialogue-box .line { font-size: calc(var(--fs) * 1.15); font-weight: 800; line-height: 1.55; }
.dialogue-box .narration { color: var(--fw-muted); line-height: 1.55; }
.dialogue-box.narration-only .narration { color: var(--fw-text); }
.dialogue-box.end { text-align: center; }
.end-line { font-size: calc(var(--fs) * 1.15); font-weight: 900; }
.choice-options { display: grid; gap: 0.4em; }
.choice-option { min-height: 2.8em; padding: 0.4em 0.8em; border-radius: 0.8em; border: var(--line-in) solid var(--ink); background: #fff; color: var(--fw-text); font: inherit; font-weight: 800; text-align: left; cursor: pointer; }
.choice-option.chosen { background: var(--fw-leaf-soft); box-shadow: inset 0 0 0 2px var(--fw-leaf); }
.choice-option:disabled { cursor: default; }
.reader-foot { display: grid; justify-items: center; gap: 0.5em; margin-top: 0.6em; }
.reader-foot .count-pill { background: #8a5a33; color: #fff4dc; }
.backlog-list { list-style: none; margin: 0; padding: 0; display: grid; gap: 0.45em; }
.backlog-list li { display: grid; gap: 0.1em; padding: 0.4em 0.6em; border-radius: 0.7em; border: 2px solid var(--fw-track); background: var(--fw-surface-3); }
.backlog-narration span { color: var(--fw-muted); }
@media (max-width: 360px) {
  .explore-tabs { grid-template-columns: 1fr 1fr 1.6fr; }
  .detail-grid { grid-template-columns: 1fr; }
}
`;var wn=Vt.map(e=>`.season-${e}.art-base:is(.backdrop-forest, .backdrop-wood) .scroll { background: var(--fw-page) ${ue(ke[e].base)} center top / 100% auto no-repeat; }`).join(`
`),ha=`
/* Season backdrop (portrait). It scrolls with the page so the column keeps its full width on tall phones. */
${wn}
.art-base.backdrop-forest .scroll:has(.scene img.scene-art) { background: var(--fw-page); }

/* Item, facility and emotion pictures: drawn straight on the panel like the mockups, no tile frame around them. */
.item-tile { width: 2em; height: 2em; }
.item-tile:has(.item-art) { border: 0; border-radius: 0; background: none; }
.item-tile .item-art { width: 100%; height: 100%; object-fit: contain; display: block; filter: drop-shadow(0 1px 0 rgba(75, 46, 26, 0.25)); }
.item-tile.big:has(.item-art) { width: 3.6em; height: 3.6em; }
.stock tbody th .item-tile, .queue-add .pill-tab .item-tile { width: 2em; height: 2em; }
.facility-image { display: block; object-fit: contain; }
.facility-image.big, .facility-image.huge { width: 100%; height: 100%; }
.facility-art { position: relative; }
.facility-art:has(.facility-image) { width: 6em; height: 4.8em; border: 0; border-radius: 0; background: none; }
.recipe-art:has(.item-art) { border: 0; border-radius: 0; background: none; }
.recipe-art .item-tile.big:has(.item-art) { width: 4.6em; height: 4.6em; }
.facility-picture:has(.facility-image) { border: 0; border-radius: 0; background: none; aspect-ratio: auto; min-height: 0; }
.facility-image.huge { max-height: 11em; }
.facility-picture.closed .facility-image, .facility-art.closed .facility-image { filter: grayscale(0.85) brightness(0.92); }
.facility-lock { position: absolute; right: 0; bottom: 0; display: inline-grid; place-items: center; width: 1.8em; height: 1.8em; border-radius: 50%; border: var(--line-in) solid var(--ink); background: var(--fw-wood); color: var(--ink); }
.facility-lock .icon { width: 1.1em; height: 1.1em; }
.facility-entry:has(.facility-image) { padding: 0.35em 0.5em; }
.facility-entry:has(.facility-image) .facility-text strong { white-space: nowrap; }
img.scene-art { object-fit: cover; object-position: 50% 60%; }
.story-stage .stage-art { position: absolute; inset: 0; width: 100%; height: 100%; object-fit: cover; object-position: 50% 60%; display: block; }
.art-sign .reader-tools .chip-button { white-space: nowrap; }
img.emotion-bubble.emotion-art { min-width: 0; width: 2.6em; height: 2.6em; padding: 0; border: 0; border-radius: 0; background: none; object-fit: contain; }

/* \uD648 (board 01-1): the workshop scene fills the top of the screen and the sign, money and \uB0A0\uC528 sit on it. */
.column:has(> .scene img.scene-art) { position: relative; }
.column:has(> .scene img.scene-art) > .top-home { position: absolute; z-index: 3; top: 0; left: 0; right: 0; }
.scene:has(img.scene-art) { aspect-ratio: 390 / 470; min-height: 22em; margin-bottom: 0; }
.home-layout .scene:has(img.scene-art) { min-height: 0; aspect-ratio: auto; margin: 0; }
@media (max-height: 480px) { .home-layout .scene:has(img.scene-art) { min-height: 12em; } }

/* Wooden sign (title-sign.webp) on every screen; the DOM title sits in its empty middle (textSafeRect 22\u201378 % \xD7 36\u201374 %). */
.art-sign .sign {
  flex: none;
  aspect-ratio: 768 / 359;
  width: min(12em, 52vw);
  display: grid;
  place-items: center;
  padding: 0;
  border: 0;
  border-radius: 0;
  background: ${ue(G.titleSign)} center / 100% 100% no-repeat;
  box-shadow: none;
  color: #4b2e1a;
  font-size: calc(var(--fs) * 1.6);
  font-weight: 900;
  letter-spacing: 0.04em;
  overflow: visible;
}
.art-sign .sign::before, .art-sign .sign::after { content: none; }
.art-sign .sign-home { width: min(10.5em, 44vw); font-size: calc(var(--fs) * 1.45); }
/* The gear on the scene: a cream disc so it reads over leaves (board 01-1). */
.art-base .icon-button.gear { border-radius: 50%; background: rgba(255, 248, 232, 0.85); }
.art-sign .top-sub .sign { margin-right: 0; }
.art-sign .top-sub:not(.with-resources) .top-row { justify-content: center; }
.art-sign .top-sub:not(.with-resources) .back-button { position: absolute; left: 0.75em; }
.art-sign .top-sub.with-resources .sign { width: min(9.5em, 40vw); font-size: calc(var(--fs) * 1.15); padding: 0; }

/* Narrow phones: the sign and its title shrink with the bar so the money and the gear keep their row. */
.art-sign .top { container-type: inline-size; }
@container (max-width: 380px) {
  .art-sign .sign-home { width: 40cqi; font-size: 5cqi; padding: 0; }
  .art-sign .top-sub.with-resources .sign { width: 37cqi; font-size: 4.3cqi; padding: 0; letter-spacing: 0; }
}
/* Large teal calls to action: primary-button.webp as nine-slice. Small, inline and secondary buttons stay drawn. */
.art-button .button:not(.secondary):not(.small):not(.is-locked):not(:disabled):not(.pressed):not(.setting-field > .button) {
  border-color: transparent;
  border-width: 0;
  border-image: ${ue(G.primaryButton)} 70 138 fill / 16px 32px / 0 stretch;
  background: transparent;
  box-shadow: none;
  padding-left: 1.8em;
  padding-right: 1.8em;
  text-shadow: 0 1px 0 rgba(37, 22, 12, 0.45);
}

.art-button .button.report-button:not(:disabled) { padding-left: 1.1em; padding-right: 1.1em; }

/* Cards, sheets and the story dialogue: paper-panel.webp (cream paper with leaf corners, as on every board). */
.art-paper .card, .art-paper .sheet, .art-paper .dialogue-box {
  border-color: transparent;
  border-width: 0;
  border-image: ${ue(G.paperPanel)} 105 154 fill / 30px 44px / 0 stretch;
  background: transparent;
  box-shadow: none;
}
.art-paper .card { padding: 1.1em 1.2em; }
.art-paper .resident-board { padding: 0.8em 1em; }
/* Inside the paper, rows and boxes use a light tan line and no ink frame, as on the boards. */
.art-paper .card :is(.facility-entry, .recipe, .plan-row, .plan-block, .setting-block, .detail-grid, .report-slot, .kit-item, .completed-arc, .segmented, .episode-tile:not(.selected)) {
  border-color: #dcc49a;
  border-width: 2px;
}
.art-paper .sheet, .art-paper .dialogue-box { padding: 1.5em 1.6em; }
/* With the 96 px picture the facility text needs the row: the action button wraps under it on phones. */
.facility-entry:has(.facility-image) { flex-wrap: wrap; }
.facility-entry:has(.facility-image) .facility-open { flex: 1 1 13em; }
.facility-entry:has(.facility-image) .outline-button { white-space: nowrap; }
.facility-entry:has(.facility-image) > :not(.facility-open) { margin-left: auto; }
.work-card .facility-entry:has(.facility-image) > .outline-button { width: 100%; margin: 0; justify-content: center; text-align: center; white-space: nowrap; font-size: calc(var(--fs) * 0.85); }
.work-stock-actions .outline-button { justify-content: center; text-align: center; }
.work-fields { margin-bottom: 0; }
.work-fields .field-tab { min-height: 44px; padding: 0.3em 0.1em; border-bottom: var(--line) solid var(--ink); border-radius: 0.65em; }
.work-fields .field-glyph { display: block; margin: 0 auto; }
.work-card .facility-art, .work-card .facility-image { width: 44px; height: 44px; }
.work-card .facility-text strong { font-size: var(--fs); }
.work-card .facility-open { gap: 0.4em; }
.work-card .segment { min-height: 44px; }
.work-card .facility-entry .outline-button { min-height: 44px; }
.work-card .plan-row.current-work { grid-template-columns: auto minmax(0, 1fr) auto; }
.work-card .current-work .plan-label { grid-column: 1 / -1; }
.work-card .current-work .plan-progress { grid-column: auto; }
.art-paper .work-card { padding: 0.6em 0.8em; gap: 0.25em; }

.big-tabs { grid-template-columns: repeat(2, minmax(0, 1fr)); }
/* Mockup art pass: read the whole production plan in one flow. */
.work-card .section-title { font-size: calc(var(--fs) * 1.1); padding-top: 0.65em; border-top: 1px solid #dcc49a; }
.art-paper .work-card { padding: 1em 1.15em; gap: 0.7em; }
.work-card .facility-art, .work-card .facility-image { width: 5em; height: 4.5em; }
.work-fields .field-art { display: block; width: 1.9em; height: 1.9em; object-fit: contain; }
.work-fields .field-tab { display: flex; flex-direction: column; gap: 0.2em; padding: 0.4em 0.15em; }
.work-stock-actions { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 0.6em; }
.work-stock-actions .button { width: 100%; padding: 0.5em; }
.art-paper .card :is(.priority-row, .usage, .setting-row, .storage-item, .usage-rows, .menu-row) { border-color: #dcc49a; box-shadow: none; }
.art-paper .card .outline-button { border-width: 2px; box-shadow: 0 2px 0 #d7bd92; }
.art-paper .card .muted { font-weight: 500; }
.art-paper .card .recipe-text strong { font-weight: 800; }

/* The original paper and button pictures also dress secondary controls. */
.art-paper .button.secondary, .art-paper .page-picker-summary {
  border: 1px solid #b49a72; background: var(--fw-surface-3); box-shadow: none; padding: 0.6em 1em;
}
.tab.current { background: var(--fw-leaf-soft); box-shadow: inset 0 0 0 1px #769b55; }
.tab.current .tab-label { border: 0; background: none; color: var(--fw-text); padding: 0; }

/* Restore the report illustration and story banner; content may scroll instead of shrinking. */
.home-layout .scroll { overflow-y: auto; }
.home-layout .column { height: auto; min-height: 100%; }
.home-layout .scene { flex: none; height: clamp(18em, 48vh, 30em); }
.home-layout .page { grid-template-columns: minmax(0, 1fr); gap: 0.6em; }
.home-layout .report-card { padding: 1em 1.15em; }
.home-layout .report-title { font-size: calc(var(--fs) * 1.2); }
.home-layout .report-body { grid-template-columns: minmax(0, 1fr) minmax(0, 1fr); gap: 0.5em; }
.home-layout .report-items { padding: 0; border: 0; }
.home-layout .report-slot { padding: 0; border: 0; background: none; }
.home-layout .report-actions { min-width: 0; }
.home-layout .report-button { min-width: 0; width: 100%; font-size: var(--fs); }
.home-layout .strip.story { min-height: 5em; padding: 0.5em 0.8em; }
.home-layout .story-art { display: flex; flex: none; width: 4em; height: 4em; padding: 0; border: 0; background: none; }
.story-vignette { width: 100%; height: 100%; object-fit: contain; }
.home-layout .story-text { flex: 1; min-width: 0; }
.home-layout .story-text strong { font-size: var(--fs); }
.home-layout .story-text span { font-size: calc(var(--fs) * 0.875); }
.home-layout .strip.offline { grid-row: 2; }
.trail-scene { position: relative; background: #dcebc4; aspect-ratio: 360 / 200; overflow: hidden; }
.trail-background { position: absolute; inset: 0; width: 100%; height: 100%; object-fit: cover; }
.trail-scene .trail-art { position: absolute; inset: 0; width: 100%; height: 100%; }
.invite-scene { display: block; width: 100%; max-height: 17em; object-fit: cover; border-radius: 1em; }
@media (max-width: 340px) {
  .home-layout .report-body { grid-template-columns: minmax(0, 1fr); }
  .home-layout .report-items { justify-content: space-around; }
  .home-layout .report-button { min-height: 44px; }
  .rule-actions { grid-template-columns: minmax(0, 1fr); }
}

.letter-detail {
  border: 0;
  border-image: ${ue(G.letterPaper)} 200 190 fill / 55px 42px / 0 stretch;
  padding: 3.6em 1.6em 2.6em;
  color: var(--fw-text);
}
.letter-detail h3 { margin: 0; font-size: calc(var(--fs) * 1.15); }
.letter-body { overflow-wrap: anywhere; }

/* Anchor the title to the wooden board, independent of the surrounding row width. */
.art-sign .sign-title { position: absolute; inset: 36% 18% 22%; display: grid; place-items: center; line-height: 1.1; white-space: nowrap; font-size: min(1em, 4.2cqi); }
.ground-launch.icon-button { width: 44px; height: 44px; min-height: 44px; min-width: 44px; padding: 0; border-width: 2px; box-shadow: none; bottom: 0.75em; right: 0.75em; }
.empty, .invite-empty { text-align: center; justify-items: center; }
.card > .empty, .sheet > .empty { width: 100%; padding: 1em 0; }
.report-slot.empty { justify-items: center; text-align: center; }
.report-slot.empty .slot-art { display: none; }

.season-weather { display: flex; align-items: center; gap: 0.4em; }
.season-badge { display: inline-grid; place-items: center; min-height: 2em; padding: 0.15em 0.65em; border: 1.5px solid var(--ink); border-radius: 999px; background: var(--fw-surface-3); color: var(--fw-text); font-weight: 700; }

/* Align icon and label as one centered control; keep reading and action gaps distinct. */
.work-fields .field-tab { align-items: center; justify-content: center; text-align: center; min-height: 4.4em; padding: 0.5em 0.2em; gap: 0.25em; font-weight: 700; }
.work-fields .field-art { flex: none; width: 1.7em; height: 1.7em; margin: 0 auto; }
.work-fields .field-tab > span:not(.lock-tag) { width: 100%; text-align: center; line-height: 1.25; }
.work-card .facility-entry { gap: 0.6em; padding: 0.65em; }
.work-card .recipe { gap: 0.7em; padding: 0.75em; }
.work-card .recipe-art .item-tile.big:has(.item-art) { width: 3.5em; height: 3.5em; }
.work-card .recipe-text strong { font-size: calc(var(--fs) * 1.1); line-height: 1.3; }
.work-card .recipe-text > span { font-size: calc(var(--fs) * 0.875); line-height: 1.5; }
.work-card .section-title { gap: 0.4em; font-size: calc(var(--fs) * 1.1); }
.mail-new { position: absolute; right: -0.2em; top: -0.2em; display: grid; place-items: center; width: 1.1em; height: 1.1em; border: 1px solid var(--ink); border-radius: 50%; background: var(--fw-gold); color: var(--ink); }
.mail-new .icon { width: 0.8em; height: 0.8em; }
.weather-choices { display: grid; grid-template-columns: repeat(4, minmax(0, 1fr)); gap: 0.4em; }
.weather-choice { display: grid; place-items: center; align-content: center; gap: 0.25em; min-width: 0; min-height: 44px; padding: 0.5em 0.2em; border: 1px solid #b49a72; border-radius: 0.7em; background: var(--fw-surface-3); color: var(--fw-text); font: inherit; cursor: pointer; }
.weather-choice.current { border: 2px solid var(--fw-accent); background: var(--fw-leaf-soft); font-weight: 700; }
.weather-choice-art { width: 1.6em; height: 1.6em; object-fit: contain; }
.weather-layer { position: absolute; inset: 0; overflow: hidden; pointer-events: none; z-index: 1; opacity: 0.6; }
.weather-layer img { object-fit: contain; }
.weather-sun { position: absolute; width: 3em; height: 3em; right: 18%; top: 23%; }
.weather-cloud { position: absolute; width: 4.5em; height: 3em; left: 12%; top: 24%; animation: fw-cloud-drift 12s ease-in-out infinite alternate; }
.weather-particle { position: absolute; left: var(--weather-x); top: -10%; width: 0.8em; height: 0.8em; animation: fw-weather-fall var(--weather-duration) linear var(--weather-delay) infinite; }
.weather-snow .weather-particle { width: 1em; height: 1em; }
.weather-sprite { width: 100%; height: 100%; }
.scene-stage { z-index: 2; }
.ground-launch, .scene-caption { z-index: 2; }
@keyframes fw-weather-fall { from { transform: translate(0, 0); } to { transform: translate(0.8em, calc(60vh + 4em)); } }
@keyframes fw-cloud-drift { from { transform: translateX(0); } to { transform: translateX(1em); } }
@media (prefers-reduced-motion: reduce) {
  .weather-layer * { animation: none !important; }
  .weather-particle { top: var(--weather-top); opacity: 0.4; }
}

.work-card .facility-text strong { white-space: normal; line-height: 1.3; }
.work-card .facility-entry { grid-template-columns: repeat(2, minmax(0, 1fr)); }
@container (max-width: 360px) {
  .art-sign .top-sub.with-resources .top-row { flex-wrap: wrap; }
  .art-sign .top-sub.with-resources .resources { flex: 1 0 100%; justify-content: flex-end; margin-left: 0; }
}
@media (max-width: 360px) {
  .work-card .facility-entry .outline-button { grid-column: 1 / -1; white-space: normal; }
  .work-card .facility-art, .work-card .facility-image { width: 3.8em; height: 3.8em; }
}

/* Resident boards: picture selection and details remain in one reading flow. */
.resident-grid { grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 0.6em; }
.resident-card { border: 1px solid #c9b18a; gap: 0.4em; padding: 0.45em; box-shadow: none; }
.resident-card.selected { border: 2px solid var(--fw-accent); background: #eef6e2; box-shadow: none; }
.resident-card-main { min-width: 0; gap: 0.4em; }
.card-stage { border: 1px solid #dcc49a; background: #f6ead0; }
.resident-name { font-size: var(--fs); line-height: 1.35; font-weight: 700; }
.resident-field-label { font-size: calc(var(--fs) * 0.8); color: var(--fw-muted); }
.resident-card .status-pill { min-height: 1.8em; font-size: calc(var(--fs) * 0.85); font-weight: 700; border-width: 1px; cursor: inherit; }
.detail-info { gap: 0.5em; }
.detail-name { font-size: calc(var(--fs) * 1.15); line-height: 1.35; }
.detail-actions { gap: 0.5em; }
.detail-action { min-height: 44px; min-width: 0; border: 1px solid #b49a72; padding: 0.45em 0.3em; font-weight: 700; }
.relation-hero .avatar.large { width: 4.5em; height: 4.5em; max-width: 100px; max-height: 100px; }
.hero-label { margin-top: 0; max-width: 100%; overflow-wrap: anywhere; }
.hero-pairs { font-size: calc(var(--fs) * 1.4); line-height: 1.3; overflow-wrap: anywhere; }
.hero-note { font-weight: 500; }
.pair-row { gap: 0.85em; }
.relation-now { border: 1px solid #dcc49a; }
.pair-actions .button { grid-column: auto; min-width: 0; min-height: 44px; padding: 0.45em; font-size: calc(var(--fs) * 0.9); }
.archived-row { flex-wrap: wrap; }
.archived-name { min-width: 0; overflow-wrap: anywhere; }
.art-paper .steps { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 0.5em; padding: 0.85em; }
.steps .step-arrow { display: none; }
.step-item { flex-direction: column; align-items: center; text-align: center; gap: 0.35em; }
.step-label { font-size: calc(var(--fs) * 0.85); line-height: 1.35; }
.drop-zone { flex-wrap: wrap; text-align: center; }
.drop-text { justify-items: center; }
.target-ribbon { flex-wrap: wrap; justify-content: center; text-align: center; }
.action-art { flex: none; width: 1.2em; height: 1.2em; object-fit: contain; }
.pair-actions .button { flex-wrap: wrap; }
.manage-art { display: block; flex: none; width: 2.3em; height: 2.3em; object-fit: contain; }
.manage-row { gap: 0.7em; padding: 0.65em 0.75em; min-height: 44px; border: 1px solid #dcc49a; }
.manage-title { min-width: 0; overflow-wrap: anywhere; font-weight: 700; }
@media (max-width: 380px) {
  .detail-stage { width: min(100%, 8em); justify-self: center; aspect-ratio: 1; }
  .detail-info { justify-items: center; text-align: center; }
  .detail-info .tag-row { justify-content: center; }
  .pair-actions { grid-template-columns: minmax(0, 1fr); }
  .archived-row .button { width: 100%; }
}

.resident-pages { display: grid; grid-template-columns: minmax(0, 1fr) auto minmax(0, 1fr); gap: 0.4em; align-items: center; }
.resident-pages .button { min-width: 0; width: 100%; min-height: 44px; padding: 0.45em 0.4em; white-space: nowrap; }
.resident-pages > span { text-align: center; }
.starter-list > li:only-child { grid-column: 1 / -1; width: calc(50% - 0.3em); justify-self: center; }
.resident-grid > .resident-card:only-child { grid-column: 1 / -1; width: calc(50% - 0.3em); justify-self: center; }
`;var ba=`
.mail-tabs { display: grid; grid-template-columns: 1fr 1fr; gap: 0.4em; }
.mail-tabs [aria-pressed="true"] { outline: 2px solid var(--fw-accent); }
.mail-list,.letter-detail { display: grid; gap: 0.6em; }
.mail-list .button { text-align: left; min-height: 44px; white-space: normal; }
.letter-body { white-space: pre-wrap; line-height: 1.7; }
.mail-unread { font-size: 12px; }

.guidelines-form { display: grid; gap: 0.5em; }
.guidelines-toggle { display: flex; align-items: center; gap: 0.5em; min-height: 44px; }
.guidelines-toggle input { width: 24px; height: 24px; }
.memory-choices { display: grid; gap: 0.35em; }
.memory-choices .button { min-height: 44px; justify-content: flex-start; text-align: left; font-size: calc(var(--fs) * 0.85); }
.memory-choices [aria-pressed="true"] { outline: 2px solid var(--fw-accent); }
.memory-detail { display: grid; gap: 0.5em; padding: 0.7em; border-radius: 0.8em; background: var(--fw-surface-3); overflow-wrap: anywhere; }
.memory-detail form { display: grid; gap: 0.5em; }

/* \u2500\u2500 Shared: ribbon, figure, avatar, tags \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 */
.ribbon {
  justify-self: center;
  max-width: 100%;
  margin: -0.1em 0 0;
  padding: 0.2em 1.1em;
  border-radius: 0.5em;
  border: var(--line-in) solid var(--ink);
  background: var(--fw-surface);
  color: var(--fw-text);
  font-size: calc(var(--fs) * 0.9);
  font-weight: 700;
  text-align: center;
}
.figure { position: relative; display: block; width: 100%; height: 100%; overflow: hidden; }
.figure-body { position: absolute; bottom: 4%; transform: translateX(-50%); display: flex; align-items: flex-end; justify-content: center; width: 100%; }
.figure-image { display: block; max-width: 100%; max-height: 100%; width: auto; height: 100%; object-fit: contain; object-position: 50% 100%; }
.figure-marker { position: absolute; transform: translate(-50%, 0); display: inline-flex; padding: 0.15em; border-radius: 50%; background: var(--fw-surface-3); color: var(--fw-leaf); border: var(--line-in) solid var(--ink); }
.figure-empty { position: absolute; inset: 0; display: grid; place-items: center; align-content: center; gap: 0.2em; color: #c9ad84; }
.figure-silhouette { width: 45%; max-width: 5em; fill: currentColor; stroke: var(--ink); stroke-width: 3; stroke-linejoin: round; }
.figure-empty-text { padding: 0.05em 0.6em; border-radius: 999px; border: var(--line-in) solid var(--ink); background: var(--fw-surface-3); color: var(--fw-muted); font-size: calc(var(--fs) * 0.75); font-weight: 800; }
.checker {
  background-color: #f4efe3;
  background-image: linear-gradient(45deg, #e2dccd 25%, transparent 25%, transparent 75%, #e2dccd 75%),
    linear-gradient(45deg, #e2dccd 25%, transparent 25%, transparent 75%, #e2dccd 75%);
  background-size: 16px 16px;
  background-position: 0 0, 8px 8px;
}
.avatar { position: relative; flex: none; display: inline-grid; place-items: center; width: 3.4em; height: 3.4em; border-radius: 50%; overflow: hidden; border: var(--line-in) solid var(--ink); background: var(--fw-surface-2); color: #c9ad84; }
.avatar.large { width: 6.5em; height: 6.5em; border-width: 3px; }
.avatar-image { width: 100%; height: 100%; object-fit: cover; object-position: 50% 12%; }
.avatar-silhouette { width: 70%; fill: currentColor; stroke: var(--ink); stroke-width: 3; margin-top: 20%; }
.avatar-unknown { position: absolute; inset: 0; display: grid; place-items: center; color: #fff; font-size: calc(var(--fs) * 1.3); font-weight: 900; }
.tag-row { display: flex; flex-wrap: wrap; justify-content: center; gap: 0.3em; }
.tag { position: relative; display: inline-flex; align-items: center; gap: 0.2em; padding: 0.1em 0.65em; border-radius: 999px; border: 2px solid var(--ink); font: inherit; font-size: calc(var(--fs) * 0.78); font-weight: 900; }
.tag.character { background: #d6e7fb; color: #285a93; }
.tag.persona { background: #e9dcfa; color: #6a3f9c; }
.tag.field { background: var(--fw-leaf-soft); color: #3f5b33; cursor: pointer; }
/* On a small tag the lock sits inside, after the word, instead of covering it. */
.tag.is-locked > .lock-tag { position: static; margin-left: 0.15em; border: 0; }
.button.pressed { background: var(--fw-surface-2); box-shadow: none; transform: translateY(0.15em); }
.textarea { width: 100%; min-height: 6em; padding: 0.6em 0.75em; border: var(--line-in) solid var(--ink); border-radius: 0.7em; background: #fffdf6; color: var(--fw-text); font: inherit; line-height: 1.55; resize: vertical; }
.textarea-wrap { position: relative; display: grid; }
.textarea-wrap .textarea { padding-bottom: 1.8em; }
.textarea-wrap .counter-text { position: absolute; right: 0.75em; bottom: 0.45em; }
.counter-text { justify-self: end; color: var(--fw-muted); font-size: calc(var(--fs) * 0.8); font-variant-numeric: tabular-nums; }
.subhead { margin: 0.3em 0 0; font-size: calc(var(--fs) * 1.05); font-weight: 900; }
.empty-state { display: grid; justify-items: center; gap: 0.3em; padding: 1.2em 0.5em; text-align: center; }
.rule-actions.even { grid-template-columns: 1fr 1fr; }
.rule-actions.even .button { justify-self: stretch; }

/* \u2500\u2500 \uC8FC\uBBFC (03-1) \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 */
.search-bar { display: flex; align-items: center; gap: 0.5em; padding: 0.45em; border-radius: 0.9em; border: var(--line-in) solid var(--ink); background: var(--fw-surface); flex-wrap: wrap; }
.search-field { flex: 1 1 10em; display: flex; align-items: center; gap: 0.45em; min-width: 0; padding: 0 0.7em; border-radius: 0.7em; background: var(--fw-surface-2); color: var(--fw-wood-dark); }
.search-input { flex: 1; min-width: 0; min-height: 2.6em; border: 0; background: none; color: var(--fw-text); font: inherit; outline: none; }
.icon-button.filter.active { background: var(--fw-accent); color: var(--fw-on-accent); }
.filter-chip { padding: 0.1em 0.7em; border-radius: 999px; background: var(--fw-leaf-soft); color: #3f5b33; font-size: calc(var(--fs) * 0.8); font-weight: 800; }
.pill-tabs { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 0.4em; }
.pill-tabs.two { grid-template-columns: repeat(2, minmax(0, 1fr)); }
.pill-tab { min-height: 2.6em; border-radius: 0.7em; border: var(--line-in) solid var(--ink); background: var(--fw-surface-2); color: var(--fw-text); font: inherit; font-weight: 800; cursor: pointer; }
.pill-tab.current { background: #4f8f6e; color: #fff; box-shadow: 0 0.15em 0 var(--ink); }
.resident-grid { list-style: none; margin: 0; padding: 0; display: grid; grid-template-columns: 1fr; gap: 0.4em; }
.resident-list-open { display: flex; align-items: center; gap: 0.65em; width: 100%; min-height: 4.2em; padding: 0.35em 0.55em; border: var(--line-in) solid var(--ink); border-radius: 0.8em; background: var(--fw-surface-3); color: var(--fw-text); font: inherit; text-align: left; cursor: pointer; }
.resident-list-copy { display: grid; flex: 1; min-width: 0; line-height: 1.3; }
.resident-list-copy strong { overflow-wrap: anywhere; }
.resident-list-copy span { color: var(--fw-muted); font-size: calc(var(--fs) * 0.85); }
.resident-pages { display: flex; align-items: center; justify-content: space-between; gap: 0.5em; }
.resident-pages .outline-button { min-width: 4em; }
.residents-back { justify-self: start; }
.resident-card { display: grid; justify-items: center; gap: 0.4em; padding: 0.5em 0.5em 0.65em; border-radius: 0.9em; border: var(--line-in) solid var(--ink); background: var(--fw-surface-3); min-width: 0; }
.resident-card.selected { background: #eef6e2; box-shadow: 0 0 0 var(--line-in) #4f8f6e, var(--drop); }
.resident-card-main { display: grid; justify-items: center; gap: 0.35em; width: 100%; padding: 0; border: 0; background: none; color: inherit; font: inherit; cursor: pointer; }
.card-stage { display: block; width: 100%; aspect-ratio: 4 / 5; border-radius: 0.75em; border: var(--line-in) solid var(--ink); background: #f6ead0; overflow: hidden; }
.resident-name { font-size: calc(var(--fs) * 1.02); font-weight: 900; text-align: center; overflow-wrap: anywhere; }
.status-pill { position: relative; display: inline-flex; justify-content: center; align-items: center; width: 100%; min-height: 2.3em; padding: 0.2em 0.5em; border-radius: 0.75em; border: var(--line-in) solid var(--ink); font: inherit; font-weight: 900; }
.status-pill.done { background: #3f7c5e; color: #fff; }
.status-pill.waiting { background: var(--fw-surface-2); color: var(--fw-muted); border: var(--line-in) dashed var(--ink); cursor: pointer; }
.detail-card { gap: 0.8em; }
.resident-detail { display: grid; grid-template-columns: minmax(0, 0.8fr) minmax(0, 1.2fr); gap: 0.75em; align-items: center; }
.detail-stage { display: block; aspect-ratio: 1; border-radius: 0.85em; border: var(--line-in) solid var(--ink); overflow: hidden; background: #f6ead0; }
.detail-info { display: grid; gap: 0.4em; min-width: 0; justify-items: start; }
.detail-info .tag-row { justify-content: flex-start; }
.detail-name { font-size: calc(var(--fs) * 1.2); font-weight: 900; overflow-wrap: anywhere; }
.detail-locked { width: 100%; gap: 0.2em; padding: 0.5em; background: var(--fw-surface-2); }
.passive, .breakthrough { display: flex; align-items: center; gap: 0.35em; flex-wrap: wrap; }
.leaf-pips { display: inline-flex; gap: 0.2em; }
.pip { width: 0.85em; height: 1em; border-radius: 0 75% 0 75%; border: 2px solid var(--ink); background: var(--fw-surface-2); }
.detail-actions { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 0.4em; }
.detail-action { display: flex; align-items: center; justify-content: center; gap: 0.35em; min-height: 3em; padding: 0.3em; border-radius: 0.8em; border: var(--line-in) solid var(--ink); background: var(--fw-surface-3); color: var(--fw-text); font: inherit; font-weight: 800; cursor: pointer; }
.detail-action .icon { color: var(--fw-wood-dark); }

.ground-launch { position: absolute; right: 0.6em; bottom: 0.5em; z-index: 4; min-height: 44px; }
.ground-overlay { position: absolute; inset: 0; z-index: 5; }
.ground-selection { position: absolute; border: 3px dashed #fff; outline: 2px solid #286c4b; background: #4f8f6e55; }
.ground-caption { position: absolute; top: 0; left: 50%; transform: translate(-50%, -100%); padding: 0.2em 0.4em; white-space: nowrap; color: #fff; background: #286c4b; font-size: 12px; }
.ground-handle { position: absolute; width: 44px; height: 44px; border: 2px solid #286c4b; border-radius: 50%; color: #243d2c; background: #fff8e8; font: inherit; font-weight: 900; touch-action: none; cursor: grab; padding: 0; }
.ground-handle.left { left: 0; top: 50%; transform: translate(-50%, -50%); }
.ground-handle.right { right: 0; top: 50%; transform: translate(50%, -50%); }
.ground-handle.top { left: 50%; top: 0; transform: translate(-50%, -50%); }
.ground-handle.bottom { left: 50%; bottom: 0; transform: translate(-50%, 50%); }
.editing-ground .resident-spot { pointer-events: none; }
.editing-ground .resident-spot:not(.filled) { visibility: hidden; }
.editing-ground .resident-spot.filled, .editing-ground .resident-spot.filled .figure { animation-play-state: paused; }
.ground-actions { grid-column: 1 / -1; display: grid; gap: 0.4em; font-size: calc(var(--fs) * 0.85); }
.ground-action-row { display: grid; grid-template-columns: 1.4fr 1fr 1fr; gap: 0.3em; }
.ground-action-row .button { min-width: 0; min-height: 44px; padding: 0.3em; }
/* Foot positions follow the saved world's ground rectangle. */
.ground-stage .resident-spot { position: absolute; transform: translate(-50%, -100%); top: 65%; }
.ground-stage .resident-spot.left { left: 22%; }
.ground-stage .resident-spot.right { left: 78%; }
.ground-stage .resident-spot.filled.left { animation: fw-ground-left 18s ease-in-out infinite; }
.ground-stage .resident-spot.filled.right { animation: fw-ground-right 18s ease-in-out infinite; }
@keyframes fw-ground-left { 0%, 20%, 95%, 100% { left: 22%; top: 65%; } 45%, 70% { left: 40%; top: 35%; } }
@keyframes fw-ground-right { 0%, 20%, 95%, 100% { left: 78%; top: 40%; } 45%, 70% { left: 60%; top: 65%; } }
@media (prefers-reduced-motion: reduce) { .ground-stage .resident-spot.filled.left, .ground-stage .resident-spot.filled.right { animation: none; } }
/* Home scene: residents standing in their places. */
.resident-spot.filled { width: 8.5em; height: 11em; border: 0; border-radius: 0; background: none; }
.resident-spot.filled.left { animation: fw-stroll-left 12s ease-in-out infinite; }
.resident-spot.filled.right { animation: fw-stroll-right 15s ease-in-out infinite; }
@keyframes fw-stroll-left { 0%, 20%, 95%, 100% { transform: translate(0, 0); } 45%, 70% { transform: translate(2.5em, 0); } }
@keyframes fw-stroll-right { 0%, 20%, 95%, 100% { transform: translate(0, 0); } 45%, 70% { transform: translate(-2.5em, 0); } }
@media (prefers-reduced-motion: reduce) { .resident-spot.filled.left, .resident-spot.filled.right { animation: none; } }
@keyframes fw-facing-left { 0%, 69% { transform: scaleX(1); } 70%, 94% { transform: scaleX(-1); } 95%, 100% { transform: scaleX(1); } }
@keyframes fw-facing-right { 0%, 69% { transform: scaleX(-1); } 70%, 94% { transform: scaleX(1); } 95%, 100% { transform: scaleX(-1); } }
.resident-spot.filled .figure { position: absolute; inset: 0; }
.resident-spot.filled.left .figure { animation: fw-facing-left 12s step-end infinite; }
.resident-spot.filled.right .figure { animation: fw-facing-right 15s step-end infinite; }
@media (prefers-reduced-motion: reduce) { .resident-spot.filled.left .figure, .resident-spot.filled.right .figure { animation: none; } }
.spot-name { position: absolute; left: 50%; bottom: -0.4em; transform: translateX(-50%); padding: 0.05em 0.6em; border-radius: 999px; border: var(--line-in) solid var(--ink); background: var(--fw-surface-3); font-size: calc(var(--fs) * 0.78); font-weight: 800; white-space: nowrap; max-width: 100%; overflow: hidden; text-overflow: ellipsis; }
.resident-spot.invite { border-style: solid; background: var(--fw-surface-3); color: var(--fw-accent); box-shadow: var(--drop); }
.resident-spot.invite .spot-text { margin: 0 0.4em 0.6em; text-align: center; }

/* \u2500\u2500 \uD504\uB85C\uD544 sheet \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 */
.sheet-head { display: flex; align-items: center; justify-content: space-between; gap: 0.5em; }
.profile-identity { display: flex; align-items: center; gap: 0.8em; padding: 0.6em; border-radius: 0.9em; background: var(--fw-surface-3); }
.profile-identity-text { display: grid; gap: 0.2em; min-width: 0; }
.profile-identity-text strong { overflow-wrap: anywhere; font-size: calc(var(--fs) * 1.1); }
.profile-identity-text .outline-button { min-height: 44px; justify-content: center; }
.profile-tabs { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 0.35em; }
.profile-tab { min-height: 44px; padding: 0.3em; border: 2px solid var(--ink); border-radius: 0.6em; background: var(--fw-surface-3); color: var(--fw-text); font: inherit; font-weight: 700; cursor: pointer; }
.profile-tab[aria-pressed="true"] { background: var(--fw-accent); color: var(--fw-on-accent); }
.profile-panel[hidden] { display: none; }
.compare { display: grid; gap: 0.6em; }
.compare-box { display: grid; gap: 0.4em; padding: 0.7em; border-radius: 0.8em; border: var(--line-in) solid var(--ink); }
.compare-box.source { background: var(--fw-surface-2); }
.compare-box.world { background: var(--fw-leaf-soft); }
.compare-box .button { justify-self: end; }
.compare-title { display: flex; align-items: center; gap: 0.35em; font-weight: 900; }
.source-field { display: grid; gap: 0.1em; }
.source-field p { white-space: pre-wrap; font-size: calc(var(--fs) * 0.9); }
.source-details { display: block; }
.source-details summary { cursor: pointer; min-height: 2.75em; }
.source-details[open] > :not(summary) { margin-top: 0.6em; }
.sheet-head { flex-wrap: wrap; }
.sheet-head .section-title { flex: 1 1 10em; }
.change-list { margin: 0; padding: 0; list-style: none; display: grid; gap: 0.3em; }
.change-row { display: grid; grid-template-columns: auto minmax(0, 1fr); gap: 0 0.6em; padding: 0.4em 0.6em; border-radius: 0.6em; background: var(--fw-surface-3); font-size: calc(var(--fs) * 0.85); }
.change-kind { font-weight: 800; }
.change-detail { overflow-wrap: anywhere; }
.change-time { grid-column: 1 / -1; color: var(--fw-muted); font-size: calc(var(--fs) * 0.75); }

/* \u2500\u2500 \uAD00\uACC4 (03-2) \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 */
.hero-card { padding-top: 1.2em; }
.relation-hero { display: grid; justify-items: center; gap: 0.35em; text-align: center; }
.hero-label { margin-top: -0.9em; padding: 0.1em 0.9em; border-radius: 0.5em; border: var(--line-in) solid var(--ink); background: var(--fw-surface); font-weight: 800; z-index: 1; }
.hero-pairs { color: var(--fw-wood-dark); font-size: calc(var(--fs) * 1.8); font-weight: 900; letter-spacing: 0.02em; }
.hero-note { font-weight: 700; }
.pair-list { list-style: none; margin: 0; padding: 0; display: grid; gap: 0.6em; }
.pair-row { grid-template-columns: minmax(0, 0.9fr) minmax(0, 1.4fr); align-items: center; gap: 0.6em; }
.pair-faces { display: grid; justify-items: center; gap: 0.25em; }
.pair-letters { display: inline-flex; align-items: center; gap: 0.3em; color: var(--fw-muted); font-weight: 800; }
.letter { display: inline-grid; place-items: center; width: 1.6em; height: 1.6em; border-radius: 50%; background: var(--fw-wood-dark); color: #fff4dc; font-weight: 900; }
.faces { display: inline-flex; align-items: center; gap: 0.15em; }
.faces .avatar { width: 3em; height: 3em; }
.times { color: var(--fw-wood-dark); font-weight: 900; }
.partner-name { font-weight: 800; text-align: center; overflow-wrap: anywhere; font-size: calc(var(--fs) * 0.9); }
.pair-info { display: grid; gap: 0.45em; min-width: 0; }
.relation-now { display: grid; padding: 0.4em 0.7em; border-radius: 0.6em; border: var(--line-in) solid var(--ink); background: var(--fw-surface-3); }
.relation-now small { color: var(--fw-muted); font-size: calc(var(--fs) * 0.75); }
.relation-now strong { font-size: calc(var(--fs) * 1.1); font-weight: 900; }
.recent { display: flex; align-items: center; gap: 0.5em; flex-wrap: wrap; font-size: calc(var(--fs) * 0.9); }
.recent-label { padding: 0.05em 0.6em; border-radius: 0.5em; background: var(--fw-surface-2); color: var(--fw-muted); font-size: calc(var(--fs) * 0.8); }
.pair-actions { display: grid; grid-template-columns: 1fr 1fr; gap: 0.35em; }
.pair-actions .outline-button { justify-content: center; min-height: 2.5em; padding: 0.2em 0.3em; gap: 0.2em; font-size: calc(var(--fs) * 0.82); white-space: nowrap; }
.pair-actions .outline-button .icon { display: none; }
.pair-actions .button { grid-column: 1 / -1; justify-self: stretch; }
.notice-strip { display: flex; align-items: center; justify-content: center; gap: 0.5em; padding: 0.5em 1em; border-radius: 0.9em; border: var(--line-in) solid var(--ink); background: var(--fw-surface); font-weight: 700; text-align: center; }
.bang { display: inline-grid; place-items: center; width: 1.6em; height: 1.6em; border-radius: 50%; background: var(--fw-wood-dark); color: #fff; font-weight: 900; }
.archived-list, .candidate-list { list-style: none; margin: 0; padding: 0; display: grid; gap: 0.4em; }
.archived-row { display: flex; align-items: center; gap: 0.6em; padding: 0.4em; border-radius: 0.7em; background: var(--fw-surface-3); }
.archived-name { flex: 1; min-width: 0; font-weight: 800; overflow-wrap: anywhere; }
.candidate { display: flex; align-items: center; gap: 0.6em; width: 100%; padding: 0.45em 0.6em; border-radius: 0.8em; border: var(--line-in) solid var(--ink); background: var(--fw-surface-3); color: var(--fw-text); font: inherit; text-align: left; cursor: pointer; }
.candidate:disabled { opacity: 0.6; cursor: not-allowed; }
.candidate-name { flex: 1; min-width: 0; font-weight: 800; overflow-wrap: anywhere; }
.candidate-state { color: var(--fw-accent); font-weight: 800; font-size: calc(var(--fs) * 0.85); }

/* \u2500\u2500 \uC8FC\uBBFC \uB4F1\uB85D (05-3) \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 */
.steps { list-style: none; margin: 0; display: flex; align-items: center; justify-content: space-between; gap: 0.3em; padding: 0.7em 0.8em; }
.step-item { display: flex; align-items: center; gap: 0.35em; min-width: 0; }
.step-number { flex: none; display: inline-grid; place-items: center; width: 2em; height: 2em; border-radius: 50%; border: var(--line-in) solid var(--ink); color: var(--fw-wood-dark); font-weight: 900; }
.step-item.current .step-number { background: var(--fw-accent); color: #fff; }
.step-item.done .step-number { background: var(--fw-leaf-soft); border-color: var(--fw-leaf); color: #3f5b33; }
.step-label { font-weight: 900; font-size: calc(var(--fs) * 0.92); white-space: nowrap; }
.step-arrow { color: var(--fw-muted); font-weight: 800; }
.source-list { list-style: none; margin: 0; padding: 0; display: grid; gap: 0.45em; }
.source-pages { display: grid; gap: 0.5em; }
.source-row .menu-detail { display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; }
.source-row:disabled { opacity: 0.65; cursor: default; }
.selected-source { padding: 0.5em; }
.selected-source .menu-row { border: 0; background: none; }
.rebuild { gap: 0.65em; }
.readonly-box { padding: 0.6em 0.8em; border-radius: 0.7em; border: var(--line-in) solid var(--ink); background: var(--fw-surface-3); white-space: pre-wrap; }
.image-drop { display: grid; gap: 0.5em; }
.drop-zone { display: flex; align-items: center; justify-content: center; gap: 0.8em; min-height: 6.5em; padding: 0.8em; border-radius: 0.8em; border: var(--line-in) dashed var(--ink); cursor: pointer; }
.drop-zone:focus-within { outline: 3px solid var(--fw-accent); outline-offset: 2px; }
.drop-icon { width: 3em; height: 3em; color: var(--fw-wood-dark); }
.drop-preview { max-height: 6em; max-width: 40%; object-fit: contain; }
.drop-text { display: grid; gap: 0.1em; min-width: 0; }
.drop-text strong { font-size: calc(var(--fs) * 1.1); font-weight: 900; overflow-wrap: anywhere; }
.drop-text span { color: var(--fw-muted); }
.starter-list { list-style: none; margin: 0; padding: 0; display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 0.6em; }
.starter-option { display: grid; justify-items: center; gap: 0.3em; width: 100%; padding: 0.5em; border-radius: 0.9em; border: var(--line-in) solid var(--ink); background: var(--fw-surface-3); color: var(--fw-text); font: inherit; cursor: pointer; }
.starter-option.chosen { border-color: var(--fw-accent); box-shadow: var(--drop); }
.starter-stage { display: block; width: 100%; aspect-ratio: 4 / 5; border-radius: 0.75em; border: var(--line-in) solid var(--ink); background: #f6ead0; overflow: hidden; }

/* \u2500\u2500 \uC8FC\uBBFC \uADF8\uB9BC (04-2) \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 */
.image-card { gap: 0.7em; }
.target-ribbon { justify-self: center; display: inline-flex; align-items: center; gap: 0.5em; margin-top: -0.2em; padding: 0.3em 1.2em; border-radius: 0.6em; border: var(--line-in) solid var(--ink); background: var(--fw-surface); }
.target-ribbon .icon { color: var(--fw-leaf); }
.target-ribbon strong { font-size: calc(var(--fs) * 1.1); font-weight: 900; }
.image-stage { display: block; aspect-ratio: 4 / 3.4; border-radius: 0.8em; border: var(--line-in) solid var(--ink); overflow: hidden; }
.file-facts { display: grid; justify-items: center; gap: 0.1em; padding: 0.5em; border-radius: 0.7em; border: var(--line-in) solid var(--ink); background: var(--fw-surface-3); text-align: center; }
.file-facts strong { overflow-wrap: anywhere; }
.file-button { cursor: pointer; }
.file-button.busy { opacity: 0.6; cursor: progress; }
.rules { margin: 0; padding: 0.6em 0.8em 0.6em 2em; border-radius: 0.7em; border: var(--line-in) solid var(--ink); background: var(--fw-surface-3); display: grid; gap: 0.15em; font-size: calc(var(--fs) * 0.9); }
.sliders { gap: 0.2em; }
.sliders .setting-row + .setting-row { border-top: var(--line-in) solid var(--ink); padding-top: 0.4em; }
.sliders .icon { color: var(--fw-wood-dark); }
.history-list { list-style: none; margin: 0; padding: 0; display: grid; gap: 0.45em; }
.history-item { display: flex; align-items: center; gap: 0.6em; padding: 0.45em; border-radius: 0.8em; background: var(--fw-surface-3); flex-wrap: wrap; }
.history-thumb { flex: none; display: grid; place-items: center; width: 3.6em; height: 3.6em; border-radius: 0.5em; overflow: hidden; }
.history-thumb img { max-width: 100%; max-height: 100%; object-fit: contain; }

@media (max-width: 380px) {
  .resident-detail { grid-template-columns: 1fr; }
  .detail-stage { aspect-ratio: 4 / 3; }
  .pair-row { grid-template-columns: 1fr; }
  .steps { flex-wrap: wrap; justify-content: center; }
  .step-arrow { display: none; }
  .detail-action { flex-direction: column; gap: 0.1em; font-size: calc(var(--fs) * 0.85); }
}
`;var wa="marinara-capability-forest-workshop",wt=class extends HTMLElement{constructor(){super();T(this,"root");T(this,"controller",null);T(this,"diagnostics",null);T(this,"unsubscribe",null);T(this,"styleNode",document.createElement("style"));T(this,"renderedRoute",null);T(this,"renderedPage",null);T(this,"ticker");T(this,"resizeObserver",new ResizeObserver(()=>this.measureStory()));T(this,"refreshedEnds",new Set);T(this,"onPresence",()=>{document.hidden&&this.controller?.pauseAutoReading(),this.controller?.heartbeat()});T(this,"onBlur",()=>this.controller?.pauseAutoReading());T(this,"presentWorld",null);this.root=this.attachShadow({mode:"open"}),this.styleNode.textContent=pa+ua+ba+ga+fa+ha}connectedCallback(){this.controller||(this.controller=er(),this.diagnostics=new Oe,this.controller.start()),this.unsubscribe?.(),this.unsubscribe=this.controller.store.subscribe(a=>this.render(a)),this.render(this.controller.store.get()),this.resizeObserver.observe(this),this.controller.startHeartbeat(),document.addEventListener("visibilitychange",this.onPresence),window.addEventListener("focus",this.onPresence),window.addEventListener("blur",this.onBlur),clearInterval(this.ticker),this.ticker=setInterval(()=>this.tick(),1e3)}disconnectedCallback(){this.resizeObserver.disconnect(),this.unsubscribe?.(),this.unsubscribe=null,this.controller?.stopHeartbeat(),this.controller?.pauseAutoReading(),document.removeEventListener("visibilitychange",this.onPresence),window.removeEventListener("focus",this.onPresence),window.removeEventListener("blur",this.onBlur),clearInterval(this.ticker)}tick(){let a=Date.now();for(let i of this.root.querySelectorAll("[data-countdown-end]")){let n=Number(i.dataset.countdownEnd);i.textContent=de(n-a),n<=a&&!this.refreshedEnds.has(i.dataset.countdownEnd)&&(this.refreshedEnds.add(i.dataset.countdownEnd),setTimeout(()=>{this.controller?.refreshProduction()},1500))}for(let i of this.root.querySelectorAll("[data-progress-end]")){let n=Number(i.dataset.progressEnd),o=Math.max(1,Number(i.dataset.progressTotal));i.style.width=`${Math.min(100,Math.max(0,Math.round((o-Math.max(0,n-a))/o*100)))}%`}}screen(a,i){switch(a.route){case"home":return Rr(a,i);case"work":return sa(a,i);case"facilities":return aa(a,i);case"settings":return Zr(a,i);case"backup":return Xr(a,i);case"residents":return Qr(a,i);case"relations":return Fr(a,i);case"register":return Or(a,i);case"resident-image":return _r(a,i);case"invite":return Er(a,i);case"explore":return Wr(a,i);case"story":return Lr(a,i);case"diagnostics":return this.diagnostics.start(),P(a,i,{top:{kind:"sub",title:"\uC5F0\uACB0 \uC810\uAC80",back:{route:"backup",label:"\uC800\uC7A5\xB7\uBC31\uC5C5"},resources:!1},backdrop:"wood",body:[this.diagnostics.node],nav:!0});default:return ca(a,i)}}measureStory(){let a=this.controller?.store.get().reader;if(!a||a.story.state!=="ready"||this.controller?.store.get().route!=="story")return;let i=a.story.value.segments[a.index];if(!i||i.kind==="choice")return;let n=this.root.querySelector(".story-layout .dialogue-box:not(.choice)");if(!n)return;let o=Jt(n,i.text);o&&this.controller?.setStoryTextPages(a.storyId,a.index,o)}render(a){let i=a.world?.state==="ready"?a.world.value.worldId:null;i&&i!==this.presentWorld&&(this.presentWorld=i,queueMicrotask(()=>{this.controller?.heartbeat()}));let n=this.screen(a,this.controller);this.style.setProperty("--fw-font-size",`${a.fontSize}px`);let o=this.root.activeElement,s=o?.id,l=o&&"selectionStart"in o&&typeof o.selectionStart=="number"?[o.selectionStart,o.selectionEnd??o.selectionStart]:null,d=rr(a),c=a.route===this.renderedRoute&&d===this.renderedPage?this.root.querySelector(".scroll")?.scrollTop??0:0;this.root.replaceChildren(this.styleNode,n),this.renderedRoute=a.route,this.renderedPage=d;let m=this.root.querySelector(".scroll");if(m&&(m.scrollTop=c),this.measureStory(),s){let g=this.root.getElementById(s);if(g?.focus({preventScroll:!0}),g&&l&&typeof g.setSelectionRange=="function")try{g.setSelectionRange(l[0],l[1])}catch{}}}};typeof customElements<"u"&&!customElements.get(wa)&&customElements.define(wa,wt);
